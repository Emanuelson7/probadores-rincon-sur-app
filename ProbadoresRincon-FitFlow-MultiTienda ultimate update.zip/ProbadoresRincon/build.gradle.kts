// Archivo raíz: solo declara las versiones de los plugins (apply false = no se aplican aquí,
// se aplican en app/build.gradle.kts).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    // Desde Kotlin 2.0 el compilador de Compose es un plugin de Kotlin.
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
    // KSP: procesa las anotaciones de Room (@Entity, @Dao...) y genera código.
    id("com.google.devtools.ksp") version "2.0.20-1.0.25" apply false
}
