package cl.duoc.fitflow.auth.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ValidadorRutTest {

    @Test
    void rutConDigitoVerificadorCorrectoEsValido() {
        assertTrue(ValidadorRut.esValido("12.345.678-5"));
        assertTrue(ValidadorRut.esValido("123456785"));      // sin puntos ni guion también sirve
        assertTrue(ValidadorRut.esValido("11.111.111-1"));
    }

    @Test
    void rutConDigitoKEsValido() {
        assertTrue(ValidadorRut.esValido("10.000.013-K"));
        assertTrue(ValidadorRut.esValido("10.000.013-k"));   // minúscula también
    }

    @Test
    void rutConDigitoVerificadorIncorrectoEsInvalido() {
        assertFalse(ValidadorRut.esValido("12.345.678-K"));  // el correcto es 5
        assertFalse(ValidadorRut.esValido("12.345.678-0"));
    }

    @Test
    void rutVacioNuloOMuyCortoEsInvalido() {
        assertFalse(ValidadorRut.esValido(null));
        assertFalse(ValidadorRut.esValido(""));
        assertFalse(ValidadorRut.esValido("1-9"));
        assertFalse(ValidadorRut.esValido("abc"));
    }

    @Test
    void calculaElDigitoVerificador() {
        assertEquals('5', ValidadorRut.calcularDv("12345678"));
        assertEquals('1', ValidadorRut.calcularDv("11111111"));
        assertEquals('K', ValidadorRut.calcularDv("10000013"));
    }

    @Test
    void limpiaPuntosGuionesYPasaAMayusculas() {
        assertEquals("12345678K", ValidadorRut.limpiar("12.345.678-k"));
    }
}
