package cl.duoc.fitflow.auth.service;

import cl.duoc.fitflow.auth.dto.RegistroRequest;
import cl.duoc.fitflow.auth.model.Usuario;
import cl.duoc.fitflow.auth.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Pruebas unitarias del servicio: el repositorio se reemplaza por un mock (sin base de datos). */
@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UsuarioRepository repo;

    private final PasswordEncoder encoder = new BCryptPasswordEncoder(4);   // costo bajo: pruebas rápidas
    private AuthService servicio;

    @BeforeEach
    void preparar() {
        servicio = new AuthService(repo, encoder);
    }

    private Usuario usuarioGuardado(String correo, String clave) {
        return new Usuario(1, "Ana Pérez", "12.345.678-5", correo, "Asistente de Probadores",
                Usuario.ROL_PERSONAL, 2, encoder.encode(clave));
    }

    private RegistroRequest registroValido() {
        return new RegistroRequest("Camila Rojas", "12.345.678-5", "Camila.Rojas@rinconsur.cl",
                "Asistente de Probadores", "Clave123", true, 2);
    }

    // ---------- login ----------

    @Test
    void loginConCredencialesCorrectasDevuelveElUsuario() {
        when(repo.buscarPorCorreo("ana@rincon.cl")).thenReturn(Optional.of(usuarioGuardado("ana@rincon.cl", "Clave123")));

        Usuario resultado = servicio.login("  ANA@rincon.cl ", "Clave123");   // el correo se normaliza

        assertEquals("Ana Pérez", resultado.nombre());
    }

    @Test
    void loginConClaveIncorrectaLanzaCredencialesInvalidas() {
        when(repo.buscarPorCorreo("ana@rincon.cl")).thenReturn(Optional.of(usuarioGuardado("ana@rincon.cl", "Clave123")));

        assertThrows(ErroresApi.CredencialesInvalidas.class, () -> servicio.login("ana@rincon.cl", "OtraClave1"));
    }

    @Test
    void loginConCorreoInexistenteLanzaCredencialesInvalidas() {
        when(repo.buscarPorCorreo("nadie@rincon.cl")).thenReturn(Optional.empty());

        assertThrows(ErroresApi.CredencialesInvalidas.class, () -> servicio.login("nadie@rincon.cl", "Clave123"));
    }

    @Test
    void loginConCamposVaciosLanzaValidacion() {
        assertThrows(ErroresApi.Validacion.class, () -> servicio.login("", "Clave123"));
        assertThrows(ErroresApi.Validacion.class, () -> servicio.login("ana@rincon.cl", " "));
        verify(repo, never()).buscarPorCorreo(any());
    }

    // ---------- registro ----------

    @Test
    void registroGuardaLaClaveConHashYNormalizaElCorreo() {
        when(repo.buscarPorCorreo("camila.rojas@rinconsur.cl")).thenReturn(Optional.empty());
        when(repo.guardar(any(Usuario.class))).thenAnswer(inv -> inv.getArgument(0));

        servicio.registrar(registroValido());

        ArgumentCaptor<Usuario> captura = ArgumentCaptor.forClass(Usuario.class);
        verify(repo).guardar(captura.capture());
        Usuario guardado = captura.getValue();
        assertEquals("camila.rojas@rinconsur.cl", guardado.correo());
        assertNotEquals("Clave123", guardado.claveHash());                   // nunca en texto plano
        assertTrue(encoder.matches("Clave123", guardado.claveHash()));
        assertEquals(Usuario.ROL_PERSONAL, guardado.rol());
        assertEquals(2, guardado.tiendaId());
    }

    @Test
    void elCargoDeAdministradorCreaUnAdminSinTienda() {
        when(repo.buscarPorCorreo("camila.rojas@rinconsur.cl")).thenReturn(Optional.empty());
        when(repo.guardar(any(Usuario.class))).thenAnswer(inv -> inv.getArgument(0));
        RegistroRequest admin = new RegistroRequest("Camila Rojas", "12.345.678-5", "camila.rojas@rinconsur.cl",
                Usuario.CARGO_ADMIN, "Clave123", true, 2);

        Usuario resultado = servicio.registrar(admin);

        assertEquals(Usuario.ROL_ADMIN, resultado.rol());
        assertEquals(0, resultado.tiendaId());
    }

    @Test
    void registroConCorreoRepetidoLanzaConflicto() {
        when(repo.buscarPorCorreo("camila.rojas@rinconsur.cl"))
                .thenReturn(Optional.of(usuarioGuardado("camila.rojas@rinconsur.cl", "Clave123")));

        assertThrows(ErroresApi.Conflicto.class, () -> servicio.registrar(registroValido()));
        verify(repo, never()).guardar(any());
    }

    @Test
    void registroConRutInvalidoLanzaValidacion() {
        RegistroRequest malo = new RegistroRequest("Camila Rojas", "12.345.678-K", "c@rinconsur.cl",
                "Asistente de Probadores", "Clave123", true, 2);

        ErroresApi.Validacion error = assertThrows(ErroresApi.Validacion.class, () -> servicio.registrar(malo));
        assertTrue(error.getMessage().contains("RUT"));
    }

    @Test
    void registroConClaveDebilLanzaValidacion() {
        RegistroRequest corta = new RegistroRequest("Camila Rojas", "12.345.678-5", "c@rinconsur.cl",
                "Asistente de Probadores", "Abc123", true, 2);          // 6 caracteres
        RegistroRequest sinNumero = new RegistroRequest("Camila Rojas", "12.345.678-5", "c@rinconsur.cl",
                "Asistente de Probadores", "SoloLetras", true, 2);

        assertThrows(ErroresApi.Validacion.class, () -> servicio.registrar(corta));
        assertThrows(ErroresApi.Validacion.class, () -> servicio.registrar(sinNumero));
    }

    @Test
    void registroSinAceptarTerminosOSinTiendaLanzaValidacion() {
        RegistroRequest sinTerminos = new RegistroRequest("Camila Rojas", "12.345.678-5", "c@rinconsur.cl",
                "Asistente de Probadores", "Clave123", false, 2);
        RegistroRequest sinTienda = new RegistroRequest("Camila Rojas", "12.345.678-5", "c@rinconsur.cl",
                "Asistente de Probadores", "Clave123", true, 0);

        assertThrows(ErroresApi.Validacion.class, () -> servicio.registrar(sinTerminos));
        assertThrows(ErroresApi.Validacion.class, () -> servicio.registrar(sinTienda));
    }

    // ---------- cambio de tienda ----------

    @Test
    void cambiarTiendaActualizaAlAsistente() {
        when(repo.buscarPorId(1L)).thenReturn(Optional.of(usuarioGuardado("ana@rincon.cl", "Clave123")));

        servicio.cambiarTienda(1L, 3);

        verify(repo).actualizarTienda(1L, 3);
    }

    @Test
    void elAdministradorNoTieneTiendaFija() {
        Usuario admin = new Usuario(9, "Admin", "", "admin@rincon.cl", Usuario.CARGO_ADMIN, Usuario.ROL_ADMIN, 0, "hash");
        when(repo.buscarPorId(9L)).thenReturn(Optional.of(admin));

        assertThrows(ErroresApi.Conflicto.class, () -> servicio.cambiarTienda(9L, 2));
        verify(repo, never()).actualizarTienda(9L, 2);
    }

    @Test
    void cambiarTiendaDeUsuarioInexistenteLanzaNoEncontrado() {
        when(repo.buscarPorId(77L)).thenReturn(Optional.empty());

        assertThrows(ErroresApi.NoEncontrado.class, () -> servicio.cambiarTienda(77L, 2));
    }
}
