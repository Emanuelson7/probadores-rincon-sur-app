CREATE TABLE IF NOT EXISTS usuarios (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre    TEXT    NOT NULL,
    rut       TEXT    NOT NULL DEFAULT '',
    correo    TEXT    NOT NULL UNIQUE,
    cargo     TEXT    NOT NULL DEFAULT '',
    rol       TEXT    NOT NULL DEFAULT 'PERSONAL',
    tiendaId  INTEGER NOT NULL DEFAULT 0,
    claveHash TEXT    NOT NULL
);
