package cl.duoc.fitflow.auth.config;

import cl.duoc.fitflow.auth.model.Usuario;
import cl.duoc.fitflow.auth.repository.UsuarioRepository;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Crea las cuentas de prueba la primera vez que se inicia el servicio (datos FICTICIOS).
 * Todas usan la clave "Clave123". Los tiendaId 1, 2 y 3 coinciden con las tiendas que siembra tiendas-service.
 */
@Component
public class SembradorDatos implements ApplicationRunner {

    private final UsuarioRepository repo;
    private final PasswordEncoder encoder;

    public SembradorDatos(UsuarioRepository repo, PasswordEncoder encoder) {
        this.repo = repo;
        this.encoder = encoder;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (repo.contar() > 0) return;
        String hash = encoder.encode("Clave123");
        crear("Administrador Demo", "admin@rincon.cl", Usuario.CARGO_ADMIN, Usuario.ROL_ADMIN, 0, hash);
        crear("Asistente Chicureo", "asistente.chicureo@rincon.cl", "Asistente de Probadores", Usuario.ROL_PERSONAL, 1, hash);
        crear("Asistente Costanera", "asistente.costanera@rincon.cl", "Asistente de Probadores", Usuario.ROL_PERSONAL, 2, hash);
        crear("Asistente Chamisero", "asistente.chamisero@rincon.cl", "Asistente de Probadores", Usuario.ROL_PERSONAL, 3, hash);
    }

    private void crear(String nombre, String correo, String cargo, String rol, int tiendaId, String hash) {
        repo.guardar(new Usuario(0, nombre, "", correo, cargo, rol, tiendaId, hash));
    }
}
