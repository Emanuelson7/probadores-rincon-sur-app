package cl.duoc.fitflow.auth.dto;

/** Datos del formulario de registro. El rol NO viene del cliente: lo decide el servidor según el cargo. */
public record RegistroRequest(
        String nombre,
        String rut,
        String correo,
        String cargo,
        String clave,
        boolean aceptaTerminos,
        int tiendaId
) { }
