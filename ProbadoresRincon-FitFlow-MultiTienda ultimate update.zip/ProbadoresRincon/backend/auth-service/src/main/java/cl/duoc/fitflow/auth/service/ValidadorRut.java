package cl.duoc.fitflow.auth.service;

/** Validación del RUT chileno con el algoritmo módulo 11 (igual que la app Android). */
public final class ValidadorRut {
    private ValidadorRut() { }

    /** Deja solo dígitos y la letra K en mayúscula: "12.345.678-k" -> "12345678K". */
    public static String limpiar(String rut) {
        if (rut == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : rut.toCharArray()) {
            if ((c >= '0' && c <= '9') || c == 'k' || c == 'K') sb.append(Character.toUpperCase(c));
        }
        return sb.toString();
    }

    /** Dígito verificador: cada dígito (de derecha a izquierda) se multiplica por 2,3,4,5,6,7,2,3... */
    public static char calcularDv(String cuerpo) {
        int suma = 0;
        int factor = 2;
        for (int i = cuerpo.length() - 1; i >= 0; i--) {
            suma += (cuerpo.charAt(i) - '0') * factor;
            factor = (factor == 7) ? 2 : factor + 1;
        }
        int resto = 11 - (suma % 11);
        if (resto == 11) return '0';
        if (resto == 10) return 'K';
        return (char) ('0' + resto);
    }

    public static boolean esValido(String rut) {
        String limpio = limpiar(rut);
        if (limpio.length() < 8 || limpio.length() > 9) return false;
        String cuerpo = limpio.substring(0, limpio.length() - 1);
        for (char c : cuerpo.toCharArray()) {
            if (c < '0' || c > '9') return false;
        }
        return calcularDv(cuerpo) == limpio.charAt(limpio.length() - 1);
    }
}
