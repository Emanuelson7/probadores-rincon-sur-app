package cl.duoc.fitflow.auth.controller;

import cl.duoc.fitflow.auth.dto.CambiarTiendaRequest;
import cl.duoc.fitflow.auth.dto.LoginRequest;
import cl.duoc.fitflow.auth.dto.Mensaje;
import cl.duoc.fitflow.auth.dto.RegistroRequest;
import cl.duoc.fitflow.auth.dto.UsuarioResponse;
import cl.duoc.fitflow.auth.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * API REST de autenticación (puerto 8081):
 *   POST /api/auth/login            -> 200 usuario | 401 credenciales inválidas
 *   POST /api/auth/registro         -> 201 usuario | 400 datos inválidos | 409 correo repetido
 *   PUT  /api/usuarios/{id}/tienda  -> 200 (recuerda la tienda del asistente)
 *   GET  /api/auth/ping             -> 200 (para comprobar que el servicio está arriba)
 */
@RestController
@RequestMapping("/api")
public class AuthController {

    private final AuthService servicio;

    public AuthController(AuthService servicio) {
        this.servicio = servicio;
    }

    @PostMapping("/auth/login")
    public UsuarioResponse login(@RequestBody LoginRequest peticion) {
        return UsuarioResponse.de(servicio.login(peticion.correo(), peticion.clave()));
    }

    @PostMapping("/auth/registro")
    @ResponseStatus(HttpStatus.CREATED)
    public UsuarioResponse registro(@RequestBody RegistroRequest peticion) {
        return UsuarioResponse.de(servicio.registrar(peticion));
    }

    @PutMapping("/usuarios/{id}/tienda")
    public Mensaje cambiarTienda(@PathVariable long id, @RequestBody CambiarTiendaRequest peticion) {
        servicio.cambiarTienda(id, peticion.tiendaId());
        return new Mensaje("Tienda actualizada");
    }

    @GetMapping("/auth/ping")
    public Mensaje ping() {
        return new Mensaje("auth-service ok");
    }
}
