package cl.duoc.fitflow.auth.model;

/**
 * Usuario del sistema. Un "record" es una clase inmutable con constructor, getters
 * (id(), nombre()...), equals y toString generados automáticamente.
 *
 * rol: "ADMIN" (entra a todas las tiendas) o "PERSONAL" (asistente de una tienda).
 * tiendaId: tienda donde trabaja el asistente (0 para el administrador).
 */
public record Usuario(
        long id,
        String nombre,
        String rut,
        String correo,
        String cargo,
        String rol,
        int tiendaId,
        String claveHash
) {
    public static final String ROL_ADMIN = "ADMIN";
    public static final String ROL_PERSONAL = "PERSONAL";
    public static final String CARGO_ADMIN = "Jefe/a de Tienda (Administrador)";
}
