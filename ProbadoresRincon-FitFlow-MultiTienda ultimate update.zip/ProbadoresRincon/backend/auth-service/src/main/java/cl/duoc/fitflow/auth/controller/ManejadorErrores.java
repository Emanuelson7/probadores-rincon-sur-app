package cl.duoc.fitflow.auth.controller;

import cl.duoc.fitflow.auth.dto.Mensaje;
import cl.duoc.fitflow.auth.service.ErroresApi;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/** Traduce las excepciones de negocio a respuestas HTTP con un mensaje claro. */
@RestControllerAdvice
public class ManejadorErrores {

    @ExceptionHandler(ErroresApi.Validacion.class)
    public ResponseEntity<Mensaje> validacion(ErroresApi.Validacion e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Mensaje(e.getMessage()));
    }

    @ExceptionHandler(ErroresApi.CredencialesInvalidas.class)
    public ResponseEntity<Mensaje> credenciales(ErroresApi.CredencialesInvalidas e) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new Mensaje(e.getMessage()));
    }

    @ExceptionHandler(ErroresApi.NoEncontrado.class)
    public ResponseEntity<Mensaje> noEncontrado(ErroresApi.NoEncontrado e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Mensaje(e.getMessage()));
    }

    @ExceptionHandler(ErroresApi.Conflicto.class)
    public ResponseEntity<Mensaje> conflicto(ErroresApi.Conflicto e) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(new Mensaje(e.getMessage()));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Mensaje> cuerpoInvalido(HttpMessageNotReadableException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Mensaje("El cuerpo de la petición no es válido"));
    }
}
