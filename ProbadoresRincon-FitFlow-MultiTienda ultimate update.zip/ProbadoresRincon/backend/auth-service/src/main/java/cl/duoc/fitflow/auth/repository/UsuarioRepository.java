package cl.duoc.fitflow.auth.repository;

import cl.duoc.fitflow.auth.model.Usuario;

import java.util.Optional;

/**
 * Contrato de acceso a datos de usuarios. El servicio depende de esta interfaz,
 * no de SQLite: así en las pruebas unitarias se reemplaza por un "mock".
 */
public interface UsuarioRepository {
    Optional<Usuario> buscarPorCorreo(String correo);

    Optional<Usuario> buscarPorId(long id);

    /** Inserta un usuario nuevo y devuelve el mismo usuario con su id asignado. */
    Usuario guardar(Usuario nuevo);

    void actualizarTienda(long id, int tiendaId);

    long contar();
}
