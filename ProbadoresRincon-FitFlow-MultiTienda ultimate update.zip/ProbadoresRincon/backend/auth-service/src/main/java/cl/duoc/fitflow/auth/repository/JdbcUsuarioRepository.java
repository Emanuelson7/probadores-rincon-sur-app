package cl.duoc.fitflow.auth.repository;

import cl.duoc.fitflow.auth.model.Usuario;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Optional;

/** Implementación con SQLite usando JdbcTemplate (SQL escrito a mano, sin ORM). */
@Repository
public class JdbcUsuarioRepository implements UsuarioRepository {

    private static final RowMapper<Usuario> MAPEO = (rs, fila) -> new Usuario(
            rs.getLong("id"),
            rs.getString("nombre"),
            rs.getString("rut"),
            rs.getString("correo"),
            rs.getString("cargo"),
            rs.getString("rol"),
            rs.getInt("tiendaId"),
            rs.getString("claveHash")
    );

    private final JdbcTemplate jdbc;

    public JdbcUsuarioRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public Optional<Usuario> buscarPorCorreo(String correo) {
        return jdbc.query("SELECT * FROM usuarios WHERE correo = ?", MAPEO, correo).stream().findFirst();
    }

    @Override
    public Optional<Usuario> buscarPorId(long id) {
        return jdbc.query("SELECT * FROM usuarios WHERE id = ?", MAPEO, id).stream().findFirst();
    }

    @Override
    public Usuario guardar(Usuario u) {
        KeyHolder llave = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO usuarios (nombre, rut, correo, cargo, rol, tiendaId, claveHash) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, u.nombre());
            ps.setString(2, u.rut());
            ps.setString(3, u.correo());
            ps.setString(4, u.cargo());
            ps.setString(5, u.rol());
            ps.setInt(6, u.tiendaId());
            ps.setString(7, u.claveHash());
            return ps;
        }, llave);
        long id = llave.getKey().longValue();
        return new Usuario(id, u.nombre(), u.rut(), u.correo(), u.cargo(), u.rol(), u.tiendaId(), u.claveHash());
    }

    @Override
    public void actualizarTienda(long id, int tiendaId) {
        jdbc.update("UPDATE usuarios SET tiendaId = ? WHERE id = ?", tiendaId, id);
    }

    @Override
    public long contar() {
        Long total = jdbc.queryForObject("SELECT COUNT(*) FROM usuarios", Long.class);
        return total == null ? 0 : total;
    }
}
