package cl.duoc.fitflow.auth.dto;

import cl.duoc.fitflow.auth.model.Usuario;

/** Lo que ve el cliente de un usuario: NUNCA incluye la clave ni su hash. */
public record UsuarioResponse(
        long id,
        String nombre,
        String rut,
        String correo,
        String cargo,
        String rol,
        int tiendaId
) {
    public static UsuarioResponse de(Usuario u) {
        return new UsuarioResponse(u.id(), u.nombre(), u.rut(), u.correo(), u.cargo(), u.rol(), u.tiendaId());
    }
}
