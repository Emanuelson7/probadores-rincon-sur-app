package cl.duoc.fitflow.auth.dto;

public record CambiarTiendaRequest(int tiendaId) { }
