package cl.duoc.fitflow.auth.service;

import cl.duoc.fitflow.auth.dto.RegistroRequest;
import cl.duoc.fitflow.auth.model.Usuario;
import cl.duoc.fitflow.auth.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.regex.Pattern;

/** Reglas de negocio de autenticación: login, registro y cambio de tienda. */
@Service
public class AuthService {

    private static final Pattern CORREO =
            Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    static final int LARGO_MIN_CLAVE = 8;

    private final UsuarioRepository repo;
    private final PasswordEncoder encoder;

    public AuthService(UsuarioRepository repo, PasswordEncoder encoder) {
        this.repo = repo;
        this.encoder = encoder;
    }

    /** Devuelve el usuario si el correo y la clave coinciden; si no, lanza CredencialesInvalidas (401). */
    public Usuario login(String correo, String clave) {
        if (correo == null || correo.isBlank() || clave == null || clave.isBlank()) {
            throw new ErroresApi.Validacion("Correo y contraseña son obligatorios");
        }
        Usuario usuario = repo.buscarPorCorreo(correo.trim().toLowerCase())
                .orElseThrow(ErroresApi.CredencialesInvalidas::new);
        // matches() compara la clave escrita con el hash BCrypt guardado: la clave real nunca se guarda.
        if (!encoder.matches(clave, usuario.claveHash())) {
            throw new ErroresApi.CredencialesInvalidas();
        }
        return usuario;
    }

    public Usuario registrar(RegistroRequest r) {
        if (r == null) throw new ErroresApi.Validacion("Faltan los datos del registro");
        if (r.nombre() == null || r.nombre().trim().length() < 3) {
            throw new ErroresApi.Validacion("El nombre debe tener al menos 3 caracteres");
        }
        if (!ValidadorRut.esValido(r.rut())) {
            throw new ErroresApi.Validacion("RUT inválido, revisa el dígito verificador");
        }
        if (r.correo() == null || !CORREO.matcher(r.correo().trim()).matches()) {
            throw new ErroresApi.Validacion("Ingresa un correo válido (ej: nombre@correo.com)");
        }
        if (r.cargo() == null || r.cargo().isBlank()) {
            throw new ErroresApi.Validacion("Selecciona un cargo");
        }
        validarClave(r.clave());
        if (!r.aceptaTerminos()) {
            throw new ErroresApi.Validacion("Debes aceptar los términos");
        }

        // El rol lo decide el servidor según el cargo: el cliente no puede mandar "ADMIN" por su cuenta.
        boolean admin = Usuario.CARGO_ADMIN.equals(r.cargo().trim());
        String rol = admin ? Usuario.ROL_ADMIN : Usuario.ROL_PERSONAL;
        int tiendaId = admin ? 0 : r.tiendaId();
        if (!admin && tiendaId <= 0) {
            throw new ErroresApi.Validacion("Selecciona una tienda");
        }

        String correo = r.correo().trim().toLowerCase();
        if (repo.buscarPorCorreo(correo).isPresent()) {
            throw new ErroresApi.Conflicto("Ese correo ya está registrado");
        }
        Usuario nuevo = new Usuario(0, r.nombre().trim(), r.rut().trim(), correo, r.cargo().trim(),
                rol, tiendaId, encoder.encode(r.clave()));
        return repo.guardar(nuevo);
    }

    /** Recuerda la tienda donde trabaja el asistente. El administrador no tiene tienda fija. */
    public void cambiarTienda(long usuarioId, int tiendaId) {
        if (tiendaId <= 0) throw new ErroresApi.Validacion("Tienda inválida");
        Usuario usuario = repo.buscarPorId(usuarioId)
                .orElseThrow(() -> new ErroresApi.NoEncontrado("Usuario no encontrado"));
        if (Usuario.ROL_ADMIN.equals(usuario.rol())) {
            throw new ErroresApi.Conflicto("El administrador entra a todas las tiendas");
        }
        repo.actualizarTienda(usuarioId, tiendaId);
    }

    private void validarClave(String clave) {
        if (clave == null || clave.isBlank()) {
            throw new ErroresApi.Validacion("La contraseña es obligatoria");
        }
        if (clave.length() < LARGO_MIN_CLAVE) {
            throw new ErroresApi.Validacion("Debe tener al menos " + LARGO_MIN_CLAVE + " caracteres");
        }
        if (clave.chars().noneMatch(Character::isDigit)) {
            throw new ErroresApi.Validacion("Debe incluir al menos un número");
        }
        if (clave.chars().noneMatch(Character::isLetter)) {
            throw new ErroresApi.Validacion("Debe incluir al menos una letra");
        }
    }
}
