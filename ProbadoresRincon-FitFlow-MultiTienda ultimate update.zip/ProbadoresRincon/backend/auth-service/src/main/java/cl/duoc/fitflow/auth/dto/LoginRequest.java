package cl.duoc.fitflow.auth.dto;

public record LoginRequest(String correo, String clave) { }
