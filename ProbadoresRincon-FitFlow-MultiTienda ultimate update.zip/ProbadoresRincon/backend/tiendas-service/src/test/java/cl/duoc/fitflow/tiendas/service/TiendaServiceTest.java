package cl.duoc.fitflow.tiendas.service;

import cl.duoc.fitflow.tiendas.model.Probador;
import cl.duoc.fitflow.tiendas.model.Tienda;
import cl.duoc.fitflow.tiendas.model.TiendaResumen;
import cl.duoc.fitflow.tiendas.repository.TiendaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Pruebas unitarias de las reglas de negocio: el repositorio es un mock y el reloj es fijo. */
@ExtendWith(MockitoExtension.class)
class TiendaServiceTest {

    private static final long AHORA = 1_000_000L;

    @Mock
    private TiendaRepository repo;

    private TiendaService servicio;

    @BeforeEach
    void preparar() {
        Clock relojFijo = Clock.fixed(Instant.ofEpochMilli(AHORA), ZoneOffset.UTC);
        servicio = new TiendaService(repo, relojFijo);
    }

    private Probador probador(long id, boolean ocupado, String estadoServicio) {
        return new Probador(id, 1, 3, ocupado, ocupado ? 500L : null, "nota", estadoServicio, "");
    }

    private void existeProbador(Probador p) {
        when(repo.buscarProbador(p.id())).thenReturn(Optional.of(p));
    }

    private void existeTienda(long id) {
        when(repo.buscarTienda(id)).thenReturn(Optional.of(new Tienda(id, "Jumbo Test")));
    }

    // ---------- crear tienda ----------

    @Test
    void crearTiendaCreaConfiguracionFilaYProbadoresNumerados() {
        when(repo.buscarTiendaPorNombre("Jumbo Vitacura")).thenReturn(Optional.empty());
        when(repo.crearTienda("Jumbo Vitacura")).thenReturn(7L);

        TiendaResumen resultado = servicio.crearTienda("  Jumbo Vitacura ", 3);   // el nombre se recorta

        assertEquals(7L, resultado.id());
        assertEquals(3, resultado.total());
        verify(repo).insertarProbador(7L, 1);
        verify(repo).insertarProbador(7L, 2);
        verify(repo).insertarProbador(7L, 3);
        verify(repo).guardarTiempoLimite(7L, 15);
        verify(repo).guardarFila(7L, 0);
    }

    @Test
    void crearTiendaConNombreRepetidoLanzaConflicto() {
        when(repo.buscarTiendaPorNombre("Jumbo Chicureo")).thenReturn(Optional.of(new Tienda(1, "Jumbo Chicureo")));

        assertThrows(ErroresApi.Conflicto.class, () -> servicio.crearTienda("Jumbo Chicureo", 5));
        verify(repo, never()).crearTienda(any());
    }

    @Test
    void crearTiendaValidaNombreYCantidad() {
        assertThrows(ErroresApi.Validacion.class, () -> servicio.crearTienda("ab", 5));
        assertThrows(ErroresApi.Validacion.class, () -> servicio.crearTienda(null, 5));
        assertThrows(ErroresApi.Validacion.class, () -> servicio.crearTienda("Jumbo Nuevo", 0));
        assertThrows(ErroresApi.Validacion.class, () -> servicio.crearTienda("Jumbo Nuevo", 31));
        verify(repo, never()).crearTienda(any());
    }

    // ---------- ocupar y liberar ----------

    @Test
    void ocuparUnProbadorLibreGuardaLaHoraDeInicio() {
        existeProbador(probador(5, false, "ACTIVO"));

        Probador resultado = servicio.ocupar(5);

        assertTrue(resultado.ocupado());
        assertEquals(AHORA, resultado.horaInicio());
        verify(repo).actualizarProbador(resultado);
    }

    @Test
    void noSePuedeOcuparUnProbadorEnReparacionONoDisponible() {
        existeProbador(probador(5, false, "EN_REPARACION"));
        existeProbador(probador(6, false, "NO_DISPONIBLE"));

        assertThrows(ErroresApi.Conflicto.class, () -> servicio.ocupar(5));
        assertThrows(ErroresApi.Conflicto.class, () -> servicio.ocupar(6));
        verify(repo, never()).actualizarProbador(any());
    }

    @Test
    void ocuparUnProbadorYaOcupadoNoCambiaNada() {
        existeProbador(probador(5, true, "ACTIVO"));

        Probador resultado = servicio.ocupar(5);

        assertEquals(500L, resultado.horaInicio());          // conserva la hora original
        verify(repo, never()).actualizarProbador(any());
    }

    @Test
    void liberarLimpiaElUsoYLaNota() {
        existeProbador(probador(5, true, "ACTIVO"));

        Probador resultado = servicio.liberar(5);

        assertFalse(resultado.ocupado());
        assertNull(resultado.horaInicio());
        assertEquals("", resultado.nota());
    }

    @Test
    void probadorInexistenteLanzaNoEncontrado() {
        when(repo.buscarProbador(99L)).thenReturn(Optional.empty());

        assertThrows(ErroresApi.NoEncontrado.class, () -> servicio.ocupar(99));
    }

    // ---------- estado de servicio ----------

    @Test
    void ponerFueraDeServicioExigeMotivo() {
        existeProbador(probador(5, false, "ACTIVO"));

        assertThrows(ErroresApi.Validacion.class, () -> servicio.cambiarServicio(5, "EN_REPARACION", ""));
        assertThrows(ErroresApi.Validacion.class, () -> servicio.cambiarServicio(5, "NO_DISPONIBLE", "  "));
        verify(repo, never()).actualizarProbador(any());
    }

    @Test
    void ponerFueraDeServicioGuardaEstadoYMotivo() {
        existeProbador(probador(5, false, "ACTIVO"));

        Probador resultado = servicio.cambiarServicio(5, "EN_REPARACION", " Puerta dañada ");

        assertEquals("EN_REPARACION", resultado.estadoServicio());
        assertEquals("Puerta dañada", resultado.motivoServicio());
        verify(repo).actualizarProbador(resultado);
    }

    @Test
    void noSePuedeDejarFueraDeServicioUnProbadorOcupado() {
        existeProbador(probador(5, true, "ACTIVO"));

        assertThrows(ErroresApi.Conflicto.class, () -> servicio.cambiarServicio(5, "EN_REPARACION", "Espejo roto"));
        verify(repo, never()).actualizarProbador(any());
    }

    @Test
    void volverAOperativoLimpiaElMotivo() {
        existeProbador(new Probador(5, 1, 3, false, null, "", "EN_REPARACION", "Puerta dañada"));

        Probador resultado = servicio.cambiarServicio(5, "ACTIVO", "ignorado");

        assertEquals("ACTIVO", resultado.estadoServicio());
        assertEquals("", resultado.motivoServicio());
    }

    @Test
    void unEstadoDeServicioDesconocidoLanzaValidacion() {
        existeProbador(probador(5, false, "ACTIVO"));

        assertThrows(ErroresApi.Validacion.class, () -> servicio.cambiarServicio(5, "ROTO", "algo"));
    }

    // ---------- agregar y eliminar probadores ----------

    @Test
    void agregarProbadorUsaElSiguienteNumero() {
        existeTienda(1L);
        when(repo.maxNumero(1L)).thenReturn(8);

        servicio.agregarProbador(1L);

        verify(repo).insertarProbador(1L, 9);
    }

    @Test
    void agregarProbadorEnTiendaInexistenteLanzaNoEncontrado() {
        when(repo.buscarTienda(42L)).thenReturn(Optional.empty());

        assertThrows(ErroresApi.NoEncontrado.class, () -> servicio.agregarProbador(42L));
        verify(repo, never()).insertarProbador(anyLong(), anyInt());
    }

    @Test
    void noSePuedeEliminarUnProbadorOcupado() {
        existeProbador(probador(5, true, "ACTIVO"));

        assertThrows(ErroresApi.Conflicto.class, () -> servicio.eliminarProbador(5));
        verify(repo, never()).eliminarProbador(anyLong());
    }

    @Test
    void eliminarUnProbadorLibreLoBorra() {
        existeProbador(probador(5, false, "ACTIVO"));

        servicio.eliminarProbador(5);

        verify(repo).eliminarProbador(5L);
    }

    // ---------- configuración y fila ----------

    @Test
    void elTiempoLimiteDebeEstarEntre1Y120Minutos() {
        assertThrows(ErroresApi.Validacion.class, () -> servicio.guardarTiempoLimite(1L, 0));
        assertThrows(ErroresApi.Validacion.class, () -> servicio.guardarTiempoLimite(1L, 121));
        verify(repo, never()).guardarTiempoLimite(anyLong(), anyInt());
    }

    @Test
    void guardaElTiempoLimiteValido() {
        existeTienda(1L);

        assertEquals(20, servicio.guardarTiempoLimite(1L, 20));

        verify(repo).guardarTiempoLimite(1L, 20);
    }

    @Test
    void laFilaDeEsperaNuncaQuedaNegativa() {
        existeTienda(1L);
        when(repo.clientesEsperando(1L)).thenReturn(0);

        assertEquals(0, servicio.cambiarFila(1L, -1));

        verify(repo).guardarFila(1L, 0);
    }

    @Test
    void laFilaDeEsperaSumaClientes() {
        existeTienda(1L);
        when(repo.clientesEsperando(1L)).thenReturn(2);

        assertEquals(3, servicio.cambiarFila(1L, +1));

        verify(repo).guardarFila(1L, 3);
    }
}
