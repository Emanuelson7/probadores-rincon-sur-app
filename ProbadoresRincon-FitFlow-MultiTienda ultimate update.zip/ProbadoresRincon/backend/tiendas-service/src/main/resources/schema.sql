CREATE TABLE IF NOT EXISTS tiendas (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS probadores (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tiendaId        INTEGER NOT NULL,
    numero          INTEGER NOT NULL,
    ocupado         INTEGER NOT NULL DEFAULT 0,
    horaInicio      INTEGER,
    nota            TEXT    NOT NULL DEFAULT '',
    estadoServicio  TEXT    NOT NULL DEFAULT 'ACTIVO',
    motivoServicio  TEXT    NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS configuracion (
    tiendaId        INTEGER PRIMARY KEY,
    tiempoLimiteMin INTEGER NOT NULL DEFAULT 15
);

CREATE TABLE IF NOT EXISTS fila (
    tiendaId          INTEGER PRIMARY KEY,
    clientesEsperando INTEGER NOT NULL DEFAULT 0
);
