package cl.duoc.fitflow.tiendas.controller;

import cl.duoc.fitflow.tiendas.dto.ConfiguracionDto;
import cl.duoc.fitflow.tiendas.dto.CrearTiendaRequest;
import cl.duoc.fitflow.tiendas.dto.FilaDeltaRequest;
import cl.duoc.fitflow.tiendas.dto.FilaDto;
import cl.duoc.fitflow.tiendas.dto.Mensaje;
import cl.duoc.fitflow.tiendas.model.Probador;
import cl.duoc.fitflow.tiendas.model.TiendaResumen;
import cl.duoc.fitflow.tiendas.service.TiendaService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * API REST de tiendas (puerto 8082):
 *   GET  /api/tiendas                       lista de tiendas con su resumen
 *   POST /api/tiendas                       crea una tienda con N probadores        (201 | 400 | 409)
 *   GET  /api/tiendas/{id}/probadores       probadores de la tienda                 (200 | 404)
 *   POST /api/tiendas/{id}/probadores       agrega un probador                      (201 | 404)
 *   GET/PUT /api/tiendas/{id}/configuracion tiempo límite de uso                    (200 | 400 | 404)
 *   GET/POST /api/tiendas/{id}/fila         clientes esperando (POST suma o resta)  (200 | 404)
 */
@RestController
@RequestMapping("/api/tiendas")
public class TiendaController {

    private final TiendaService servicio;

    public TiendaController(TiendaService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public List<TiendaResumen> listar() {
        return servicio.listarTiendas();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TiendaResumen crear(@RequestBody CrearTiendaRequest peticion) {
        return servicio.crearTienda(peticion.nombre(), peticion.cantidadProbadores());
    }

    @GetMapping("/{id}/probadores")
    public List<Probador> probadores(@PathVariable long id) {
        return servicio.listarProbadores(id);
    }

    @PostMapping("/{id}/probadores")
    @ResponseStatus(HttpStatus.CREATED)
    public Probador agregarProbador(@PathVariable long id) {
        return servicio.agregarProbador(id);
    }

    @GetMapping("/{id}/configuracion")
    public ConfiguracionDto configuracion(@PathVariable long id) {
        return new ConfiguracionDto(servicio.tiempoLimite(id));
    }

    @PutMapping("/{id}/configuracion")
    public ConfiguracionDto guardarConfiguracion(@PathVariable long id, @RequestBody ConfiguracionDto peticion) {
        return new ConfiguracionDto(servicio.guardarTiempoLimite(id, peticion.tiempoLimiteMin()));
    }

    @GetMapping("/{id}/fila")
    public FilaDto fila(@PathVariable long id) {
        return new FilaDto(servicio.clientesEsperando(id));
    }

    @PostMapping("/{id}/fila")
    public FilaDto cambiarFila(@PathVariable long id, @RequestBody FilaDeltaRequest peticion) {
        return new FilaDto(servicio.cambiarFila(id, peticion.delta()));
    }

    @GetMapping("/ping")
    public Mensaje ping() {
        return new Mensaje("tiendas-service ok");
    }
}
