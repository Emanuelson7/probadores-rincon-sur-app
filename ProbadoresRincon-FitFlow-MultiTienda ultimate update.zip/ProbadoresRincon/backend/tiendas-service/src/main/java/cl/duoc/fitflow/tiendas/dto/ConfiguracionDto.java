package cl.duoc.fitflow.tiendas.dto;

public record ConfiguracionDto(int tiempoLimiteMin) { }
