package cl.duoc.fitflow.tiendas.dto;

/** delta = +1 (llega un cliente) o -1 (se atiende uno). */
public record FilaDeltaRequest(int delta) { }
