package cl.duoc.fitflow.tiendas.repository;

import cl.duoc.fitflow.tiendas.model.Probador;
import cl.duoc.fitflow.tiendas.model.Tienda;
import cl.duoc.fitflow.tiendas.model.TiendaResumen;

import java.util.List;
import java.util.Optional;

/**
 * Contrato de acceso a datos. El servicio depende de esta interfaz, no de SQLite:
 * así en las pruebas unitarias se reemplaza por un "mock".
 */
public interface TiendaRepository {
    // --- tiendas ---
    List<TiendaResumen> listarResumen();
    Optional<Tienda> buscarTienda(long id);
    Optional<Tienda> buscarTiendaPorNombre(String nombre);
    long crearTienda(String nombre);
    long contarTiendas();

    // --- probadores ---
    List<Probador> listarProbadores(long tiendaId);
    Optional<Probador> buscarProbador(long id);
    Probador insertarProbador(long tiendaId, int numero);
    /** Mayor número de probador de la tienda (0 si no tiene ninguno). */
    int maxNumero(long tiendaId);
    void actualizarProbador(Probador probador);
    void eliminarProbador(long id);

    // --- configuración y fila (una por tienda) ---
    int tiempoLimite(long tiendaId);
    void guardarTiempoLimite(long tiendaId, int minutos);
    int clientesEsperando(long tiendaId);
    void guardarFila(long tiendaId, int clientes);
}
