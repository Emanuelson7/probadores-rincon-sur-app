package cl.duoc.fitflow.tiendas.model;

/**
 * Un probador de una tienda. Inmutable: para "cambiarlo" se crea una copia con los métodos con...().
 * horaInicio: momento (milisegundos desde 1970) en que se ocupó; null si está libre.
 */
public record Probador(
        long id,
        long tiendaId,
        int numero,
        boolean ocupado,
        Long horaInicio,
        String nota,
        String estadoServicio,
        String motivoServicio
) {
    public Probador conUso(boolean ocupado, Long horaInicio, String nota) {
        return new Probador(id, tiendaId, numero, ocupado, horaInicio, nota, estadoServicio, motivoServicio);
    }

    public Probador conNota(String nota) {
        return new Probador(id, tiendaId, numero, ocupado, horaInicio, nota, estadoServicio, motivoServicio);
    }

    public Probador conServicio(String estadoServicio, String motivoServicio) {
        return new Probador(id, tiendaId, numero, ocupado, horaInicio, nota, estadoServicio, motivoServicio);
    }
}
