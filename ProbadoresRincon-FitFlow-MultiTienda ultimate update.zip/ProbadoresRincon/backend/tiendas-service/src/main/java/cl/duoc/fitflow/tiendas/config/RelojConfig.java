package cl.duoc.fitflow.tiendas.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;

@Configuration
public class RelojConfig {
    /** Reloj del sistema. Se inyecta (en vez de llamar a System.currentTimeMillis) para poder probar el servicio. */
    @Bean
    public Clock reloj() {
        return Clock.systemUTC();
    }
}
