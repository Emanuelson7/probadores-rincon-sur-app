package cl.duoc.fitflow.tiendas.model;

/** Estado de servicio de un probador (lo define el administrador). */
public enum EstadoServicio {
    ACTIVO,
    EN_REPARACION,
    NO_DISPONIBLE;

    /** Convierte el texto recibido; devuelve null si no corresponde a ningún estado. */
    public static EstadoServicio desde(String texto) {
        if (texto == null) return null;
        for (EstadoServicio e : values()) {
            if (e.name().equals(texto.trim())) return e;
        }
        return null;
    }
}
