package cl.duoc.fitflow.tiendas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Punto de entrada del microservicio de tiendas y probadores. */
@SpringBootApplication
public class TiendasServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(TiendasServiceApplication.class, args);
    }
}
