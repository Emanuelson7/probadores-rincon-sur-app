package cl.duoc.fitflow.tiendas.dto;

public record CrearTiendaRequest(String nombre, int cantidadProbadores) { }
