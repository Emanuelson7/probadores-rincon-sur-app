package cl.duoc.fitflow.tiendas.dto;

public record NotaRequest(String nota) { }
