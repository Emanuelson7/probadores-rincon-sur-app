package cl.duoc.fitflow.tiendas.dto;

public record FilaDto(int clientesEsperando) { }
