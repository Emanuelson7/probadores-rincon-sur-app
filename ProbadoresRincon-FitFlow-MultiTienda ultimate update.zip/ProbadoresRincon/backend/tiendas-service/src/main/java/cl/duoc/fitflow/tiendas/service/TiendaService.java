package cl.duoc.fitflow.tiendas.service;

import cl.duoc.fitflow.tiendas.model.EstadoServicio;
import cl.duoc.fitflow.tiendas.model.Probador;
import cl.duoc.fitflow.tiendas.model.TiendaResumen;
import cl.duoc.fitflow.tiendas.repository.TiendaRepository;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.util.List;

/**
 * Reglas de negocio de tiendas y probadores. Las mismas reglas que aplica la app Android,
 * pero ahora el servidor es la fuente de verdad.
 */
@Service
public class TiendaService {

    static final int TIEMPO_LIMITE_POR_DEFECTO = 15;

    private final TiendaRepository repo;
    /** Reloj inyectado: en las pruebas se reemplaza por uno fijo para poder comprobar la hora de inicio. */
    private final Clock reloj;

    public TiendaService(TiendaRepository repo, Clock reloj) {
        this.repo = repo;
        this.reloj = reloj;
    }

    // ---------------- tiendas ----------------

    public List<TiendaResumen> listarTiendas() {
        return repo.listarResumen();
    }

    public TiendaResumen crearTienda(String nombre, int cantidadProbadores) {
        String limpio = nombre == null ? "" : nombre.trim();
        if (limpio.length() < 3 || limpio.length() > 40) {
            throw new ErroresApi.Validacion("El nombre debe tener entre 3 y 40 caracteres");
        }
        if (cantidadProbadores < 1 || cantidadProbadores > 30) {
            throw new ErroresApi.Validacion("La cantidad de probadores debe estar entre 1 y 30");
        }
        if (repo.buscarTiendaPorNombre(limpio).isPresent()) {
            throw new ErroresApi.Conflicto("Ya existe una tienda con ese nombre");
        }
        long id = repo.crearTienda(limpio);
        // Cada tienda nace con su configuración, su fila de espera y sus probadores numerados 1..N.
        repo.guardarTiempoLimite(id, TIEMPO_LIMITE_POR_DEFECTO);
        repo.guardarFila(id, 0);
        for (int numero = 1; numero <= cantidadProbadores; numero++) {
            repo.insertarProbador(id, numero);
        }
        return new TiendaResumen(id, limpio, cantidadProbadores, 0);
    }

    // ---------------- probadores ----------------

    public List<Probador> listarProbadores(long tiendaId) {
        exigirTienda(tiendaId);
        return repo.listarProbadores(tiendaId);
    }

    public Probador agregarProbador(long tiendaId) {
        exigirTienda(tiendaId);
        return repo.insertarProbador(tiendaId, repo.maxNumero(tiendaId) + 1);
    }

    /** Marca el probador como ocupado y guarda la hora de inicio (la toma el servidor). */
    public Probador ocupar(long id) {
        Probador p = obtenerProbador(id);
        // Un probador en reparación o no disponible no se puede ocupar.
        if (!EstadoServicio.ACTIVO.name().equals(p.estadoServicio())) {
            throw new ErroresApi.Conflicto("El probador está fuera de servicio");
        }
        if (p.ocupado()) return p;
        Probador actualizado = p.conUso(true, reloj.millis(), p.nota());
        repo.actualizarProbador(actualizado);
        return actualizado;
    }

    public Probador liberar(long id) {
        Probador p = obtenerProbador(id);
        Probador actualizado = p.conUso(false, null, "");
        repo.actualizarProbador(actualizado);
        return actualizado;
    }

    /** Cambia el estado de servicio (operativo / en reparación / no disponible) con su motivo. */
    public Probador cambiarServicio(long id, String estadoTexto, String motivo) {
        Probador p = obtenerProbador(id);
        EstadoServicio estado = EstadoServicio.desde(estadoTexto);
        if (estado == null) {
            throw new ErroresApi.Validacion("Estado de servicio inválido");
        }
        String motivoFinal = "";
        if (estado != EstadoServicio.ACTIVO) {
            motivoFinal = motivo == null ? "" : motivo.trim();
            if (motivoFinal.length() < 3) {
                throw new ErroresApi.Validacion("Indica el motivo (mínimo 3 caracteres)");
            }
            if (motivoFinal.length() > 100) {
                throw new ErroresApi.Validacion("El motivo admite máximo 100 caracteres");
            }
            if (p.ocupado()) {
                throw new ErroresApi.Conflicto("Primero libera el probador (está ocupado)");
            }
        }
        Probador actualizado = p.conServicio(estado.name(), motivoFinal);
        repo.actualizarProbador(actualizado);
        return actualizado;
    }

    public Probador guardarNota(long id, String nota) {
        Probador p = obtenerProbador(id);
        String limpia = nota == null ? "" : nota.trim();
        if (limpia.length() > 200) {
            throw new ErroresApi.Validacion("La nota admite máximo 200 caracteres");
        }
        Probador actualizado = p.conNota(limpia);
        repo.actualizarProbador(actualizado);
        return actualizado;
    }

    public void eliminarProbador(long id) {
        Probador p = obtenerProbador(id);
        if (p.ocupado()) {
            throw new ErroresApi.Conflicto("No se puede eliminar un probador ocupado");
        }
        repo.eliminarProbador(id);
    }

    // ---------------- configuración y fila ----------------

    public int tiempoLimite(long tiendaId) {
        exigirTienda(tiendaId);
        return repo.tiempoLimite(tiendaId);
    }

    public int guardarTiempoLimite(long tiendaId, int minutos) {
        if (minutos < 1 || minutos > 120) {
            throw new ErroresApi.Validacion("El tiempo límite debe estar entre 1 y 120 minutos");
        }
        exigirTienda(tiendaId);
        repo.guardarTiempoLimite(tiendaId, minutos);
        return minutos;
    }

    public int clientesEsperando(long tiendaId) {
        exigirTienda(tiendaId);
        return repo.clientesEsperando(tiendaId);
    }

    /** Suma o resta clientes a la fila. Nunca queda negativa. */
    public int cambiarFila(long tiendaId, int delta) {
        exigirTienda(tiendaId);
        int nuevo = Math.max(0, repo.clientesEsperando(tiendaId) + delta);
        repo.guardarFila(tiendaId, nuevo);
        return nuevo;
    }

    // ---------------- auxiliares ----------------

    private void exigirTienda(long tiendaId) {
        if (repo.buscarTienda(tiendaId).isEmpty()) {
            throw new ErroresApi.NoEncontrado("Tienda no encontrada");
        }
    }

    private Probador obtenerProbador(long id) {
        return repo.buscarProbador(id).orElseThrow(() -> new ErroresApi.NoEncontrado("Probador no encontrado"));
    }
}
