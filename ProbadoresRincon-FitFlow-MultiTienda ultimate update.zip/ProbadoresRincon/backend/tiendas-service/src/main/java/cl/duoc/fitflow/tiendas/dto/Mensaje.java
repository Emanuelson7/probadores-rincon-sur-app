package cl.duoc.fitflow.tiendas.dto;

/** Respuesta simple {"mensaje": "..."}: se usa para errores y confirmaciones. */
public record Mensaje(String mensaje) { }
