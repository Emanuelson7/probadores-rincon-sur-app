package cl.duoc.fitflow.tiendas.model;

public record Tienda(long id, String nombre) { }
