package cl.duoc.fitflow.tiendas.dto;

/** estado: ACTIVO, EN_REPARACION o NO_DISPONIBLE. El motivo es obligatorio si no es ACTIVO. */
public record ServicioRequest(String estado, String motivo) { }
