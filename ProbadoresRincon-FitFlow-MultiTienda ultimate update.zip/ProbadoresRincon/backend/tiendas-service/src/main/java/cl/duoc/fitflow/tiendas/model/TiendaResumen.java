package cl.duoc.fitflow.tiendas.model;

/** Una tienda con cuántos probadores tiene y cuántos están fuera de servicio. */
public record TiendaResumen(long id, String nombre, int total, int fueraServicio) { }
