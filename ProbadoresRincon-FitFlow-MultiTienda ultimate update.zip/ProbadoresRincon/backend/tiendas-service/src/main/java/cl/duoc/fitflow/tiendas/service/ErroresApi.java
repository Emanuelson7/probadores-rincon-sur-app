package cl.duoc.fitflow.tiendas.service;

/** Excepciones de negocio. El manejador global las traduce a códigos HTTP (400, 404, 409). */
public final class ErroresApi {
    private ErroresApi() { }

    /** 400: los datos enviados no cumplen las reglas. */
    public static class Validacion extends RuntimeException {
        public Validacion(String mensaje) { super(mensaje); }
    }

    /** 404: el recurso no existe. */
    public static class NoEncontrado extends RuntimeException {
        public NoEncontrado(String mensaje) { super(mensaje); }
    }

    /** 409: la operación choca con el estado actual (ej: probador ocupado o fuera de servicio). */
    public static class Conflicto extends RuntimeException {
        public Conflicto(String mensaje) { super(mensaje); }
    }
}
