package cl.duoc.fitflow.tiendas.repository;

import cl.duoc.fitflow.tiendas.model.Probador;
import cl.duoc.fitflow.tiendas.model.Tienda;
import cl.duoc.fitflow.tiendas.model.TiendaResumen;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

/** Implementación con SQLite usando JdbcTemplate (SQL escrito a mano, sin ORM). */
@Repository
public class JdbcTiendaRepository implements TiendaRepository {

    private static final RowMapper<Tienda> MAPEO_TIENDA =
            (rs, fila) -> new Tienda(rs.getLong("id"), rs.getString("nombre"));

    private static final RowMapper<TiendaResumen> MAPEO_RESUMEN = (rs, fila) -> new TiendaResumen(
            rs.getLong("id"), rs.getString("nombre"), rs.getInt("total"), rs.getInt("fueraServicio"));

    private static final RowMapper<Probador> MAPEO_PROBADOR = (rs, fila) -> {
        long hora = rs.getLong("horaInicio");
        Long horaInicio = rs.wasNull() ? null : hora;   // wasNull(): la columna era NULL (probador libre)
        return new Probador(
                rs.getLong("id"),
                rs.getLong("tiendaId"),
                rs.getInt("numero"),
                rs.getInt("ocupado") == 1,
                horaInicio,
                rs.getString("nota"),
                rs.getString("estadoServicio"),
                rs.getString("motivoServicio"));
    };

    private final JdbcTemplate jdbc;

    public JdbcTiendaRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // ---------------- tiendas ----------------

    @Override
    public List<TiendaResumen> listarResumen() {
        return jdbc.query(
                "SELECT t.id AS id, t.nombre AS nombre, COUNT(p.id) AS total, "
                        + "COALESCE(SUM(CASE WHEN p.estadoServicio != 'ACTIVO' THEN 1 ELSE 0 END), 0) AS fueraServicio "
                        + "FROM tiendas t LEFT JOIN probadores p ON p.tiendaId = t.id "
                        + "GROUP BY t.id, t.nombre ORDER BY t.nombre",
                MAPEO_RESUMEN);
    }

    @Override
    public Optional<Tienda> buscarTienda(long id) {
        return jdbc.query("SELECT id, nombre FROM tiendas WHERE id = ?", MAPEO_TIENDA, id).stream().findFirst();
    }

    @Override
    public Optional<Tienda> buscarTiendaPorNombre(String nombre) {
        return jdbc.query("SELECT id, nombre FROM tiendas WHERE nombre = ?", MAPEO_TIENDA, nombre).stream().findFirst();
    }

    @Override
    public long crearTienda(String nombre) {
        KeyHolder llave = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO tiendas (nombre) VALUES (?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, nombre);
            return ps;
        }, llave);
        return llave.getKey().longValue();
    }

    @Override
    public long contarTiendas() {
        Long total = jdbc.queryForObject("SELECT COUNT(*) FROM tiendas", Long.class);
        return total == null ? 0 : total;
    }

    // ---------------- probadores ----------------

    @Override
    public List<Probador> listarProbadores(long tiendaId) {
        return jdbc.query("SELECT * FROM probadores WHERE tiendaId = ? ORDER BY numero", MAPEO_PROBADOR, tiendaId);
    }

    @Override
    public Optional<Probador> buscarProbador(long id) {
        return jdbc.query("SELECT * FROM probadores WHERE id = ?", MAPEO_PROBADOR, id).stream().findFirst();
    }

    @Override
    public Probador insertarProbador(long tiendaId, int numero) {
        KeyHolder llave = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO probadores (tiendaId, numero) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1, tiendaId);
            ps.setInt(2, numero);
            return ps;
        }, llave);
        return new Probador(llave.getKey().longValue(), tiendaId, numero, false, null, "", "ACTIVO", "");
    }

    @Override
    public int maxNumero(long tiendaId) {
        Integer maximo = jdbc.queryForObject(
                "SELECT COALESCE(MAX(numero), 0) FROM probadores WHERE tiendaId = ?", Integer.class, tiendaId);
        return maximo == null ? 0 : maximo;
    }

    @Override
    public void actualizarProbador(Probador p) {
        jdbc.update(
                "UPDATE probadores SET ocupado = ?, horaInicio = ?, nota = ?, estadoServicio = ?, motivoServicio = ? WHERE id = ?",
                p.ocupado() ? 1 : 0, p.horaInicio(), p.nota(), p.estadoServicio(), p.motivoServicio(), p.id());
    }

    @Override
    public void eliminarProbador(long id) {
        jdbc.update("DELETE FROM probadores WHERE id = ?", id);
    }

    // ---------------- configuración y fila ----------------

    @Override
    public int tiempoLimite(long tiendaId) {
        List<Integer> r = jdbc.queryForList(
                "SELECT tiempoLimiteMin FROM configuracion WHERE tiendaId = ?", Integer.class, tiendaId);
        return r.isEmpty() ? 15 : r.get(0);
    }

    @Override
    public void guardarTiempoLimite(long tiendaId, int minutos) {
        jdbc.update("INSERT OR REPLACE INTO configuracion (tiendaId, tiempoLimiteMin) VALUES (?, ?)", tiendaId, minutos);
    }

    @Override
    public int clientesEsperando(long tiendaId) {
        List<Integer> r = jdbc.queryForList(
                "SELECT clientesEsperando FROM fila WHERE tiendaId = ?", Integer.class, tiendaId);
        return r.isEmpty() ? 0 : r.get(0);
    }

    @Override
    public void guardarFila(long tiendaId, int clientes) {
        jdbc.update("INSERT OR REPLACE INTO fila (tiendaId, clientesEsperando) VALUES (?, ?)", tiendaId, clientes);
    }
}
