package cl.duoc.fitflow.tiendas.config;

import cl.duoc.fitflow.tiendas.model.Probador;
import cl.duoc.fitflow.tiendas.repository.TiendaRepository;
import cl.duoc.fitflow.tiendas.service.TiendaService;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

/**
 * Crea las tiendas de ejemplo la primera vez que se inicia el servicio (datos FICTICIOS).
 * Se crean en este orden para que sus ids sean 1, 2 y 3, igual que los tiendaId de las cuentas de auth-service.
 */
@Component
public class SembradorDatos implements ApplicationRunner {

    private final TiendaRepository repo;
    private final TiendaService servicio;

    public SembradorDatos(TiendaRepository repo, TiendaService servicio) {
        this.repo = repo;
        this.servicio = servicio;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (repo.contarTiendas() > 0) return;

        servicio.crearTienda("Jumbo Chicureo", 8);

        long costanera = servicio.crearTienda("Jumbo Costanera", 12).id();
        fueraDeServicio(costanera, 4, "EN_REPARACION", "Puerta dañada");

        long chamisero = servicio.crearTienda("Jumbo Chamisero", 6).id();
        fueraDeServicio(chamisero, 2, "NO_DISPONIBLE", "Espejo roto");
    }

    private void fueraDeServicio(long tiendaId, int numero, String estado, String motivo) {
        for (Probador p : servicio.listarProbadores(tiendaId)) {
            if (p.numero() == numero) {
                servicio.cambiarServicio(p.id(), estado, motivo);
            }
        }
    }
}
