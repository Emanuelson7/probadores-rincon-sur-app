package cl.duoc.fitflow.tiendas.controller;

import cl.duoc.fitflow.tiendas.dto.Mensaje;
import cl.duoc.fitflow.tiendas.dto.NotaRequest;
import cl.duoc.fitflow.tiendas.dto.ServicioRequest;
import cl.duoc.fitflow.tiendas.model.Probador;
import cl.duoc.fitflow.tiendas.service.TiendaService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * API REST de probadores (puerto 8082):
 *   POST   /api/probadores/{id}/ocupar     (200 | 404 | 409 si está fuera de servicio)
 *   POST   /api/probadores/{id}/liberar    (200 | 404)
 *   PUT    /api/probadores/{id}/servicio   (200 | 400 | 404 | 409 si está ocupado)
 *   PUT    /api/probadores/{id}/nota       (200 | 400 | 404)
 *   DELETE /api/probadores/{id}            (200 | 404 | 409 si está ocupado)
 */
@RestController
@RequestMapping("/api/probadores")
public class ProbadorController {

    private final TiendaService servicio;

    public ProbadorController(TiendaService servicio) {
        this.servicio = servicio;
    }

    @PostMapping("/{id}/ocupar")
    public Probador ocupar(@PathVariable long id) {
        return servicio.ocupar(id);
    }

    @PostMapping("/{id}/liberar")
    public Probador liberar(@PathVariable long id) {
        return servicio.liberar(id);
    }

    @PutMapping("/{id}/servicio")
    public Probador cambiarServicio(@PathVariable long id, @RequestBody ServicioRequest peticion) {
        return servicio.cambiarServicio(id, peticion.estado(), peticion.motivo());
    }

    @PutMapping("/{id}/nota")
    public Probador nota(@PathVariable long id, @RequestBody NotaRequest peticion) {
        return servicio.guardarNota(id, peticion.nota());
    }

    @DeleteMapping("/{id}")
    public Mensaje eliminar(@PathVariable long id) {
        servicio.eliminarProbador(id);
        return new Mensaje("Probador eliminado");
    }
}
