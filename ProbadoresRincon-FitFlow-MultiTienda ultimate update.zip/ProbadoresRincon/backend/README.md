# Backend FitFlow — microservicios Spring Boot + SQLite

MVP del backend de la app FitFlow (Probadores Rincón Sur). Son **dos microservicios independientes**, cada uno con
su propia API REST, su propia base de datos SQLite y sus propias pruebas unitarias. La app Android los consume con
**Retrofit**. Todos los datos son **ficticios**: no hay credenciales ni datos reales de ninguna tienda.

| Microservicio | Puerto | Base de datos | Responsabilidad |
|---|---|---|---|
| `auth-service` | 8081 | `auth.db` | Login, registro, roles (ADMIN / PERSONAL) y tienda de trabajo del asistente |
| `tiendas-service` | 8082 | `tiendas.db` | Tiendas, probadores, estado de servicio, tiempo límite y fila de espera |

## Requisitos
- JDK 17 o superior
- Maven 3.9+ (o abrir cada carpeta como proyecto Maven en IntelliJ IDEA / VS Code / Eclipse)

## Cómo ejecutar
Abre **dos terminales**, una por servicio:

```bash
cd backend/auth-service
mvn spring-boot:run          # http://localhost:8081

cd backend/tiendas-service
mvn spring-boot:run          # http://localhost:8082
```
La primera vez cada servicio crea su archivo `.db` y carga datos de ejemplo (3 tiendas y 4 cuentas de prueba).
Para empezar de cero, detén el servicio y borra el archivo `.db`.

Comprobar que están arriba:
```bash
curl http://localhost:8081/api/auth/ping
curl http://localhost:8082/api/tiendas/ping
```

## Pruebas unitarias
```bash
cd backend/auth-service    && mvn test     # RUT, login, registro, roles, cambio de tienda
cd backend/tiendas-service && mvn test     # ocupar/liberar, fuera de servicio, tiendas, fila, tiempo límite
```
Usan JUnit 5 y Mockito: el repositorio se reemplaza por un *mock* (no tocan SQLite) y el reloj es fijo.

## Arquitectura (por servicio)
```
controller   API REST: recibe HTTP y devuelve JSON (@RestController) + manejo de errores (@RestControllerAdvice)
service      Reglas de negocio y validaciones (lo que se prueba con pruebas unitarias)
repository   Interfaz + implementación JDBC con SQLite (SQL escrito a mano con JdbcTemplate)
model / dto  Datos del dominio y objetos que viajan por la API
config       Datos de ejemplo al iniciar y beans (reloj, BCrypt)
```
Flujo: `Controller → Service → Repository (interfaz) → SQLite`. El servicio depende de la **interfaz** del
repositorio, por eso se puede probar con un mock.

## API de `auth-service` (8081)
| Método | Ruta | Respuestas |
|---|---|---|
| POST | `/api/auth/login` `{correo, clave}` | 200 usuario · 400 · 401 credenciales inválidas |
| POST | `/api/auth/registro` `{nombre, rut, correo, cargo, clave, aceptaTerminos, tiendaId}` | 201 usuario · 400 datos inválidos · 409 correo repetido |
| PUT | `/api/usuarios/{id}/tienda` `{tiendaId}` | 200 · 404 · 409 (el administrador no tiene tienda fija) |

El **rol lo decide el servidor** según el cargo (`Jefe/a de Tienda (Administrador)` → ADMIN). Las claves se guardan
con **BCrypt**; la API nunca devuelve la clave ni su hash.

## API de `tiendas-service` (8082)
| Método | Ruta | Respuestas |
|---|---|---|
| GET | `/api/tiendas` | 200 lista con total de probadores y cuántos están fuera de servicio |
| POST | `/api/tiendas` `{nombre, cantidadProbadores}` | 201 · 400 · 409 nombre repetido |
| GET / POST | `/api/tiendas/{id}/probadores` | 200 lista / 201 agrega un probador · 404 |
| GET / PUT | `/api/tiendas/{id}/configuracion` `{tiempoLimiteMin}` | 200 · 400 (1–120) · 404 |
| GET / POST | `/api/tiendas/{id}/fila` `{delta}` | 200 (la fila nunca es negativa) · 404 |
| POST | `/api/probadores/{id}/ocupar` | 200 · 404 · 409 si está fuera de servicio |
| POST | `/api/probadores/{id}/liberar` | 200 · 404 |
| PUT | `/api/probadores/{id}/servicio` `{estado, motivo}` | 200 · 400 (motivo obligatorio) · 409 si está ocupado |
| PUT | `/api/probadores/{id}/nota` `{nota}` | 200 · 400 · 404 |
| DELETE | `/api/probadores/{id}` | 200 · 404 · 409 si está ocupado |

`estado` puede ser `ACTIVO`, `EN_REPARACION` o `NO_DISPONIBLE`.

Ejemplos:
```bash
curl -X POST http://localhost:8081/api/auth/login -H "Content-Type: application/json" \
     -d '{"correo":"admin@rincon.cl","clave":"Clave123"}'

curl http://localhost:8082/api/tiendas
curl -X PUT http://localhost:8082/api/probadores/1/servicio -H "Content-Type: application/json" \
     -d '{"estado":"EN_REPARACION","motivo":"Puerta dañada"}'
```

## Cuentas de prueba (clave `Clave123`)
`admin@rincon.cl` (administrador) · `asistente.chicureo@rincon.cl` · `asistente.costanera@rincon.cl` ·
`asistente.chamisero@rincon.cl`.

## Conexión con la app Android
La app usa **Retrofit** (`app/.../data/remote`). El emulador ve el computador como `10.0.2.2`, así que las
direcciones son `http://10.0.2.2:8081/` y `http://10.0.2.2:8082/` (se cambian en `ConfigApi`). En un celular real
hay que poner la IP del computador. La app guarda una copia en **Room** y sigue funcionando si el backend está
apagado.

## Alcance del MVP (qué NO incluye)
- Sin tokens de sesión (JWT): las rutas no exigen autenticación. En producción cada petición debería llevar un token
  y el servidor validar el rol.
- HTTP sin cifrar (solo para desarrollo local); en producción, HTTPS.
- Un solo archivo SQLite por servicio: suficiente para el MVP, no para muchos usuarios simultáneos.
