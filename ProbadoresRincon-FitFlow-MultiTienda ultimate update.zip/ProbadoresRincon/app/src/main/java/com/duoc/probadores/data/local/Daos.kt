package com.duoc.probadores.data.local

import com.duoc.probadores.model.TiendaEntity
import com.duoc.probadores.model.ProbadorEntity
import com.duoc.probadores.model.ConfiguracionEntity
import com.duoc.probadores.model.FilaEntity
import com.duoc.probadores.model.UsuarioEntity
import com.duoc.probadores.model.ResumenTienda
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/*
 * DAO (Data Access Object) = interfaz con las consultas a la base de datos.
 * Room genera la implementación en tiempo de compilación.
 *
 * - Funciones que devuelven Flow: Room vuelve a emitir cada vez que la tabla cambia.
 *   Gracias a eso la UI se actualiza sola al modificar un probador.
 * - Funciones suspend: se ejecutan en segundo plano (corrutinas), nunca bloquean la UI.
 */

@Dao
interface TiendaDao {
    @Query("SELECT * FROM tiendas ORDER BY nombre")
    fun observarTodas(): Flow<List<TiendaEntity>>

    @Query("SELECT * FROM tiendas ORDER BY id")
    suspend fun obtenerTodas(): List<TiendaEntity>

    @Query("SELECT * FROM tiendas WHERE id = :id")
    fun observarPorId(id: Int): Flow<TiendaEntity?>

    @Query("SELECT COUNT(*) FROM tiendas")
    suspend fun contar(): Int

    // Devuelve el id insertado, o -1 si ya existía una tienda con ese nombre (índice único + IGNORE).
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertar(tienda: TiendaEntity): Long

    // --- Sincronización con el servidor: se guardan las tiendas con SUS ids y se borran las que ya no existen ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardarTodas(tiendas: List<TiendaEntity>)

    @Query("DELETE FROM tiendas WHERE id NOT IN (:ids)")
    suspend fun borrarFueraDe(ids: List<Int>)

    /**
     * Resumen para la lista de tiendas del administrador: cuántos probadores tiene cada una
     * y cuántos están fuera de servicio. LEFT JOIN = también aparecen las tiendas sin probadores.
     */
    @Query(
        """
        SELECT t.id AS id, t.nombre AS nombre,
               COUNT(p.id) AS total,
               COALESCE(SUM(CASE WHEN p.estadoServicio != 'ACTIVO' THEN 1 ELSE 0 END), 0) AS fueraServicio
        FROM tiendas t
        LEFT JOIN probadores p ON p.tiendaId = t.id
        GROUP BY t.id, t.nombre
        ORDER BY t.nombre
        """
    )
    fun observarResumen(): Flow<List<ResumenTienda>>
}

@Dao
interface ProbadorDao {
    @Query("SELECT * FROM probadores WHERE tiendaId = :tiendaId ORDER BY numero")
    fun observarPorTienda(tiendaId: Int): Flow<List<ProbadorEntity>>

    @Query("SELECT * FROM probadores WHERE id = :id")
    fun observarPorId(id: Int): Flow<ProbadorEntity?>

    @Query("SELECT * FROM probadores WHERE id = :id")
    suspend fun obtener(id: Int): ProbadorEntity?

    @Query("SELECT COUNT(*) FROM probadores WHERE tiendaId = :tiendaId")
    suspend fun contarPorTienda(tiendaId: Int): Int

    // MAX devuelve null si la tienda no tiene probadores.
    @Query("SELECT MAX(numero) FROM probadores WHERE tiendaId = :tiendaId")
    suspend fun maxNumero(tiendaId: Int): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarTodos(lista: List<ProbadorEntity>)

    @Insert
    suspend fun insertar(probador: ProbadorEntity): Long

    @Update
    suspend fun actualizar(probador: ProbadorEntity)

    @Query("DELETE FROM probadores WHERE id = :id")
    suspend fun eliminar(id: Int)

    // --- Sincronización con el servidor ---
    @Query("SELECT * FROM probadores WHERE tiendaId = :tiendaId")
    suspend fun obtenerDeTienda(tiendaId: Int): List<ProbadorEntity>

    @Query("DELETE FROM probadores WHERE tiendaId = :tiendaId AND id NOT IN (:ids)")
    suspend fun borrarDeTiendaFueraDe(tiendaId: Int, ids: List<Int>)

    // La foto se guarda solo en el celular (el servidor no la maneja): se borra al liberar el probador.
    @Query("UPDATE probadores SET fotoPath = NULL WHERE id = :id")
    suspend fun limpiarFoto(id: Int)
}

@Dao
interface ConfiguracionDao {
    // El id de la configuración es el id de la tienda.
    @Query("SELECT * FROM configuracion WHERE id = :tiendaId")
    fun observar(tiendaId: Int): Flow<ConfiguracionEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)   // REPLACE = si existe, la reemplaza
    suspend fun guardar(config: ConfiguracionEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)    // IGNORE = si existe, no hace nada
    suspend fun insertarSiNoExiste(config: ConfiguracionEntity)
}

@Dao
interface FilaDao {
    // El id de la fila de espera es el id de la tienda.
    @Query("SELECT * FROM fila WHERE id = :tiendaId")
    fun observar(tiendaId: Int): Flow<FilaEntity?>

    @Query("SELECT * FROM fila WHERE id = :tiendaId")
    suspend fun obtener(tiendaId: Int): FilaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardar(fila: FilaEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarSiNoExiste(fila: FilaEntity)
}

@Dao
interface UsuarioDao {
    // Devuelve el id insertado, o -1 si el correo ya existía (por el índice único + IGNORE).
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertar(usuario: UsuarioEntity): Long

    @Query("SELECT * FROM usuarios WHERE correo = :correo LIMIT 1")
    suspend fun buscarPorCorreo(correo: String): UsuarioEntity?

    // Guarda (o reemplaza) el usuario que devolvió el servidor, para poder entrar también sin conexión.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardar(usuario: UsuarioEntity)

    // Solo el personal tiene una tienda de trabajo; el administrador (tiendaId 0) entra a todas.
    @Query("UPDATE usuarios SET tiendaId = :tiendaId WHERE id = :usuarioId AND rol = 'PERSONAL'")
    suspend fun cambiarTienda(usuarioId: Int, tiendaId: Int)
}
