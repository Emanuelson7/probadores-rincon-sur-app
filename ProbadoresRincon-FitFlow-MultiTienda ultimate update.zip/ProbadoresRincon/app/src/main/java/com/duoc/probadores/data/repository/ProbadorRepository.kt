package com.duoc.probadores.data.repository

import com.duoc.probadores.model.ConfiguracionEntity
import com.duoc.probadores.model.FilaEntity
import com.duoc.probadores.model.ProbadorEntity
import com.duoc.probadores.model.ResumenTienda
import com.duoc.probadores.model.TiendaEntity
import com.duoc.probadores.model.UsuarioEntity
import com.duoc.probadores.model.EstadoServicio
import kotlinx.coroutines.flow.Flow

/**
 * REPOSITORIO (interfaz).
 * Los ViewModels hablan SOLO con esta interfaz, nunca con Room directamente.
 * Cuando agreguen el backend (Retrofit + Spring Boot) solo hay que crear otra
 * implementación de esta interfaz: ViewModels y pantallas no cambian.
 */
interface ProbadorRepository {
    // --- Tiendas ---
    fun observarTiendas(): Flow<List<TiendaEntity>>
    fun observarResumenTiendas(): Flow<List<ResumenTienda>>
    fun observarTienda(id: Int): Flow<TiendaEntity?>
    /** Crea una tienda con [cantidadProbadores] probadores. false si ya existe una con ese nombre. */
    suspend fun crearTienda(nombre: String, cantidadProbadores: Int): Boolean

    // --- Lectura de probadores (Flows que se actualizan solos) ---
    fun observarProbadores(tiendaId: Int): Flow<List<ProbadorEntity>>
    fun observarProbador(id: Int): Flow<ProbadorEntity?>
    fun observarConfiguracion(tiendaId: Int): Flow<ConfiguracionEntity>
    fun observarFila(tiendaId: Int): Flow<FilaEntity>

    // --- Acciones del personal sobre probadores ---
    suspend fun ocupar(id: Int)
    suspend fun liberar(id: Int)
    suspend fun marcarAlertado(id: Int)
    suspend fun guardarNota(id: Int, nota: String)
    suspend fun guardarFoto(id: Int, ruta: String)

    // --- Acciones del administrador ---
    suspend fun agregarProbador(tiendaId: Int)
    /** false si el probador está ocupado (primero hay que liberarlo). */
    suspend fun eliminarProbador(id: Int): Boolean
    /** false si se intenta dejar fuera de servicio un probador que está ocupado. */
    suspend fun cambiarEstadoServicio(id: Int, estado: EstadoServicio, motivo: String): Boolean

    // --- Configuración y fila de espera (una por tienda) ---
    suspend fun guardarTiempoLimite(tiendaId: Int, minutos: Int)
    suspend fun cambiarFila(tiendaId: Int, delta: Int)

    // --- Usuarios ---
    suspend fun registrar(
        nombre: String, rut: String, correo: String, cargo: String, clave: String,
        aceptaTerminos: Boolean, rol: String, tiendaId: Int
    ): Boolean
    suspend fun iniciarSesion(correo: String, clave: String): UsuarioEntity?
    /** Recuerda la última tienda donde trabajó el asistente: la próxima vez que entre, parte ahí. */
    suspend fun guardarTiendaDeTrabajo(usuarioId: Int, tiendaId: Int)

    // --- Sincronización con el servidor (Retrofit) ---
    /** Descarga tiendas, probadores, configuración y filas desde el servidor y actualiza Room. false si no hay conexión. */
    suspend fun sincronizarTodo(): Boolean
    /** Igual que [sincronizarTodo] pero solo para una tienda (el panel lo repite cada pocos segundos). */
    suspend fun sincronizarTienda(tiendaId: Int): Boolean

    /** Carga datos ficticios la primera vez que se abre la app (sirve para trabajar sin servidor). */
    suspend fun sembrarDatosSiVacio()
}
