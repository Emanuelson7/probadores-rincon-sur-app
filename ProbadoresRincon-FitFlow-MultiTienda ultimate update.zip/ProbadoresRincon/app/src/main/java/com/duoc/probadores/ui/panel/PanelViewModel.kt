package com.duoc.probadores.ui.panel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.duoc.probadores.model.ProbadorEntity
import com.duoc.probadores.data.repository.ProbadorRepository
import com.duoc.probadores.domain.EstadoProbador
import com.duoc.probadores.model.EstadoServicio
import com.duoc.probadores.domain.fueraDeServicio
import com.duoc.probadores.domain.ReglasProbador
import com.duoc.probadores.util.Notificador
import com.duoc.probadores.util.relojCadaSegundo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PanelViewModel(
    private val repo: ProbadorRepository,
    private val notificador: Notificador,
    private val tiendaId: Int          // este panel muestra SOLO los probadores de esta tienda
) : ViewModel() {

    /** Un probador listo para dibujar: la entidad + su estado calculado + segundos transcurridos. */
    data class ProbadorUi(val entidad: ProbadorEntity, val estado: EstadoProbador, val segundos: Long)

    /** Todo lo que necesita la pantalla en un solo objeto inmutable. */
    data class PanelUiState(
        val nombreTienda: String = "",
        val probadores: List<ProbadorUi> = emptyList(),
        val clientesEsperando: Int = 0
    ) {
        val libres get() = probadores.count { it.estado == EstadoProbador.LIBRE }
        val fueraServicio get() = probadores.count { it.estado.fueraDeServicio }
        val ocupados get() = probadores.size - libres - fueraServicio
    }

    /**
     * combine() junta 5 flujos y recalcula el estado cuando CUALQUIERA cambia:
     * probadores de la tienda, configuración, fila, datos de la tienda y el reloj (cada segundo).
     * stateIn() lo convierte en StateFlow, que la pantalla puede leer con collectAsState.
     */
    val estado: StateFlow<PanelUiState> = combine(
        repo.observarProbadores(tiendaId),
        repo.observarConfiguracion(tiendaId),
        repo.observarFila(tiendaId),
        repo.observarTienda(tiendaId),
        relojCadaSegundo()
    ) { lista, config, fila, tienda, ahora ->
        PanelUiState(
            nombreTienda = tienda?.nombre ?: "",
            probadores = lista.map { p ->
                ProbadorUi(
                    entidad = p,
                    estado = ReglasProbador.calcularEstado(
                        p.ocupado, p.horaInicio, ahora, config.tiempoLimiteMin,
                        EstadoServicio.desde(p.estadoServicio)
                    ),
                    segundos = ReglasProbador.segundosOcupado(p.horaInicio, ahora)
                )
            },
            clientesEsperando = fila.clientesEsperando
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PanelUiState())

    // Ids ya notificados en memoria: evita notificar dos veces mientras la BD aún se actualiza.
    private val yaNotificados = mutableSetOf<Int>()

    init {
        // Vigila el estado: cada vez que cambia, revisa si hay que lanzar alertas.
        viewModelScope.launch { estado.collect { revisarAlertas(it) } }

        // Sincroniza con el servidor cada 5 segundos: así se ven los cambios hechos desde otro celular.
        // Si no hay conexión, sincronizarTienda devuelve false y la app sigue con los datos locales.
        viewModelScope.launch {
            while (true) {
                repo.sincronizarTienda(tiendaId)
                delay(5_000)
            }
        }
    }

    private suspend fun revisarAlertas(s: PanelUiState) {
        val prolongados = s.probadores.filter { it.estado == EstadoProbador.PROLONGADO }
        // Los que ya no están prolongados (se liberaron) salen del set.
        yaNotificados.retainAll(prolongados.map { it.entidad.id }.toSet())

        prolongados
            .filter { !it.entidad.alertado && yaNotificados.add(it.entidad.id) }
            .forEach {
                notificador.alertarUsoProlongado(it.entidad.numero, it.segundos / 60)
                repo.marcarAlertado(it.entidad.id)
            }
        // LIMITACIÓN: esto solo funciona con la app abierta o el proceso vivo. En un sistema
        // real las alertas las enviaría el backend (push) o un WorkManager/Service.
    }

    fun sumarFila() { viewModelScope.launch { repo.cambiarFila(tiendaId, +1) } }
    fun restarFila() { viewModelScope.launch { repo.cambiarFila(tiendaId, -1) } }
}
