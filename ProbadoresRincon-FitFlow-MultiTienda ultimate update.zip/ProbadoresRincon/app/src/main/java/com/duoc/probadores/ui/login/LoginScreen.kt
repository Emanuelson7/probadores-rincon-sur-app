package com.duoc.probadores.ui.login

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.probadores.domain.ROL_ADMIN
import com.duoc.probadores.ui.ViewModelFactory
import com.duoc.probadores.ui.components.BotonFit
import com.duoc.probadores.ui.components.CampoValidado
import com.duoc.probadores.ui.components.LogoFit
import com.duoc.probadores.ui.rememberApp
import com.duoc.probadores.ui.theme.ColorError
import com.duoc.probadores.ui.theme.Indigo
import com.duoc.probadores.ui.theme.TextoPrincipal
import com.duoc.probadores.ui.theme.TextoSecundario

/**
 * PANTALLA = solo dibuja y reenvía eventos al ViewModel. No contiene reglas de negocio.
 * Flujo de datos: ViewModel (estado) --> pantalla (dibuja) --> usuario (escribe)
 *                 --> pantalla (llama onCorreoChange) --> ViewModel (actualiza estado) ...
 */
@Composable
fun LoginScreen(onLoginExito: (esAdmin: Boolean, tiendaId: Int) -> Unit, onIrARegistro: () -> Unit) {
    val app = rememberApp()
    val vm: LoginViewModel = viewModel(factory = ViewModelFactory(app))
    val contexto = LocalContext.current

    // "¿Olvidaste tu contraseña?" aún no tiene backend: avisa con un Toast.
    val proximamente: () -> Unit = {
        Toast.makeText(contexto, "Disponible próximamente", Toast.LENGTH_SHORT).show()
    }

    // El botón solo se activa cuando ambos campos tienen texto y ninguno tiene error.
    val formularioListo = vm.correo.isNotBlank() && vm.clave.isNotBlank() &&
        vm.errorCorreo == null && vm.errorClave == null && !vm.cargando

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Cabecera: logo + nombre de la marca.
        Row(verticalAlignment = Alignment.CenterVertically) {
            LogoFit(tamano = 28.dp)
            Spacer(Modifier.width(8.dp))
            Text("FitFlow · Rincón Sur", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextoPrincipal)
        }
        Spacer(Modifier.height(12.dp))
        Text("Bienvenido/a de vuelta", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = TextoPrincipal)
        Text("Ingresa con tu cuenta del personal", fontSize = 12.sp, color = TextoSecundario)

        CampoValidado(
            valor = vm.correo, onCambio = vm::onCorreoChange, etiqueta = "Correo electrónico",
            iconoInicial = Icons.Default.Email, error = vm.errorCorreo, teclado = KeyboardType.Email,
            sugerencia = "nombre@rinconsur.cl"
        )
        CampoValidado(
            valor = vm.clave, onCambio = vm::onClaveChange, etiqueta = "Contraseña",
            iconoInicial = Icons.Default.Lock, error = vm.errorClave,
            esClave = true, teclado = KeyboardType.Password
        )

        Text(
            "¿Olvidaste tu contraseña?",
            fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Indigo,
            modifier = Modifier.align(Alignment.End).clickable(onClick = proximamente)
        )

        // Mensaje general de error que aparece/desaparece con animación.
        AnimatedVisibility(visible = vm.errorGeneral != null) {
            Text(vm.errorGeneral ?: "", color = ColorError, fontSize = 12.sp)
        }

        BotonFit(
            texto = if (vm.cargando) "Ingresando..." else "Iniciar sesión",
            enabled = formularioListo,
            onClick = {
                vm.iniciarSesion { usuario ->
                    // Se guarda la sesión: el rol decide si ve la lista de tiendas o solo la suya.
                    app.nombreUsuario = usuario.nombre
                    app.usuarioId = usuario.id
                    app.esAdmin = usuario.rol == ROL_ADMIN
                    onLoginExito(app.esAdmin, usuario.tiendaId)
                }
            }
        )

        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Text("¿No tienes cuenta? ", fontSize = 12.sp, color = TextoSecundario)
            Text(
                "Regístrate",
                fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Indigo,
                modifier = Modifier.clickable(onClick = onIrARegistro)
            )
        }
    }
}
