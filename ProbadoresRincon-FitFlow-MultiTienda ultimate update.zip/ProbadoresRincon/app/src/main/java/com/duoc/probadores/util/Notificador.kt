package com.duoc.probadores.util

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.duoc.probadores.MainActivity

/**
 * RECURSO NATIVO 1: NOTIFICACIONES.
 * Avisa al personal cuando un probador supera el tiempo límite.
 * Pasos que exige Android: (1) crear un canal, (2) tener el permiso, (3) construir y mostrar.
 */
class Notificador(private val context: Context) {

    companion object {
        const val CANAL_ID = "alertas_probadores"
    }

    /** Se llama una vez al iniciar la app (minSdk 26, así que el canal siempre aplica). */
    fun crearCanal() {
        val canal = NotificationChannel(CANAL_ID, "Alertas de probadores", NotificationManager.IMPORTANCE_HIGH)
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(canal)
    }

    /** En Android 13+ (API 33) el permiso se pide al usuario; antes se concede al instalar. */
    private fun tienePermiso(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission") // ya lo verificamos con tienePermiso()
    fun alertarUsoProlongado(numeroProbador: Int, minutos: Long) {
        if (!tienePermiso()) return   // integración segura: sin permiso no se intenta notificar

        // Al tocar la notificación se abre la app.
        val intent = Intent(context, MainActivity::class.java)
            .apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP }
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val notificacion = NotificationCompat.Builder(context, CANAL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Probador $numeroProbador con uso prolongado")
            .setContentText("Lleva $minutos min ocupado. Revisa si hay prendas abandonadas.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        // Usamos el número del probador como id: así cada probador tiene su propia notificación.
        NotificationManagerCompat.from(context).notify(numeroProbador, notificacion)
    }
}
