package com.duoc.probadores.data.remote

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

/**
 * Dirección de los microservicios.
 * 10.0.2.2 es la forma en que el EMULADOR de Android ve el "localhost" de tu computador.
 * Si pruebas en un celular real, cambia 10.0.2.2 por la IP de tu computador (ej: 192.168.1.20).
 */
object ConfigApi {
    const val URL_AUTH = "http://10.0.2.2:8081/"
    const val URL_TIENDAS = "http://10.0.2.2:8082/"
}

/**
 * API de autenticación (auth-service, puerto 8081).
 * Retrofit convierte cada función en una llamada HTTP. Las funciones "suspend" no bloquean la pantalla.
 * Si el servidor responde con error (400, 401, 409...), Retrofit lanza HttpException.
 */
interface AuthApi {
    @POST("api/auth/login")
    suspend fun login(@Body datos: LoginDto): UsuarioDto

    @POST("api/auth/registro")
    suspend fun registro(@Body datos: RegistroDto): UsuarioDto

    @PUT("api/usuarios/{id}/tienda")
    suspend fun cambiarTienda(@Path("id") usuarioId: Int, @Body datos: CambiarTiendaDto): MensajeDto
}

/** API de tiendas y probadores (tiendas-service, puerto 8082). */
interface TiendasApi {
    @GET("api/tiendas")
    suspend fun tiendas(): List<TiendaResumenDto>

    @POST("api/tiendas")
    suspend fun crearTienda(@Body datos: CrearTiendaDto): TiendaResumenDto

    @GET("api/tiendas/{id}/probadores")
    suspend fun probadores(@Path("id") tiendaId: Int): List<ProbadorDto>

    @POST("api/tiendas/{id}/probadores")
    suspend fun agregarProbador(@Path("id") tiendaId: Int): ProbadorDto

    @GET("api/tiendas/{id}/configuracion")
    suspend fun configuracion(@Path("id") tiendaId: Int): ConfigDto

    @PUT("api/tiendas/{id}/configuracion")
    suspend fun guardarConfiguracion(@Path("id") tiendaId: Int, @Body datos: ConfigDto): ConfigDto

    @GET("api/tiendas/{id}/fila")
    suspend fun fila(@Path("id") tiendaId: Int): FilaDto

    @POST("api/tiendas/{id}/fila")
    suspend fun cambiarFila(@Path("id") tiendaId: Int, @Body datos: FilaDeltaDto): FilaDto

    @POST("api/probadores/{id}/ocupar")
    suspend fun ocupar(@Path("id") probadorId: Int): ProbadorDto

    @POST("api/probadores/{id}/liberar")
    suspend fun liberar(@Path("id") probadorId: Int): ProbadorDto

    @PUT("api/probadores/{id}/servicio")
    suspend fun servicio(@Path("id") probadorId: Int, @Body datos: ServicioDto): ProbadorDto

    @PUT("api/probadores/{id}/nota")
    suspend fun nota(@Path("id") probadorId: Int, @Body datos: NotaDto): ProbadorDto

    @DELETE("api/probadores/{id}")
    suspend fun eliminar(@Path("id") probadorId: Int): MensajeDto
}

/** Agrupa las dos APIs. Se crea una sola vez en ProbadoresApp y se entrega al repositorio. */
class ApiFitFlow(val auth: AuthApi, val tiendas: TiendasApi) {
    companion object {
        fun crear(): ApiFitFlow {
            // Tiempos cortos: si el servidor está apagado, la app lo nota rápido y sigue con los datos locales.
            val cliente = OkHttpClient.Builder()
                .connectTimeout(2, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.SECONDS)
                .build()

            fun <T> servicio(url: String, tipo: Class<T>): T =
                Retrofit.Builder()
                    .baseUrl(url)
                    .client(cliente)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                    .create(tipo)

            return ApiFitFlow(
                auth = servicio(ConfigApi.URL_AUTH, AuthApi::class.java),
                tiendas = servicio(ConfigApi.URL_TIENDAS, TiendasApi::class.java)
            )
        }
    }
}
