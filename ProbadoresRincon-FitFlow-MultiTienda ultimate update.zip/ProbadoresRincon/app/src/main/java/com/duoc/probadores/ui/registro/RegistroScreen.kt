package com.duoc.probadores.ui.registro

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.probadores.domain.CARGOS_PERSONAL
import com.duoc.probadores.ui.ViewModelFactory
import com.duoc.probadores.ui.components.BarraPaso
import com.duoc.probadores.ui.components.BotonFit
import com.duoc.probadores.ui.components.CampoSelector
import com.duoc.probadores.ui.components.CampoValidado
import com.duoc.probadores.ui.components.IndicadorFuerza
import com.duoc.probadores.ui.rememberApp
import com.duoc.probadores.ui.theme.ColorError
import com.duoc.probadores.ui.theme.ColorExito
import com.duoc.probadores.ui.theme.Indigo
import com.duoc.probadores.ui.theme.TextoPrincipal
import com.duoc.probadores.ui.theme.TextoSecundario

@OptIn(ExperimentalMaterial3Api::class) // TopAppBar aún está marcado como experimental
@Composable
fun RegistroScreen(onRegistroExito: () -> Unit, onVolver: () -> Unit) {
    val vm: RegistroViewModel = viewModel(factory = ViewModelFactory(rememberApp()))

    // Scaffold = estructura base de Material (barra superior + contenido).
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Crear cuenta", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)          // respeta el espacio de la barra superior
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (vm.registrado) PasoCuentaCreada(correo = vm.correo, onIrALogin = onRegistroExito)
            else PasoDatos(vm)
        }
    }
}

/** PASO 1 de 2: formulario con todos los datos del personal. */
@Composable
private fun PasoDatos(vm: RegistroViewModel) {
    val tiendas by vm.tiendas.collectAsStateWithLifecycle()

    Text("Paso 1 de 2 · Datos del personal", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextoSecundario)
    BarraPaso(fraccion = 0.5f)

    CampoValidado(
        valor = vm.nombre, onCambio = vm::onNombreChange, etiqueta = "Nombre completo",
        iconoInicial = Icons.Default.Person, error = vm.errorNombre, sugerencia = "Camila Rojas"
    )
    CampoValidado(
        valor = vm.rut, onCambio = vm::onRutChange, etiqueta = "RUT",
        iconoInicial = Icons.Default.Badge, error = vm.errorRut, sugerencia = "12.345.678-5"
    )
    CampoValidado(
        valor = vm.correo, onCambio = vm::onCorreoChange, etiqueta = "Correo institucional",
        iconoInicial = Icons.Default.Email, error = vm.errorCorreo, teclado = KeyboardType.Email,
        sugerencia = "nombre@rinconsur.cl"
    )
    CampoSelector(
        valor = vm.cargo, opciones = CARGOS_PERSONAL, onSeleccion = vm::onCargoChange, etiqueta = "Cargo",
        iconoInicial = Icons.Default.Work, error = vm.errorCargo, sugerencia = "Selecciona tu cargo"
    )
    // El personal elige en qué tienda trabaja; el administrador entra a todas, así que no elige.
    if (vm.esAdministrador) {
        Text("Los administradores pueden entrar a todas las tiendas.", fontSize = 12.sp, color = TextoSecundario)
    } else {
        CampoSelector(
            valor = vm.tiendaNombre, opciones = tiendas.map { it.nombre }, onSeleccion = vm::onTiendaChange,
            etiqueta = "Tienda", iconoInicial = Icons.Default.Home, error = vm.errorTienda,
            sugerencia = "Selecciona tu tienda"
        )
    }
    CampoValidado(
        valor = vm.clave, onCambio = vm::onClaveChange, etiqueta = "Contraseña",
        iconoInicial = Icons.Default.Lock, error = vm.errorClave, esClave = true, teclado = KeyboardType.Password
    )
    // Barra + requisitos: aparecen apenas se empieza a escribir la contraseña.
    if (vm.clave.isNotEmpty()) IndicadorFuerza(vm.fuerza)

    CampoValidado(
        valor = vm.confirmar, onCambio = vm::onConfirmarChange, etiqueta = "Confirmar contraseña",
        iconoInicial = Icons.Default.Lock, error = vm.errorConfirmar, esClave = true, teclado = KeyboardType.Password
    )

    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = vm.aceptaTerminos,
                onCheckedChange = vm::onAceptarTerminosChange,
                colors = CheckboxDefaults.colors(
                    checkedColor = Indigo,
                    uncheckedColor = if (vm.errorTerminos != null) ColorError else TextoSecundario
                )
            )
            Text("Acepto los términos y la política de datos internos.", fontSize = 12.sp, color = TextoPrincipal)
        }
        vm.errorTerminos?.let { mensaje ->
            Text(mensaje, fontSize = 11.sp, color = ColorError, modifier = Modifier.padding(start = 12.dp))
        }
    }

    BotonFit(
        texto = if (vm.cargando) "Creando cuenta..." else "Crear cuenta",
        onClick = vm::registrar,
        enabled = !vm.cargando
    )
}

/** PASO 2 de 2: confirmación. Se muestra cuando el repositorio guardó la cuenta. */
@Composable
private fun PasoCuentaCreada(correo: String, onIrALogin: () -> Unit) {
    Text("Paso 2 de 2 · Cuenta creada", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextoSecundario)
    BarraPaso(fraccion = 1f)

    Spacer(Modifier.height(32.dp))
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier.size(72.dp).clip(CircleShape).background(ColorExito),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(40.dp))
        }
        Text("¡Cuenta creada!", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = TextoPrincipal)
        Text(
            "Ya puedes iniciar sesión con $correo.",
            fontSize = 13.sp, color = TextoSecundario
        )
    }
    Spacer(Modifier.height(16.dp))
    BotonFit(texto = "Ir a iniciar sesión", onClick = onIrALogin)
}
