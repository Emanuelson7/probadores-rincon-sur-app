package com.duoc.probadores.ui.panel

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.probadores.domain.EstadoProbador
import com.duoc.probadores.domain.fueraDeServicio
import com.duoc.probadores.ui.ViewModelFactory
import com.duoc.probadores.ui.rememberApp
import com.duoc.probadores.ui.theme.ColorFueraServicio
import com.duoc.probadores.ui.theme.ColorLibre
import com.duoc.probadores.ui.theme.ColorOcupado
import com.duoc.probadores.ui.theme.ColorProlongado
import com.duoc.probadores.util.formatearTiempo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PanelScreen(
    tiendaId: Int,
    onProbadorClick: (Int) -> Unit,
    onConfiguracion: () -> Unit,
    onAdministrar: () -> Unit,   // solo el administrador ve este botón
    onCambiarTienda: () -> Unit, // abre la lista de tiendas (asistente y administrador)
    onSalir: () -> Unit
) {
    val app = rememberApp()
    val context = LocalContext.current
    val vm: PanelViewModel = viewModel(factory = ViewModelFactory(app, idTienda = tiendaId))

    // collectAsStateWithLifecycle: convierte el StateFlow en estado de Compose y deja de
    // escuchar cuando la app pasa a segundo plano (ahorra batería).
    val estado by vm.estado.collectAsStateWithLifecycle()

    // Pedir el permiso de notificaciones (Android 13+) la primera vez que se abre el panel.
    val lanzadorPermiso = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {   // LaunchedEffect(Unit) = se ejecuta una sola vez al entrar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            lanzadorPermiso.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(estado.nombreTienda.ifBlank { "Probadores" }, fontWeight = FontWeight.Bold)
                        Text(app.nombreUsuario, style = MaterialTheme.typography.bodySmall)
                    }
                },
                actions = {
                    // Cambiar de tienda según dónde vaya a trabajar hoy (todos los usuarios).
                    IconButton(onClick = onCambiarTienda) {
                        Icon(Icons.Default.SwapHoriz, contentDescription = "Cambiar de tienda")
                    }
                    if (app.esAdmin) {
                        IconButton(onClick = onAdministrar) {
                            Icon(Icons.Default.Build, contentDescription = "Administrar probadores")
                        }
                    }
                    IconButton(onClick = onConfiguracion) {
                        Icon(Icons.Default.Settings, contentDescription = "Configuración")
                    }
                    TextButton(onClick = onSalir) { Text("Salir") }
                }
            )
        }
    ) { padding ->
        // LazyVerticalGrid: grilla "perezosa", solo dibuja lo que se ve en pantalla.
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            // span = ocupar las 2 columnas (encabezados a todo el ancho)
            item(span = { GridItemSpan(maxLineSpan) }) {
                Resumen(libres = estado.libres, ocupados = estado.ocupados, fuera = estado.fueraServicio)
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                TarjetaFila(
                    clientes = estado.clientesEsperando,
                    onSumar = vm::sumarFila,
                    onRestar = vm::restarFila
                )
            }
            // key = id estable: Compose reutiliza y anima cada tarjeta correctamente.
            items(estado.probadores, key = { it.entidad.id }) { item ->
                ProbadorCard(item = item, onClick = { onProbadorClick(item.entidad.id) })
            }
        }
    }
}

@Composable
private fun Resumen(libres: Int, ocupados: Int, fuera: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        ElevatedCard(modifier = Modifier.weight(1f)) {
            Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$libres", style = MaterialTheme.typography.headlineMedium)
                Text("Libres")
            }
        }
        ElevatedCard(modifier = Modifier.weight(1f)) {
            Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$ocupados", style = MaterialTheme.typography.headlineMedium)
                Text("Ocupados")
            }
        }
        ElevatedCard(modifier = Modifier.weight(1f)) {
            Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$fuera", style = MaterialTheme.typography.headlineMedium)
                Text("Fuera de servicio", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun TarjetaFila(clientes: Int, onSumar: () -> Unit, onRestar: () -> Unit) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Clientes en fila", fontWeight = FontWeight.Bold)
                Text("$clientes esperando", style = MaterialTheme.typography.bodyMedium)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onRestar) { Text("−") }
                FilledTonalButton(onClick = onSumar) { Text("+") }
            }
        }
    }
}

@Composable
private fun ProbadorCard(item: PanelViewModel.ProbadorUi, onClick: () -> Unit) {
    val colorObjetivo = when (item.estado) {
        EstadoProbador.LIBRE -> ColorLibre
        EstadoProbador.OCUPADO -> ColorOcupado
        EstadoProbador.PROLONGADO -> ColorProlongado
        EstadoProbador.EN_REPARACION, EstadoProbador.NO_DISPONIBLE -> ColorFueraServicio
    }
    // ANIMACIÓN: el color cambia suavemente en 600 ms cuando cambia el estado.
    val color by animateColorAsState(colorObjetivo, animationSpec = tween(600), label = "colorProbador")

    Card(
        onClick = onClick,
        enabled = !item.estado.fueraDeServicio,   // un probador fuera de servicio no se puede abrir
        colors = CardDefaults.cardColors(containerColor = color, disabledContainerColor = color),
        // animateContentSize: la tarjeta crece/se encoge con animación al aparecer el cronómetro.
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Probador ${item.entidad.numero}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                when (item.estado) {
                    EstadoProbador.LIBRE -> "Libre"
                    EstadoProbador.OCUPADO -> "Ocupado"
                    EstadoProbador.PROLONGADO -> "⚠ Uso prolongado"
                    EstadoProbador.EN_REPARACION -> "En reparación"
                    EstadoProbador.NO_DISPONIBLE -> "No disponible"
                }
            )
            if (item.estado.fueraDeServicio) {
                // Motivo que dejó el administrador (ej: "Puerta dañada").
                if (item.entidad.motivoServicio.isNotBlank()) {
                    Text(item.entidad.motivoServicio, style = MaterialTheme.typography.bodySmall)
                }
            } else if (item.estado != EstadoProbador.LIBRE) {
                Text(formatearTiempo(item.segundos), style = MaterialTheme.typography.headlineSmall)
            }
        }
    }
}
