package com.duoc.probadores.ui.onboarding

import android.app.Activity
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.duoc.probadores.ui.components.LogoFit
import com.duoc.probadores.ui.theme.Indigo
import com.duoc.probadores.ui.theme.IndigoOscuro
import com.duoc.probadores.ui.theme.IndigoSuave
import com.duoc.probadores.ui.theme.TextoPrincipal
import com.duoc.probadores.ui.theme.TextoSecundario
import kotlinx.coroutines.delay

/** Un paso del carrusel de bienvenida. */
private data class PasoOnboarding(val icono: ImageVector, val titulo: String, val detalle: String)

private val PASOS = listOf(
    PasoOnboarding(
        Icons.Default.MeetingRoom,
        "Mira qué probadores están libres",
        "Controla el tiempo de cada cliente. Recibe alertas antes de que haya filas."
    ),
    PasoOnboarding(
        Icons.Default.Notifications,
        "Alertas de uso prolongado",
        "Te avisamos cuando un probador supera el tiempo límite que definiste en Configuración."
    ),
    PasoOnboarding(
        Icons.Default.Groups,
        "Gestiona la fila y los reportes",
        "Lleva la cuenta de clientes esperando y deja notas o fotos de prendas abandonadas."
    )
)

private const val TOTAL_PROBADORES = 8   // la app siembra 8 probadores (ver ProbadorRepositoryImpl)

/**
 * Splash + onboarding (diseño "01 Splash + Onboarding"): fondo degradado azul, marca FitFlow
 * y una tarjeta con 3 pasos. [onTerminar] se llama con "Saltar" o con "Comenzar" en el último paso.
 */
@Composable
fun OnboardingScreen(onTerminar: () -> Unit) {
    // rememberSaveable: el paso actual sobrevive a rotar la pantalla.
    var paso by rememberSaveable { mutableStateOf(0) }
    // Texto "Cargando turnos..." que desaparece solo a los 1,5 s (detalle visual del diseño).
    var cargando by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1500)
        cargando = false
    }

    BarraEstadoIndigo()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Indigo, IndigoOscuro)))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // "Saltar" arriba a la derecha.
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onTerminar) {
                    Text("Saltar", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.weight(0.6f))

            // Marca.
            LogoFit(tamano = 64.dp, fondo = Color.White, icono = Indigo)
            Spacer(Modifier.height(14.dp))
            Text("FitFlow", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Rincón Sur · Vestuario",
                color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(14.dp))
            Text(
                "Controla tus probadores en tiempo real",
                color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))

            // Tarjeta blanca con el paso actual + puntos indicadores.
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
                    .padding(bottom = 14.dp)
            ) {
                Crossfade(targetState = paso, label = "tarjetaOnboarding") { indice ->
                    ContenidoPaso(indice)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PASOS.indices.forEach { indice ->
                        Punto(activo = indice == paso)
                        if (indice < PASOS.lastIndex) Spacer(Modifier.width(6.dp))
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            // Botones Atrás / Siguiente.
            val esUltimo = paso == PASOS.lastIndex
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { if (paso > 0) paso-- },
                    enabled = paso > 0,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = if (paso > 0) 0.7f else 0.3f)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color.White,
                        disabledContentColor = Color.White.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) { Text("Atrás", fontWeight = FontWeight.Bold) }

                Button(
                    onClick = { if (esUltimo) onTerminar() else paso++ },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Indigo),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) { Text(if (esUltimo) "Comenzar" else "Siguiente", fontWeight = FontWeight.Bold) }
            }

            // "Cargando turnos..." (mantiene el alto para que los botones no se muevan al desaparecer).
            Row(
                modifier = Modifier.height(32.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (cargando) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(12.dp),
                        strokeWidth = 1.5.dp,
                        color = Color.White
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Cargando turnos...", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ContenidoPaso(indice: Int) {
    val paso = PASOS[indice]
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(IndigoSuave),
                contentAlignment = Alignment.Center
            ) {
                Icon(paso.icono, contentDescription = null, tint = Indigo)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(paso.titulo, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextoPrincipal)
                Text(
                    "Paso ${indice + 1} de ${PASOS.size} · $TOTAL_PROBADORES probadores en vivo",
                    fontSize = 11.sp, color = TextoSecundario
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(paso.detalle, fontSize = 12.sp, color = TextoSecundario)
    }
}

/** Punto indicador: el activo es una píldora azul más ancha (animada), los demás son círculos grises. */
@Composable
private fun Punto(activo: Boolean) {
    val ancho by animateDpAsState(targetValue = if (activo) 20.dp else 6.dp, label = "anchoPunto")
    Box(
        modifier = Modifier
            .width(ancho)
            .height(6.dp)
            .clip(CircleShape)
            .background(if (activo) Indigo else Color(0xFFD0D4EA))
    )
}

/**
 * Pinta la barra de estado del mismo azul mientras se ve el splash y, al salir de esta
 * pantalla, restaura el color claro del resto de la app.
 */
@Composable
private fun BarraEstadoIndigo() {
    val vista = LocalView.current
    DisposableEffect(Unit) {
        val ventana = (vista.context as Activity).window
        val control = WindowCompat.getInsetsController(ventana, vista)
        val colorAnterior = ventana.statusBarColor
        val claroAnterior = control.isAppearanceLightStatusBars
        ventana.statusBarColor = Indigo.toArgb()
        control.isAppearanceLightStatusBars = false   // íconos blancos sobre fondo azul
        onDispose {
            ventana.statusBarColor = colorAnterior
            control.isAppearanceLightStatusBars = claroAnterior
        }
    }
}
