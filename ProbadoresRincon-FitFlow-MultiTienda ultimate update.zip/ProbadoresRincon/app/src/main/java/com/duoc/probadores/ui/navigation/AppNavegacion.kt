package com.duoc.probadores.ui.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.duoc.probadores.ui.administrar.AdministrarScreen
import com.duoc.probadores.ui.configuracion.ConfiguracionScreen
import com.duoc.probadores.ui.detalle.DetalleScreen
import com.duoc.probadores.ui.login.LoginScreen
import com.duoc.probadores.ui.onboarding.OnboardingScreen
import com.duoc.probadores.ui.panel.PanelScreen
import com.duoc.probadores.ui.registro.RegistroScreen
import com.duoc.probadores.ui.tiendas.TiendasScreen

/** Nombres (rutas) de cada pantalla. Centralizados para no escribir textos sueltos. */
object Rutas {
    const val ONBOARDING = "onboarding"
    const val LOGIN = "login"
    const val REGISTRO = "registro"
    const val TIENDAS = "tiendas"                       // lista de tiendas (solo administrador)
    const val PANEL = "panel/{tiendaId}"                // {tiendaId} es un argumento
    const val ADMINISTRAR = "administrar/{tiendaId}"
    const val CONFIG = "configuracion/{tiendaId}"
    const val DETALLE = "detalle/{tiendaId}/{id}"
    fun panel(tiendaId: Int) = "panel/$tiendaId"
    fun administrar(tiendaId: Int) = "administrar/$tiendaId"
    fun configuracion(tiendaId: Int) = "configuracion/$tiendaId"
    fun detalle(tiendaId: Int, id: Int) = "detalle/$tiendaId/$id"
}

/**
 * Mapa de navegación de la app. El NavController mantiene la "pila" de pantallas:
 * navigate() apila una pantalla, popBackStack() vuelve a la anterior.
 * Las transiciones (deslizar + desvanecer) cumplen el requisito de animaciones (IE 2.2.2).
 */
@Composable
fun AppNavegacion() {
    val nav = rememberNavController()

    NavHost(
        navController = nav,
        startDestination = Rutas.LOGIN,   // la app abre directo en el inicio de sesión (el onboarding queda registrado, sin usarse)
        enterTransition = { slideInHorizontally(initialOffsetX = { it }) + fadeIn() },
        exitTransition = { slideOutHorizontally(targetOffsetX = { -it / 3 }) + fadeOut() },
        popEnterTransition = { slideInHorizontally(initialOffsetX = { -it / 3 }) + fadeIn() },
        popExitTransition = { slideOutHorizontally(targetOffsetX = { it }) + fadeOut() }
    ) {
        composable(Rutas.ONBOARDING) {
            OnboardingScreen(
                onTerminar = {
                    // El splash se borra de la pila: "atrás" desde el login cierra la app, no vuelve aquí.
                    nav.navigate(Rutas.LOGIN) { popUpTo(Rutas.ONBOARDING) { inclusive = true } }
                }
            )
        }
        composable(Rutas.LOGIN) {
            LoginScreen(
                onLoginExito = { esAdmin, tiendaId ->
                    // El administrador elige tienda; el personal entra directo a la suya.
                    // popUpTo + inclusive: borra el login de la pila para que "atrás" no vuelva a él.
                    val destino = if (esAdmin) Rutas.TIENDAS else Rutas.panel(tiendaId)
                    nav.navigate(destino) { popUpTo(Rutas.LOGIN) { inclusive = true } }
                },
                onIrARegistro = { nav.navigate(Rutas.REGISTRO) }
            )
        }
        composable(Rutas.REGISTRO) {
            RegistroScreen(
                onRegistroExito = { nav.popBackStack() },
                onVolver = { nav.popBackStack() }
            )
        }
        composable(Rutas.TIENDAS) {
            TiendasScreen(
                onAbrirTienda = { id -> nav.navigate(Rutas.panel(id)) },
                onSalir = { salir(nav) }
            )
        }
        composable(Rutas.PANEL, arguments = listOf(navArgument("tiendaId") { type = NavType.IntType })) { entrada ->
            val tiendaId = entrada.arguments?.getInt("tiendaId") ?: 0
            PanelScreen(
                tiendaId = tiendaId,
                onProbadorClick = { id -> nav.navigate(Rutas.detalle(tiendaId, id)) },
                onConfiguracion = { nav.navigate(Rutas.configuracion(tiendaId)) },
                onAdministrar = { nav.navigate(Rutas.administrar(tiendaId)) },
                onCambiarTienda = {
                    // Si la lista de tiendas ya está en la pila (administrador) se vuelve a ella;
                    // si no (asistente que entró directo a su tienda) se abre reemplazando el panel.
                    if (!nav.popBackStack(Rutas.TIENDAS, inclusive = false)) {
                        nav.navigate(Rutas.TIENDAS) { popUpTo(Rutas.PANEL) { inclusive = true } }
                    }
                },
                onSalir = { salir(nav) }
            )
        }
        composable(Rutas.ADMINISTRAR, arguments = listOf(navArgument("tiendaId") { type = NavType.IntType })) { entrada ->
            AdministrarScreen(
                tiendaId = entrada.arguments?.getInt("tiendaId") ?: 0,
                onVolver = { nav.popBackStack() }
            )
        }
        composable(
            route = Rutas.DETALLE,
            arguments = listOf(
                navArgument("tiendaId") { type = NavType.IntType },
                navArgument("id") { type = NavType.IntType }
            )
        ) { entrada ->
            DetalleScreen(
                idTienda = entrada.arguments?.getInt("tiendaId") ?: 0,
                idProbador = entrada.arguments?.getInt("id") ?: 0,
                onVolver = { nav.popBackStack() }
            )
        }
        composable(Rutas.CONFIG, arguments = listOf(navArgument("tiendaId") { type = NavType.IntType })) { entrada ->
            ConfiguracionScreen(
                tiendaId = entrada.arguments?.getInt("tiendaId") ?: 0,
                onVolver = { nav.popBackStack() }
            )
        }
    }
}

/** Cierra la sesión: limpia toda la pila de pantallas y vuelve al login. */
private fun salir(nav: NavHostController) {
    nav.navigate(Rutas.LOGIN) { popUpTo(nav.graph.id) { inclusive = true } }
}
