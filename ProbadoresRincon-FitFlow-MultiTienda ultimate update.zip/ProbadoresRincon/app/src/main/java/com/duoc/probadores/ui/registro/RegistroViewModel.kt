package com.duoc.probadores.ui.registro

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.duoc.probadores.data.repository.ProbadorRepository
import com.duoc.probadores.model.TiendaEntity
import com.duoc.probadores.domain.CARGO_ADMIN
import com.duoc.probadores.model.FuerzaClave
import com.duoc.probadores.domain.ROL_ADMIN
import com.duoc.probadores.domain.ROL_PERSONAL
import com.duoc.probadores.domain.Validador
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel del registro (diseño FitFlow, "Paso 1 de 2 · Datos del personal").
 * Campos: nombre completo, RUT, correo institucional, cargo, contraseña, confirmar y términos.
 * El paso 2 es la pantalla de "Cuenta creada" ([registrado] = true).
 */
class RegistroViewModel(private val repo: ProbadorRepository) : ViewModel() {

    var nombre by mutableStateOf("")
        private set
    var rut by mutableStateOf("")
        private set
    var correo by mutableStateOf("")
        private set
    var cargo by mutableStateOf("")
        private set
    /** Nombre de la tienda elegida (solo el personal elige tienda; el administrador entra a todas). */
    var tiendaNombre by mutableStateOf("")
        private set
    var clave by mutableStateOf("")
        private set
    var confirmar by mutableStateOf("")
        private set
    var aceptaTerminos by mutableStateOf(false)
        private set

    var errorNombre by mutableStateOf<String?>(null)
        private set
    var errorRut by mutableStateOf<String?>(null)
        private set
    var errorCorreo by mutableStateOf<String?>(null)
        private set
    var errorCargo by mutableStateOf<String?>(null)
        private set
    var errorTienda by mutableStateOf<String?>(null)
        private set
    var errorClave by mutableStateOf<String?>(null)
        private set
    var errorConfirmar by mutableStateOf<String?>(null)
        private set
    var errorTerminos by mutableStateOf<String?>(null)
        private set

    var cargando by mutableStateOf(false)
        private set
    /** true cuando la cuenta ya se creó: la pantalla pasa al "Paso 2 de 2". */
    var registrado by mutableStateOf(false)
        private set

    /** Tiendas disponibles para elegir (se actualizan solas desde la base de datos). */
    val tiendas: StateFlow<List<TiendaEntity>> = repo.observarTiendas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        // Para que la lista de tiendas del registro esté al día (si hay conexión con el servidor).
        viewModelScope.launch { repo.sincronizarTodo() }
    }

    /** true si el cargo elegido convierte la cuenta en administrador. */
    val esAdministrador: Boolean
        get() = cargo == CARGO_ADMIN

    /** Fortaleza de la contraseña actual (se recalcula sola cada vez que cambia [clave]). */
    val fuerza: FuerzaClave
        get() = Validador.fuerzaClave(clave)

    fun onNombreChange(v: String) { nombre = v; errorNombre = Validador.nombre(v) }

    fun onRutChange(v: String) {
        rut = Validador.formatearRut(v)       // se escribe "123456785" y queda "12.345.678-5"
        errorRut = Validador.rut(rut)
    }

    fun onCorreoChange(v: String) { correo = v; errorCorreo = Validador.correo(v) }
    fun onCargoChange(v: String) {
        cargo = v
        errorCargo = Validador.cargo(v)
        if (v == CARGO_ADMIN) errorTienda = null   // el administrador no necesita tienda
    }

    fun onTiendaChange(v: String) { tiendaNombre = v; errorTienda = Validador.tienda(v) }

    fun onClaveChange(v: String) {
        clave = v
        errorClave = Validador.clave(v)
        // Si ya se escribió la confirmación, se revalida porque depende de la clave.
        if (confirmar.isNotEmpty()) errorConfirmar = Validador.confirmarClave(v, confirmar)
    }

    fun onConfirmarChange(v: String) {
        confirmar = v
        errorConfirmar = Validador.confirmarClave(clave, v)
    }

    fun onAceptarTerminosChange(v: Boolean) {
        aceptaTerminos = v
        errorTerminos = if (v) null else "Debes aceptar los términos"
    }

    fun registrar() {
        errorNombre = Validador.nombre(nombre)
        errorRut = Validador.rut(rut)
        errorCorreo = Validador.correo(correo)
        errorCargo = Validador.cargo(cargo)
        errorTienda = if (esAdministrador) null else Validador.tienda(tiendaNombre)
        errorClave = Validador.clave(clave)
        errorConfirmar = Validador.confirmarClave(clave, confirmar)
        errorTerminos = if (aceptaTerminos) null else "Debes aceptar los términos"
        val errores = listOf(errorNombre, errorRut, errorCorreo, errorCargo, errorTienda, errorClave, errorConfirmar, errorTerminos)
        if (errores.any { it != null }) return

        viewModelScope.launch {
            cargando = true
            // El cargo decide el rol: "Jefe/a de Tienda (Administrador)" -> ADMIN (tiendaId 0 = todas).
            val rol = if (esAdministrador) ROL_ADMIN else ROL_PERSONAL
            val tiendaId = if (esAdministrador) 0 else tiendas.value.firstOrNull { it.nombre == tiendaNombre }?.id ?: 0
            if (!esAdministrador && tiendaId == 0) {
                cargando = false
                errorTienda = "Selecciona una tienda"
                return@launch
            }
            val creada = repo.registrar(nombre, rut, correo, cargo, clave, aceptaTerminos, rol, tiendaId)
            cargando = false
            if (creada) registrado = true
            else errorCorreo = "Ese correo ya está registrado"
        }
    }
}
