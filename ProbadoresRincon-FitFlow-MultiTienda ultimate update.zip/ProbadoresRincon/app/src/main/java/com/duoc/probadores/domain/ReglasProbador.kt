package com.duoc.probadores.domain

import com.duoc.probadores.model.EstadoServicio
import kotlin.math.max

/** Estados que ve el personal en el panel: 3 de uso + 2 de "fuera de servicio". */
enum class EstadoProbador { LIBRE, OCUPADO, PROLONGADO, EN_REPARACION, NO_DISPONIBLE }

/** true si el probador no se puede usar (lo marcó el administrador). */
val EstadoProbador.fueraDeServicio: Boolean
    get() = this == EstadoProbador.EN_REPARACION || this == EstadoProbador.NO_DISPONIBLE

/**
 * REGLAS DE NEGOCIO.
 * Son funciones puras (sin Android, sin base de datos): reciben datos y devuelven un resultado.
 * Por eso son muy fáciles de probar con tests unitarios (ver carpeta test).
 */
object ReglasProbador {

    /**
     * Primero mira el estado de servicio: si está en reparación o no disponible, manda ese estado.
     * Si no: LIBRE si no está ocupado; PROLONGADO si superó el límite; OCUPADO en otro caso.
     */
    fun calcularEstado(
        ocupado: Boolean,
        horaInicio: Long?,
        ahora: Long,
        limiteMin: Int,
        servicio: EstadoServicio = EstadoServicio.ACTIVO   // por defecto operativo (así los tests antiguos siguen igual)
    ): EstadoProbador {
        when (servicio) {
            EstadoServicio.EN_REPARACION -> return EstadoProbador.EN_REPARACION
            EstadoServicio.NO_DISPONIBLE -> return EstadoProbador.NO_DISPONIBLE
            EstadoServicio.ACTIVO -> Unit
        }
        if (!ocupado || horaInicio == null) return EstadoProbador.LIBRE
        val minutos = (ahora - horaInicio) / 60_000
        return if (minutos >= limiteMin) EstadoProbador.PROLONGADO else EstadoProbador.OCUPADO
    }

    /** Segundos transcurridos desde que se ocupó (0 si está libre). */
    fun segundosOcupado(horaInicio: Long?, ahora: Long): Long =
        if (horaInicio == null) 0 else max(0, (ahora - horaInicio) / 1000)
}
