package com.duoc.probadores.domain

/** Roles de la app. El rol se guarda en la tabla de usuarios y decide qué pantallas se ven. */
const val ROL_ADMIN = "ADMIN"          // entra a todas las tiendas y administra probadores
const val ROL_PERSONAL = "PERSONAL"    // trabaja en UNA tienda

/** Cargo que convierte la cuenta en administrador. */
const val CARGO_ADMIN = "Jefe/a de Tienda (Administrador)"

/** Cargos que se pueden elegir al crear una cuenta (lista desplegable del registro). */
val CARGOS_PERSONAL = listOf(
    "Asistente de Probadores",
    "Encargado/a de Vestuario",
    "Vendedor/a de Sala",
    "Supervisor/a de Tienda",
    "Reponedor/a",
    CARGO_ADMIN
)
