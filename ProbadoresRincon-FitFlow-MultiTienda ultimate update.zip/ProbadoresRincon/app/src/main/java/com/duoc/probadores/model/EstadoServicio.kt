package com.duoc.probadores.model

/**
 * Estado de SERVICIO de un probador (lo define el administrador): ¿se puede usar o no?
 * Es distinto del estado de USO (libre / ocupado / prolongado), que depende de los clientes.
 * En la base de datos se guarda como texto (el nombre del valor).
 */
enum class EstadoServicio(val etiqueta: String) {
    ACTIVO("Operativo"),
    EN_REPARACION("En reparación"),
    NO_DISPONIBLE("No disponible");

    companion object {
        /** Convierte el texto guardado en la BD; si no lo reconoce, asume operativo. */
        fun desde(texto: String): EstadoServicio = values().firstOrNull { it.name == texto } ?: ACTIVO
    }
}
