package com.duoc.probadores.model

/** Resultado de la consulta de resumen (no es una tabla: solo una "foto" calculada). */
data class ResumenTienda(
    val id: Int,
    val nombre: String,
    val total: Int,
    val fueraServicio: Int
)
