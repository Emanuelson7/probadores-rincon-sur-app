package com.duoc.probadores.ui.detalle

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Create
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.probadores.domain.EstadoProbador
import com.duoc.probadores.domain.fueraDeServicio
import com.duoc.probadores.ui.ViewModelFactory
import com.duoc.probadores.ui.components.CampoValidado
import com.duoc.probadores.ui.rememberApp
import com.duoc.probadores.ui.theme.ColorFueraServicio
import com.duoc.probadores.ui.theme.ColorLibre
import com.duoc.probadores.ui.theme.ColorOcupado
import com.duoc.probadores.ui.theme.ColorProlongado
import com.duoc.probadores.util.Fotos
import com.duoc.probadores.util.formatearTiempo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetalleScreen(idTienda: Int, idProbador: Int, onVolver: () -> Unit) {
    val context = LocalContext.current
    // Pasamos el id a la fábrica para que construya el ViewModel de ESTE probador.
    val vm: DetalleViewModel = viewModel(factory = ViewModelFactory(rememberApp(), idProbador, idTienda))
    val ui by vm.uiState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    // Cuando el ViewModel publica un mensaje, se muestra y se limpia.
    LaunchedEffect(vm.mensaje) {
        vm.mensaje?.let {
            snackbar.showSnackbar(it)
            vm.limpiarMensaje()
        }
    }

    // ---- RECURSO NATIVO 2: CÁMARA ----
    // TakePicturePreview abre la app de cámara del sistema y devuelve una miniatura (Bitmap).
    // Al usar la cámara del sistema no necesitamos manejar el hardware nosotros.
    val lanzadorCamara = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap: Bitmap? ->
        if (bitmap != null) {
            val ruta = Fotos.guardar(context, bitmap, idProbador)   // almacenamiento interno
            vm.guardarFoto(ruta)
        }
    }
    // Permiso en tiempo de ejecución: se pide solo si aún no está concedido.
    val lanzadorPermiso = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { concedido ->
        if (concedido) lanzadorCamara.launch(null) else vm.avisarPermisoDenegado()
    }
    fun tomarFoto() {
        val concedido = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (concedido) lanzadorCamara.launch(null) else lanzadorPermiso.launch(Manifest.permission.CAMERA)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Probador ${ui.probador?.numero ?: ""}") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            TarjetaEstado(ui.estado, ui.segundos)

            // Un solo botón cuyo propósito cambia según el estado.
            if (ui.estado.fueraDeServicio) {
                // Fuera de servicio: no se puede ocupar. Se muestra el motivo que dejó el administrador.
                Text(ui.probador?.motivoServicio.orEmpty().ifBlank { "Este probador no está disponible." })
            } else if (ui.estado == EstadoProbador.LIBRE) {
                Button(onClick = vm::ocupar, modifier = Modifier.fillMaxWidth()) { Text("Marcar como ocupado") }
            } else {
                Button(onClick = vm::liberar, modifier = Modifier.fillMaxWidth()) { Text("Liberar probador") }
            }

            // El formulario de reporte aparece/desaparece con animación según esté ocupado.
            AnimatedVisibility(visible = ui.probador?.ocupado == true) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Reporte (prenda abandonada, observaciones)", style = MaterialTheme.typography.titleMedium)

                    CampoValidado(
                        valor = vm.nota, onCambio = vm::onNotaChange, etiqueta = "Observación",
                        iconoInicial = Icons.Default.Create, error = vm.errorNota, unaLinea = false
                    )
                    Button(onClick = vm::guardarReporte, modifier = Modifier.fillMaxWidth()) { Text("Guardar reporte") }

                    OutlinedButton(onClick = ::tomarFoto, modifier = Modifier.fillMaxWidth()) { Text("Tomar foto") }

                    // Muestra la foto guardada (si existe). remember(ruta): solo decodifica si cambia la ruta.
                    val ruta = ui.probador?.fotoPath
                    val imagen = remember(ruta) { ruta?.let { BitmapFactory.decodeFile(it)?.asImageBitmap() } }
                    if (imagen != null) {
                        Image(bitmap = imagen, contentDescription = "Foto del reporte", modifier = Modifier.height(180.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TarjetaEstado(estado: EstadoProbador, segundos: Long) {
    val objetivo = when (estado) {
        EstadoProbador.LIBRE -> ColorLibre
        EstadoProbador.OCUPADO -> ColorOcupado
        EstadoProbador.PROLONGADO -> ColorProlongado
        EstadoProbador.EN_REPARACION, EstadoProbador.NO_DISPONIBLE -> ColorFueraServicio
    }
    val color by animateColorAsState(objetivo, animationSpec = tween(600), label = "colorEstado")
    Card(colors = CardDefaults.cardColors(containerColor = color), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(
                when (estado) {
                    EstadoProbador.LIBRE -> "Libre"
                    EstadoProbador.OCUPADO -> "Ocupado"
                    EstadoProbador.PROLONGADO -> "⚠ Uso prolongado"
                    EstadoProbador.EN_REPARACION -> "En reparación"
                    EstadoProbador.NO_DISPONIBLE -> "No disponible"
                },
                style = MaterialTheme.typography.headlineMedium
            )
            if (estado != EstadoProbador.LIBRE && !estado.fueraDeServicio) Text("Tiempo: ${formatearTiempo(segundos)}")
        }
    }
}
