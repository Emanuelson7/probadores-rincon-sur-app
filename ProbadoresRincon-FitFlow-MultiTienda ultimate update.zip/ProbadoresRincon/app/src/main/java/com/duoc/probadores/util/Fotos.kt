package com.duoc.probadores.util

import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream

/**
 * Guarda la foto tomada con la cámara en el almacenamiento INTERNO de la app
 * (filesDir). Solo esta app puede leerlo: es la opción más segura.
 */
object Fotos {
    fun guardar(context: Context, bitmap: Bitmap, idProbador: Int): String {
        val carpeta = File(context.filesDir, "fotos").apply { mkdirs() }
        // Nombre único con la hora, para que la UI detecte que la foto cambió.
        val archivo = File(carpeta, "probador_${idProbador}_${System.currentTimeMillis()}.jpg")
        FileOutputStream(archivo).use { salida -> bitmap.compress(Bitmap.CompressFormat.JPEG, 90, salida) }
        return archivo.absolutePath
    }
}
