package com.duoc.probadores.ui.configuracion

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.probadores.ui.ViewModelFactory
import com.duoc.probadores.ui.components.CampoValidado
import com.duoc.probadores.ui.rememberApp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfiguracionScreen(tiendaId: Int, onVolver: () -> Unit) {
    val vm: ConfiguracionViewModel = viewModel(factory = ViewModelFactory(rememberApp(), idTienda = tiendaId))

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Configuración") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "Tiempo máximo de uso antes de enviar una alerta. " +
                    "Tip para probar la app: pon 1 minuto.",
                style = MaterialTheme.typography.bodyMedium
            )
            CampoValidado(
                valor = vm.tiempo, onCambio = vm::onTiempoChange, etiqueta = "Minutos",
                iconoInicial = Icons.Default.Settings, error = vm.error, teclado = KeyboardType.Number
            )
            Button(onClick = vm::guardar, modifier = Modifier.fillMaxWidth()) { Text("Guardar") }

            // Retroalimentación visual de éxito.
            AnimatedVisibility(visible = vm.guardado) {
                Text("✓ Configuración guardada", color = MaterialTheme.colorScheme.secondary)
            }
        }
    }
}
