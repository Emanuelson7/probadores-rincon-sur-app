package com.duoc.probadores.ui.administrar

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.probadores.model.EstadoServicio
import com.duoc.probadores.ui.ViewModelFactory
import com.duoc.probadores.ui.components.BotonFit
import com.duoc.probadores.ui.components.CampoValidado
import com.duoc.probadores.ui.rememberApp
import com.duoc.probadores.ui.theme.ColorError
import com.duoc.probadores.ui.theme.ColorExito
import com.duoc.probadores.ui.theme.Indigo
import com.duoc.probadores.ui.theme.TextoPrincipal
import com.duoc.probadores.ui.theme.TextoSecundario

/** Administrar una tienda: agregar/quitar probadores y marcarlos en reparación o no disponibles. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdministrarScreen(tiendaId: Int, onVolver: () -> Unit) {
    val vm: AdministrarViewModel = viewModel(factory = ViewModelFactory(rememberApp(), idTienda = tiendaId))
    val tienda by vm.tienda.collectAsStateWithLifecycle()
    val probadores by vm.probadores.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(vm.mensaje) {
        vm.mensaje?.let {
            snackbar.showSnackbar(it)
            vm.limpiarMensaje()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Administrar · ${tienda?.nombre ?: ""}", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${probadores.size} probadores en esta tienda", fontSize = 12.sp, color = TextoSecundario)
                    BotonFit(texto = "Agregar probador", onClick = vm::agregarProbador)
                }
            }
            items(probadores, key = { it.id }) { p ->
                val servicio = EstadoServicio.desde(p.estadoServicio)
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(start = 16.dp, top = 8.dp, end = 4.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Probador ${p.numero}", fontWeight = FontWeight.Bold, color = TextoPrincipal)
                            Text(
                                servicio.etiqueta,
                                fontSize = 12.sp,
                                color = if (servicio == EstadoServicio.ACTIVO) ColorExito else ColorError
                            )
                            if (servicio != EstadoServicio.ACTIVO && p.motivoServicio.isNotBlank()) {
                                Text(p.motivoServicio, fontSize = 12.sp, color = TextoSecundario)
                            }
                            if (p.ocupado) Text("Ocupado ahora", fontSize = 12.sp, color = TextoSecundario)
                        }
                        IconButton(onClick = { vm.abrirEstado(p) }) {
                            Icon(Icons.Default.Build, contentDescription = "Cambiar estado", tint = Indigo)
                        }
                        IconButton(onClick = { vm.pedirEliminar(p) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Eliminar probador", tint = ColorError)
                        }
                    }
                }
            }
        }
    }

    // ---- Diálogo: cambiar el estado de servicio ----
    vm.editando?.let { p ->
        AlertDialog(
            onDismissRequest = vm::cerrarEstado,
            title = { Text("Probador ${p.numero}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    EstadoServicio.values().forEach { opcion ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { vm.elegirEstado(opcion) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = vm.estadoElegido == opcion,
                                onClick = { vm.elegirEstado(opcion) },
                                colors = RadioButtonDefaults.colors(selectedColor = Indigo)
                            )
                            Text(opcion.etiqueta)
                        }
                    }
                    // El motivo solo se pide si el probador queda fuera de servicio.
                    if (vm.estadoElegido != EstadoServicio.ACTIVO) {
                        CampoValidado(
                            valor = vm.motivo, onCambio = vm::onMotivoChange, etiqueta = "Motivo",
                            iconoInicial = Icons.Default.Build, error = vm.errorMotivo,
                            sugerencia = "Ej: puerta dañada"
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = vm::guardarEstado) { Text("Guardar") } },
            dismissButton = { TextButton(onClick = vm::cerrarEstado) { Text("Cancelar") } }
        )
    }

    // ---- Diálogo: confirmar eliminación ----
    vm.porEliminar?.let { p ->
        AlertDialog(
            onDismissRequest = vm::cancelarEliminar,
            title = { Text("¿Eliminar probador ${p.numero}?") },
            text = { Text("Se borra de esta tienda. Esta acción no se puede deshacer.") },
            confirmButton = { TextButton(onClick = vm::confirmarEliminar) { Text("Eliminar", color = ColorError) } },
            dismissButton = { TextButton(onClick = vm::cancelarEliminar) { Text("Cancelar") } }
        )
    }
}
