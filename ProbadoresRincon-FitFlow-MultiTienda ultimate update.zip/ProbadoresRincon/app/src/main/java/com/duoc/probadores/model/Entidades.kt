package com.duoc.probadores.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/*
 * ENTIDADES = tablas de la base de datos (Room).
 * Cada data class anotada con @Entity se convierte en una tabla SQLite;
 * cada propiedad es una columna.
 */

/** Una tienda (ej: Jumbo Chicureo). Cada tienda tiene su propio conjunto de probadores. */
@Entity(
    tableName = "tiendas",
    indices = [Index(value = ["nombre"], unique = true)]   // no se repiten nombres de tienda
)
data class TiendaEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String
)

/** Un probador físico de una tienda. */
@Entity(tableName = "probadores")
data class ProbadorEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,   // id único en TODA la app (no solo en la tienda)
    val numero: Int,                 // número visible en la puerta (se repite entre tiendas)
    val ocupado: Boolean = false,
    val horaInicio: Long? = null,    // momento (ms desde 1970) en que se ocupó; null si está libre
    val alertado: Boolean = false,   // true si ya se envió la notificación de uso prolongado
    val nota: String = "",           // reporte del personal (ej: "prenda abandonada")
    val fotoPath: String? = null,    // ruta de la foto tomada con la cámara
    @ColumnInfo(defaultValue = "1") val tiendaId: Int = 1,                         // a qué tienda pertenece
    @ColumnInfo(defaultValue = "'ACTIVO'") val estadoServicio: String = "ACTIVO",  // ACTIVO / EN_REPARACION / NO_DISPONIBLE
    @ColumnInfo(defaultValue = "''") val motivoServicio: String = ""               // ej: "puerta dañada"
)

/** Configuración de UNA tienda: el id de esta fila es el id de la tienda. */
@Entity(tableName = "configuracion")
data class ConfiguracionEntity(
    @PrimaryKey val id: Int = 1,
    val tiempoLimiteMin: Int = 15    // minutos a partir de los cuales el uso es "prolongado"
)

/** Cuántos clientes esperan por un probador en UNA tienda: el id de la fila es el id de la tienda. */
@Entity(tableName = "fila")
data class FilaEntity(
    @PrimaryKey val id: Int = 1,
    val clientesEsperando: Int = 0
)

/** Personal de tienda que puede iniciar sesión. */
@Entity(
    tableName = "usuarios",
    indices = [Index(value = ["correo"], unique = true)] // no se repiten correos
)
data class UsuarioEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String,
    val correo: String,
    val claveHash: String,           // NUNCA se guarda la clave en texto plano, solo su hash
    @ColumnInfo(defaultValue = "''") val direccion: String = "",   // ya no se pide en el registro (queda por compatibilidad)
    @ColumnInfo(defaultValue = "0") val aceptaTerminos: Boolean = false,
    @ColumnInfo(defaultValue = "''") val rut: String = "",         // RUT con formato 12.345.678-5
    @ColumnInfo(defaultValue = "''") val cargo: String = "",       // ej: "Encargado/a de Vestuario"
    @ColumnInfo(defaultValue = "'PERSONAL'") val rol: String = "PERSONAL",   // PERSONAL o ADMIN
    @ColumnInfo(defaultValue = "1") val tiendaId: Int = 1          // tienda donde trabaja (0 = administrador, todas)
)
