package com.duoc.probadores.data.local

import com.duoc.probadores.model.TiendaEntity
import com.duoc.probadores.model.ProbadorEntity
import com.duoc.probadores.model.ConfiguracionEntity
import com.duoc.probadores.model.FilaEntity
import com.duoc.probadores.model.UsuarioEntity
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Punto de entrada de Room: lista las tablas (entities) y entrega los DAOs.
 * Si cambias una entidad, sube [version] (o desinstala la app mientras desarrollas).
 */
@Database(
    entities = [
        ProbadorEntity::class, ConfiguracionEntity::class, FilaEntity::class,
        UsuarioEntity::class, TiendaEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun probadorDao(): ProbadorDao
    abstract fun configuracionDao(): ConfiguracionDao
    abstract fun filaDao(): FilaDao
    abstract fun usuarioDao(): UsuarioDao
    abstract fun tiendaDao(): TiendaDao

    companion object {
        /** Conserva las cuentas ya creadas al agregar dirección y aceptación de términos. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE usuarios ADD COLUMN direccion TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE usuarios ADD COLUMN aceptaTerminos INTEGER NOT NULL DEFAULT 0")
            }
        }

        /** Conserva las cuentas ya creadas al agregar RUT y cargo (diseño FitFlow). */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE usuarios ADD COLUMN rut TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE usuarios ADD COLUMN cargo TEXT NOT NULL DEFAULT ''")
            }
        }

        /**
         * Multi-tienda: crea la tabla de tiendas y agrega a cada probador su tienda y su estado de
         * servicio, y a cada usuario su rol y su tienda. Todo lo que ya existía queda en la tienda 1
         * (la primera que se siembra al abrir la app) y los usuarios existentes quedan como PERSONAL.
         */
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS `tiendas` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `nombre` TEXT NOT NULL)"
                )
                database.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_tiendas_nombre` ON `tiendas` (`nombre`)")
                database.execSQL("ALTER TABLE probadores ADD COLUMN tiendaId INTEGER NOT NULL DEFAULT 1")
                database.execSQL("ALTER TABLE probadores ADD COLUMN estadoServicio TEXT NOT NULL DEFAULT 'ACTIVO'")
                database.execSQL("ALTER TABLE probadores ADD COLUMN motivoServicio TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE usuarios ADD COLUMN rol TEXT NOT NULL DEFAULT 'PERSONAL'")
                database.execSQL("ALTER TABLE usuarios ADD COLUMN tiendaId INTEGER NOT NULL DEFAULT 1")
            }
        }

        fun crear(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "probadores.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                .build()
    }
}
