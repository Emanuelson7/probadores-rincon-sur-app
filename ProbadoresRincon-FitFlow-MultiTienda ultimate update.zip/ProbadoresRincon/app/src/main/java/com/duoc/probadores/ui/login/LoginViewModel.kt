package com.duoc.probadores.ui.login

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.duoc.probadores.model.UsuarioEntity
import com.duoc.probadores.data.repository.ProbadorRepository
import com.duoc.probadores.domain.Validador
import kotlinx.coroutines.launch

/**
 * VIEWMODEL = intermediario entre la pantalla y los datos.
 *  - Guarda el ESTADO del formulario (sobrevive a rotaciones de pantalla).
 *  - Ejecuta la LÓGICA (validar, consultar el repositorio).
 *  - La pantalla solo lee estos valores y llama a estas funciones.
 *
 * Usamos mutableStateOf: cuando el valor cambia, Compose redibuja automáticamente
 * solo lo que lo usa. "private set" = la pantalla puede leer pero NO modificar directamente.
 */
class LoginViewModel(private val repo: ProbadorRepository) : ViewModel() {

    var correo by mutableStateOf("")
        private set
    var clave by mutableStateOf("")
        private set
    var errorCorreo by mutableStateOf<String?>(null)
        private set
    var errorClave by mutableStateOf<String?>(null)
        private set
    var errorGeneral by mutableStateOf<String?>(null)
        private set
    var cargando by mutableStateOf(false)
        private set

    // Validación en vivo: cada vez que el usuario escribe se revalida el campo.
    fun onCorreoChange(valor: String) {
        correo = valor
        errorCorreo = Validador.correo(valor)
        errorGeneral = null
    }

    fun onClaveChange(valor: String) {
        clave = valor
        errorClave = Validador.claveIngreso(valor)
        errorGeneral = null
    }

    /** [onExito] recibe el usuario (nombre, rol, tienda); la pantalla decide a dónde navegar. */
    fun iniciarSesion(onExito: (UsuarioEntity) -> Unit) {
        // Se validan ambos campos al presionar el botón (por si nunca se tocaron).
        errorCorreo = Validador.correo(correo)
        errorClave = Validador.claveIngreso(clave)
        if (errorCorreo != null || errorClave != null) return

        viewModelScope.launch {          // corrutina: no bloquea la interfaz
            cargando = true
            val usuario = repo.iniciarSesion(correo, clave)
            cargando = false
            if (usuario == null) errorGeneral = "Correo o contraseña incorrectos" else onExito(usuario)
        }
    }
}
