package com.duoc.probadores.model

/**
 * Resultado de evaluar una contraseña con 4 criterios (los mismos que muestra el diseño):
 * 8 caracteres, mayúscula, número y símbolo. Es una data class simple: se puede probar
 * en un test unitario sin emulador.
 */
data class FuerzaClave(
    val tieneLargo: Boolean,
    val tieneMayuscula: Boolean,
    val tieneNumero: Boolean,
    val tieneSimbolo: Boolean
) {
    /** Cuántos criterios se cumplen (0 a 4). Se usa para llenar la barra de fortaleza. */
    val puntaje: Int
        get() = listOf(tieneLargo, tieneMayuscula, tieneNumero, tieneSimbolo).count { it }

    val etiqueta: String
        get() = when (puntaje) {
            0, 1 -> "Débil"
            2 -> "Media"
            3 -> "Fuerte"
            else -> "Muy fuerte"
        }
}
