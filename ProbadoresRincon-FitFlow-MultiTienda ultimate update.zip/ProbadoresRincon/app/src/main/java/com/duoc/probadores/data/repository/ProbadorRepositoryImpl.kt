package com.duoc.probadores.data.repository

import com.duoc.probadores.data.local.ConfiguracionDao
import com.duoc.probadores.data.local.FilaDao
import com.duoc.probadores.data.local.ProbadorDao
import com.duoc.probadores.data.local.TiendaDao
import com.duoc.probadores.data.local.UsuarioDao
import com.duoc.probadores.data.remote.ApiFitFlow
import com.duoc.probadores.data.remote.CambiarTiendaDto
import com.duoc.probadores.data.remote.ConfigDto
import com.duoc.probadores.data.remote.CrearTiendaDto
import com.duoc.probadores.data.remote.FilaDeltaDto
import com.duoc.probadores.data.remote.LoginDto
import com.duoc.probadores.data.remote.NotaDto
import com.duoc.probadores.data.remote.RegistroDto
import com.duoc.probadores.data.remote.ServicioDto
import com.duoc.probadores.domain.ROL_ADMIN
import com.duoc.probadores.domain.ROL_PERSONAL
import com.duoc.probadores.model.ConfiguracionEntity
import com.duoc.probadores.model.EstadoServicio
import com.duoc.probadores.model.FilaEntity
import com.duoc.probadores.model.ProbadorEntity
import com.duoc.probadores.model.ResumenTienda
import com.duoc.probadores.model.TiendaEntity
import com.duoc.probadores.model.UsuarioEntity
import com.duoc.probadores.util.Seguridad
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import retrofit2.HttpException

/**
 * Repositorio con DOS fuentes de datos:
 *  - Servidor (Retrofit -> microservicios Spring Boot): es la fuente de verdad.
 *  - Room (SQLite local): copia de respaldo. La pantalla SIEMPRE lee de Room (Flow), así que se ve
 *    rápido y la app sigue funcionando sin conexión.
 *
 * Cada acción primero se envía al servidor y, si respondió, se vuelve a descargar el estado y se guarda en
 * Room. Si no hay conexión, la acción se aplica solo en Room (los datos locales se reemplazan en la
 * próxima sincronización con el servidor).
 */
class ProbadorRepositoryImpl(
    private val probadorDao: ProbadorDao,
    private val configDao: ConfiguracionDao,
    private val filaDao: FilaDao,
    private val usuarioDao: UsuarioDao,
    private val tiendaDao: TiendaDao,
    private val api: ApiFitFlow
) : ProbadorRepository {

    /** Resultado de hablar con el servidor. */
    private enum class Remoto { OK, RECHAZADO, SIN_CONEXION }

    private class Intento<T>(val estado: Remoto, val valor: T? = null)

    /** true si el último inicio de sesión se hizo contra el servidor (si fue sin conexión, no se le avisa). */
    private var sesionRemota = false

    /**
     * Ejecuta una llamada al servidor y clasifica el resultado:
     *  OK = respondió bien · RECHAZADO = respondió con error de negocio (400/401/404/409) · SIN_CONEXION = no llegó.
     */
    private suspend fun <T> intentar(llamada: suspend () -> T): Intento<T> = try {
        Intento(Remoto.OK, llamada())
    } catch (e: CancellationException) {
        throw e                                   // nunca se traga la cancelación de corrutinas
    } catch (e: HttpException) {
        Intento(Remoto.RECHAZADO)
    } catch (e: Exception) {
        Intento(Remoto.SIN_CONEXION)              // sin red, servidor apagado, tiempo agotado, JSON inválido...
    }

    // ---------------- Sincronización ----------------

    override suspend fun sincronizarTodo(): Boolean = try {
        val tiendas = api.tiendas.tiendas()
        tiendaDao.guardarTodas(tiendas.map { TiendaEntity(id = it.id, nombre = it.nombre) })
        tiendaDao.borrarFueraDe(tiendas.map { it.id })
        tiendas.forEach { sincronizarTienda(it.id) }
        true
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        false
    }

    override suspend fun sincronizarTienda(tiendaId: Int): Boolean = try {
        val remotos = api.tiendas.probadores(tiendaId)
        val locales = probadorDao.obtenerDeTienda(tiendaId).associateBy { it.id }
        probadorDao.insertarTodos(
            remotos.map { d ->
                val local = locales[d.id]
                ProbadorEntity(
                    id = d.id,
                    numero = d.numero,
                    ocupado = d.ocupado,
                    horaInicio = d.horaInicio,
                    // "alertado" y la foto son propios de cada celular: se conservan mientras sea la misma ocupación.
                    alertado = local != null && local.alertado && d.ocupado && local.horaInicio == d.horaInicio,
                    nota = d.nota,
                    fotoPath = if (d.ocupado) local?.fotoPath else null,
                    tiendaId = d.tiendaId,
                    estadoServicio = d.estadoServicio,
                    motivoServicio = d.motivoServicio
                )
            }
        )
        probadorDao.borrarDeTiendaFueraDe(tiendaId, remotos.map { it.id })
        val config = api.tiendas.configuracion(tiendaId)
        configDao.guardar(ConfiguracionEntity(id = tiendaId, tiempoLimiteMin = config.tiempoLimiteMin))
        val fila = api.tiendas.fila(tiendaId)
        filaDao.guardar(FilaEntity(id = tiendaId, clientesEsperando = fila.clientesEsperando))
        true
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        false
    }

    // ---------------- Tiendas ----------------

    override fun observarTiendas(): Flow<List<TiendaEntity>> = tiendaDao.observarTodas()
    override fun observarResumenTiendas(): Flow<List<ResumenTienda>> = tiendaDao.observarResumen()
    override fun observarTienda(id: Int): Flow<TiendaEntity?> = tiendaDao.observarPorId(id)

    override suspend fun crearTienda(nombre: String, cantidadProbadores: Int): Boolean =
        when (intentar { api.tiendas.crearTienda(CrearTiendaDto(nombre.trim(), cantidadProbadores)) }.estado) {
            Remoto.OK -> { sincronizarTodo(); true }
            Remoto.RECHAZADO -> false                      // ej: ya existe una tienda con ese nombre
            Remoto.SIN_CONEXION -> crearTiendaLocal(nombre, cantidadProbadores)
        }

    private suspend fun crearTiendaLocal(nombre: String, cantidadProbadores: Int): Boolean {
        val id = tiendaDao.insertar(TiendaEntity(nombre = nombre.trim()))
        if (id == -1L) return false          // ya existía una tienda con ese nombre
        val tiendaId = id.toInt()
        // Cada tienda nace con su configuración, su fila de espera y sus probadores numerados 1..N.
        configDao.insertarSiNoExiste(ConfiguracionEntity(id = tiendaId))
        filaDao.insertarSiNoExiste(FilaEntity(id = tiendaId))
        probadorDao.insertarTodos((1..cantidadProbadores).map { ProbadorEntity(numero = it, tiendaId = tiendaId) })
        return true
    }

    // ---------------- Probadores (lectura) ----------------

    override fun observarProbadores(tiendaId: Int) = probadorDao.observarPorTienda(tiendaId)
    override fun observarProbador(id: Int) = probadorDao.observarPorId(id)

    // map { it ?: Default } evita tener que manejar null en el resto de la app.
    override fun observarConfiguracion(tiendaId: Int): Flow<ConfiguracionEntity> =
        configDao.observar(tiendaId).map { it ?: ConfiguracionEntity(id = tiendaId) }

    override fun observarFila(tiendaId: Int): Flow<FilaEntity> =
        filaDao.observar(tiendaId).map { it ?: FilaEntity(id = tiendaId) }

    // ---------------- Acciones del personal ----------------

    override suspend fun ocupar(id: Int) {
        val p = probadorDao.obtener(id) ?: return
        if (intentar { api.tiendas.ocupar(id) }.estado == Remoto.SIN_CONEXION) {
            // Un probador en reparación o no disponible no se puede ocupar.
            if (p.ocupado || EstadoServicio.desde(p.estadoServicio) != EstadoServicio.ACTIVO) return
            // copy() crea una copia de la data class cambiando solo lo indicado (inmutabilidad).
            probadorDao.actualizar(p.copy(ocupado = true, horaInicio = System.currentTimeMillis(), alertado = false))
        } else {
            sincronizarTienda(p.tiendaId)   // el servidor manda: se refleja su estado real (aunque haya rechazado)
        }
    }

    override suspend fun liberar(id: Int) {
        val p = probadorDao.obtener(id) ?: return
        if (intentar { api.tiendas.liberar(id) }.estado == Remoto.SIN_CONEXION) {
            probadorDao.actualizar(
                p.copy(ocupado = false, horaInicio = null, alertado = false, nota = "", fotoPath = null)
            )
        } else {
            probadorDao.limpiarFoto(id)
            sincronizarTienda(p.tiendaId)
        }
    }

    // La alerta de uso prolongado es local: cada celular avisa por su cuenta.
    override suspend fun marcarAlertado(id: Int) {
        val p = probadorDao.obtener(id) ?: return
        probadorDao.actualizar(p.copy(alertado = true))
    }

    override suspend fun guardarNota(id: Int, nota: String) {
        val p = probadorDao.obtener(id) ?: return
        if (intentar { api.tiendas.nota(id, NotaDto(nota)) }.estado == Remoto.SIN_CONEXION) {
            probadorDao.actualizar(p.copy(nota = nota))
        } else {
            sincronizarTienda(p.tiendaId)
        }
    }

    // La foto se guarda solo en el celular (el servidor no recibe imágenes en este MVP).
    override suspend fun guardarFoto(id: Int, ruta: String) {
        val p = probadorDao.obtener(id) ?: return
        probadorDao.actualizar(p.copy(fotoPath = ruta))
    }

    // ---------------- Acciones del administrador ----------------

    override suspend fun agregarProbador(tiendaId: Int) {
        if (intentar { api.tiendas.agregarProbador(tiendaId) }.estado == Remoto.SIN_CONEXION) {
            val siguiente = (probadorDao.maxNumero(tiendaId) ?: 0) + 1
            probadorDao.insertar(ProbadorEntity(numero = siguiente, tiendaId = tiendaId))
        } else {
            sincronizarTienda(tiendaId)
        }
    }

    override suspend fun eliminarProbador(id: Int): Boolean {
        val p = probadorDao.obtener(id) ?: return false
        return when (intentar { api.tiendas.eliminar(id) }.estado) {
            Remoto.OK -> { sincronizarTienda(p.tiendaId); true }
            Remoto.RECHAZADO -> { sincronizarTienda(p.tiendaId); false }   // ej: está ocupado
            Remoto.SIN_CONEXION -> {
                if (p.ocupado) false else { probadorDao.eliminar(id); true }
            }
        }
    }

    override suspend fun cambiarEstadoServicio(id: Int, estado: EstadoServicio, motivo: String): Boolean {
        val p = probadorDao.obtener(id) ?: return false
        return when (intentar { api.tiendas.servicio(id, ServicioDto(estado.name, motivo)) }.estado) {
            Remoto.OK -> { sincronizarTienda(p.tiendaId); true }
            Remoto.RECHAZADO -> { sincronizarTienda(p.tiendaId); false }   // ej: está ocupado
            Remoto.SIN_CONEXION -> {
                if (estado != EstadoServicio.ACTIVO && p.ocupado) false     // primero hay que liberarlo
                else {
                    probadorDao.actualizar(p.copy(estadoServicio = estado.name, motivoServicio = motivo))
                    true
                }
            }
        }
    }

    // ---------------- Configuración y fila ----------------

    override suspend fun guardarTiempoLimite(tiendaId: Int, minutos: Int) {
        if (intentar { api.tiendas.guardarConfiguracion(tiendaId, ConfigDto(minutos)) }.estado == Remoto.SIN_CONEXION) {
            configDao.guardar(ConfiguracionEntity(id = tiendaId, tiempoLimiteMin = minutos))
        } else {
            sincronizarTienda(tiendaId)
        }
    }

    override suspend fun cambiarFila(tiendaId: Int, delta: Int) {
        if (intentar { api.tiendas.cambiarFila(tiendaId, FilaDeltaDto(delta)) }.estado == Remoto.SIN_CONEXION) {
            val actual = filaDao.obtener(tiendaId)?.clientesEsperando ?: 0
            // maxOf(0, ...) evita que la fila quede negativa.
            filaDao.guardar(FilaEntity(id = tiendaId, clientesEsperando = maxOf(0, actual + delta)))
        } else {
            sincronizarTienda(tiendaId)
        }
    }

    // ---------------- Usuarios ----------------

    override suspend fun registrar(
        nombre: String, rut: String, correo: String, cargo: String, clave: String,
        aceptaTerminos: Boolean, rol: String, tiendaId: Int
    ): Boolean {
        val intento = intentar {
            api.auth.registro(
                RegistroDto(nombre.trim(), rut.trim(), correo.trim().lowercase(), cargo.trim(), clave, aceptaTerminos, tiendaId)
            )
        }
        return when (intento.estado) {
            Remoto.OK -> {
                val d = intento.valor!!
                // Se guarda también en Room (con el id del servidor) para poder entrar sin conexión después.
                usuarioDao.guardar(
                    UsuarioEntity(
                        id = d.id, nombre = d.nombre, correo = d.correo, claveHash = Seguridad.hash(clave),
                        aceptaTerminos = aceptaTerminos, rut = d.rut, cargo = d.cargo, rol = d.rol, tiendaId = d.tiendaId
                    )
                )
                true
            }
            Remoto.RECHAZADO -> false          // ej: correo ya registrado
            Remoto.SIN_CONEXION -> {
                val id = usuarioDao.insertar(
                    UsuarioEntity(
                        nombre = nombre.trim(),
                        correo = correo.trim().lowercase(),
                        claveHash = Seguridad.hash(clave),
                        aceptaTerminos = aceptaTerminos,
                        rut = rut.trim(),
                        cargo = cargo.trim(),
                        rol = rol,
                        tiendaId = tiendaId
                    )
                )
                id != -1L   // -1 = ya existía ese correo
            }
        }
    }

    override suspend fun iniciarSesion(correo: String, clave: String): UsuarioEntity? {
        val intento = intentar { api.auth.login(LoginDto(correo.trim().lowercase(), clave)) }
        return when (intento.estado) {
            Remoto.OK -> {
                val d = intento.valor!!
                sesionRemota = true
                UsuarioEntity(
                    id = d.id, nombre = d.nombre, correo = d.correo, claveHash = Seguridad.hash(clave),
                    aceptaTerminos = true, rut = d.rut, cargo = d.cargo, rol = d.rol, tiendaId = d.tiendaId
                ).also { usuarioDao.guardar(it) }
            }
            Remoto.RECHAZADO -> null           // el servidor dijo que el correo o la clave no coinciden
            Remoto.SIN_CONEXION -> {
                // Sin servidor: se entra con la copia local de las cuentas.
                sesionRemota = false
                val usuario = usuarioDao.buscarPorCorreo(correo.trim().lowercase())
                // Se compara hash con hash: la clave real nunca se almacena.
                if (usuario != null && usuario.claveHash == Seguridad.hash(clave)) usuario else null
            }
        }
    }

    override suspend fun guardarTiendaDeTrabajo(usuarioId: Int, tiendaId: Int) {
        if (sesionRemota) intentar { api.auth.cambiarTienda(usuarioId, CambiarTiendaDto(tiendaId)) }
        usuarioDao.cambiarTienda(usuarioId, tiendaId)
    }

    // ---------------- Datos de ejemplo (para trabajar sin servidor) ----------------

    override suspend fun sembrarDatosSiVacio() {
        // 1) Las tres tiendas de ejemplo (solo si no hay ninguna).
        if (tiendaDao.contar() == 0) {
            listOf("Jumbo Chicureo", "Jumbo Costanera", "Jumbo Chamisero").forEach {
                tiendaDao.insertar(TiendaEntity(nombre = it))
            }
        }
        val tiendas = tiendaDao.obtenerTodas()

        // 2) Cada tienda de ejemplo con distinta cantidad de probadores y algunos fuera de servicio.
        //    Solo se siembran las tiendas de esta lista: una tienda creada por el administrador
        //    nunca se rellena sola, aunque le borren todos los probadores.
        val cantidades = mapOf("Jumbo Chicureo" to 8, "Jumbo Costanera" to 12, "Jumbo Chamisero" to 6)
        tiendas.forEach { tienda ->
            configDao.insertarSiNoExiste(ConfiguracionEntity(id = tienda.id))
            filaDao.insertarSiNoExiste(FilaEntity(id = tienda.id))

            val cantidad = cantidades[tienda.nombre] ?: return@forEach
            if (probadorDao.contarPorTienda(tienda.id) == 0) {
                probadorDao.insertarTodos(
                    (1..cantidad).map { numero ->
                        val base = ProbadorEntity(numero = numero, tiendaId = tienda.id)
                        when {
                            tienda.nombre == "Jumbo Costanera" && numero == 4 ->
                                base.copy(estadoServicio = EstadoServicio.EN_REPARACION.name, motivoServicio = "Puerta dañada")
                            tienda.nombre == "Jumbo Chamisero" && numero == 2 ->
                                base.copy(estadoServicio = EstadoServicio.NO_DISPONIBLE.name, motivoServicio = "Espejo roto")
                            else -> base
                        }
                    }
                )
            }
        }

        // 3) Usuarios de prueba (si ya existen, IGNORE no hace nada). Todos con la clave Clave123.
        //    Un asistente por tienda de ejemplo: cada uno parte en su tienda y puede cambiarla desde el panel.
        val primeraTienda = tiendas.firstOrNull()?.id ?: 1
        listOf(
            Triple("Asistente Chicureo", "asistente.chicureo@rincon.cl", "Jumbo Chicureo"),
            Triple("Asistente Costanera", "asistente.costanera@rincon.cl", "Jumbo Costanera"),
            Triple("Asistente Chamisero", "asistente.chamisero@rincon.cl", "Jumbo Chamisero")
        ).forEach { (nombre, correo, nombreTienda) ->
            usuarioDao.insertar(
                UsuarioEntity(
                    nombre = nombre,
                    correo = correo,
                    claveHash = Seguridad.hash("Clave123"),
                    cargo = "Asistente de Probadores",
                    rol = ROL_PERSONAL,
                    tiendaId = tiendas.firstOrNull { it.nombre == nombreTienda }?.id ?: primeraTienda
                )
            )
        }
        usuarioDao.insertar(
            UsuarioEntity(
                nombre = "Administrador Demo",
                correo = "admin@rincon.cl",
                claveHash = Seguridad.hash("Clave123"),
                cargo = "Jefe/a de Tienda (Administrador)",
                rol = ROL_ADMIN,
                tiendaId = 0     // 0 = no pertenece a una tienda: entra a todas
            )
        )
    }
}
