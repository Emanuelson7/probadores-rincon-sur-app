package com.duoc.probadores.ui.detalle

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.duoc.probadores.model.ProbadorEntity
import com.duoc.probadores.data.repository.ProbadorRepository
import com.duoc.probadores.domain.EstadoProbador
import com.duoc.probadores.model.EstadoServicio
import com.duoc.probadores.domain.ReglasProbador
import com.duoc.probadores.domain.Validador
import com.duoc.probadores.util.relojCadaSegundo
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DetalleViewModel(
    private val repo: ProbadorRepository,
    private val id: Int,
    private val tiendaId: Int     // para leer el tiempo límite de ESTA tienda
) : ViewModel() {

    data class DetalleUiState(
        val probador: ProbadorEntity? = null,
        val estado: EstadoProbador = EstadoProbador.LIBRE,
        val segundos: Long = 0
    )

    // Estado "de solo lectura" que viene de la base de datos + reloj.
    val uiState: StateFlow<DetalleUiState> = combine(
        repo.observarProbador(id),
        repo.observarConfiguracion(tiendaId),
        relojCadaSegundo()
    ) { p, config, ahora ->
        DetalleUiState(
            probador = p,
            estado = ReglasProbador.calcularEstado(
                p?.ocupado == true, p?.horaInicio, ahora, config.tiempoLimiteMin,
                EstadoServicio.desde(p?.estadoServicio ?: "")
            ),
            segundos = ReglasProbador.segundosOcupado(p?.horaInicio, ahora)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DetalleUiState())

    // Estado del formulario de reporte.
    var nota by mutableStateOf("")
        private set
    var errorNota by mutableStateOf<String?>(null)
        private set
    /** Mensaje para el Snackbar (aviso temporal inferior). */
    var mensaje by mutableStateOf<String?>(null)
        private set

    init {
        // Carga la nota guardada una sola vez (first() toma el primer valor y termina).
        viewModelScope.launch { nota = repo.observarProbador(id).first()?.nota ?: "" }
    }

    fun ocupar() { viewModelScope.launch { repo.ocupar(id) } }

    fun liberar() {
        viewModelScope.launch {
            repo.liberar(id)
            nota = ""
            errorNota = null
        }
    }

    fun onNotaChange(v: String) { nota = v; errorNota = Validador.nota(v) }

    fun guardarReporte() {
        errorNota = Validador.nota(nota)
        if (errorNota != null) return
        viewModelScope.launch {
            repo.guardarNota(id, nota.trim())
            mensaje = "Reporte guardado"
        }
    }

    fun guardarFoto(ruta: String) {
        viewModelScope.launch {
            repo.guardarFoto(id, ruta)
            mensaje = "Foto guardada"
        }
    }

    fun avisarPermisoDenegado() { mensaje = "Sin permiso de cámara no se puede tomar la foto" }
    fun limpiarMensaje() { mensaje = null }
}
