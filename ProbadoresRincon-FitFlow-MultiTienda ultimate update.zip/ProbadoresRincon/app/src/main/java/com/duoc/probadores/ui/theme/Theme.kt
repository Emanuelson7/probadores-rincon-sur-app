package com.duoc.probadores.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Colores semánticos de los estados del probador (verde / rojo / ámbar).
val ColorLibre = Color(0xFFC8E6C9)
val ColorOcupado = Color(0xFFFFCDD2)
val ColorProlongado = Color(0xFFFFE082)
val ColorFueraServicio = Color(0xFFD9DCE6)   // gris: probador en reparación o no disponible

// Paleta FitFlow (tomada del diseño): azul índigo + grises azulados.
val Indigo = Color(0xFF3A47C9)            // color de marca: botones, enlaces, íconos
val IndigoOscuro = Color(0xFF1B2166)      // final del degradado del splash
val IndigoSuave = Color(0xFFE3E6FA)       // fondo de íconos dentro de tarjetas
val FondoApp = Color(0xFFF4F5FA)          // fondo general de las pantallas
val TextoPrincipal = Color(0xFF1A1D2E)
val TextoSecundario = Color(0xFF6B7085)
val BordeCampo = Color(0xFFE0E3EE)
val BotonDeshabilitado = Color(0xFFC5CAE1)
val ColorExito = Color(0xFF2E9E6A)        // campo válido, requisito cumplido
val ColorError = Color(0xFFD32F3F)        // campo con error

// Esquema de colores de Material Design 3.
private val Esquema = lightColorScheme(
    primary = Indigo,
    onPrimary = Color.White,
    primaryContainer = IndigoSuave,
    onPrimaryContainer = Indigo,
    secondary = ColorExito,
    background = FondoApp,
    onBackground = TextoPrincipal,
    surface = Color.White,
    onSurface = TextoPrincipal,
    onSurfaceVariant = TextoSecundario,
    outline = BordeCampo,
    error = ColorError
)

// Esquinas más redondeadas, como en el diseño.
private val Formas = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp)
)

/** Envuelve toda la app: cualquier Composable hijo hereda estos colores y formas. */
@Composable
fun ProbadoresTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Esquema, shapes = Formas, content = content)
}
