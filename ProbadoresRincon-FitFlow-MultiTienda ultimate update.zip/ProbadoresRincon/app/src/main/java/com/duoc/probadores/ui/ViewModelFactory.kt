package com.duoc.probadores.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.duoc.probadores.ProbadoresApp
import com.duoc.probadores.ui.administrar.AdministrarViewModel
import com.duoc.probadores.ui.configuracion.ConfiguracionViewModel
import com.duoc.probadores.ui.detalle.DetalleViewModel
import com.duoc.probadores.ui.login.LoginViewModel
import com.duoc.probadores.ui.panel.PanelViewModel
import com.duoc.probadores.ui.registro.RegistroViewModel
import com.duoc.probadores.ui.tiendas.TiendasViewModel

/**
 * Los ViewModels necesitan parámetros (el repositorio), y Android por defecto solo sabe crear
 * ViewModels sin parámetros. Esta "fábrica" le enseña cómo construir cada uno.
 */
class ViewModelFactory(
    private val app: ProbadoresApp,
    private val idProbador: Int = 0,  // solo lo usa DetalleViewModel
    private val idTienda: Int = 0     // tienda con la que trabaja el ViewModel (panel, detalle, config, administrar)
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(LoginViewModel::class.java) -> LoginViewModel(app.repositorio)
        modelClass.isAssignableFrom(RegistroViewModel::class.java) -> RegistroViewModel(app.repositorio)
        modelClass.isAssignableFrom(PanelViewModel::class.java) -> PanelViewModel(app.repositorio, app.notificador, idTienda)
        modelClass.isAssignableFrom(DetalleViewModel::class.java) -> DetalleViewModel(app.repositorio, idProbador, idTienda)
        modelClass.isAssignableFrom(ConfiguracionViewModel::class.java) -> ConfiguracionViewModel(app.repositorio, idTienda)
        modelClass.isAssignableFrom(TiendasViewModel::class.java) -> TiendasViewModel(app.repositorio)
        modelClass.isAssignableFrom(AdministrarViewModel::class.java) -> AdministrarViewModel(app.repositorio, idTienda)
        else -> throw IllegalArgumentException("ViewModel desconocido: ${modelClass.name}")
    } as T
}

/** Atajo para obtener la Application desde cualquier Composable. */
@Composable
fun rememberApp(): ProbadoresApp = LocalContext.current.applicationContext as ProbadoresApp
