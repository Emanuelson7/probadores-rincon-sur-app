package com.duoc.probadores.util

import java.security.MessageDigest

object Seguridad {
    /**
     * Convierte la clave en un hash SHA-256 (texto hexadecimal).
     * NOTA PARA ESTUDIAR: en una app real se usa además una "sal" aleatoria y un algoritmo
     * lento (bcrypt/Argon2). Para este MVP académico SHA-256 basta para no guardar claves planas.
     */
    fun hash(texto: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(texto.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
