package com.duoc.probadores.ui.configuracion

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.duoc.probadores.data.repository.ProbadorRepository
import com.duoc.probadores.domain.Validador
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ConfiguracionViewModel(
    private val repo: ProbadorRepository,
    private val tiendaId: Int      // la configuración (tiempo límite) es propia de cada tienda
) : ViewModel() {

    // El campo es de texto (TextField), aunque el dato real es un número.
    var tiempo by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var guardado by mutableStateOf(false)
        private set

    init {
        viewModelScope.launch { tiempo = repo.observarConfiguracion(tiendaId).first().tiempoLimiteMin.toString() }
    }

    fun onTiempoChange(v: String) {
        // filter { isDigit }: ignora cualquier carácter que no sea número.
        tiempo = v.filter { it.isDigit() }
        error = Validador.tiempoLimite(tiempo)
        guardado = false
    }

    fun guardar() {
        error = Validador.tiempoLimite(tiempo)
        if (error != null) return
        viewModelScope.launch {
            repo.guardarTiempoLimite(tiendaId, tiempo.toInt())
            guardado = true
        }
    }
}
