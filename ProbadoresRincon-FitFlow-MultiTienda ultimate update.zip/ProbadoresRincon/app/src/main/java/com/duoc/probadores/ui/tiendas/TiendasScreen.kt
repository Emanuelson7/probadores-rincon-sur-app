package com.duoc.probadores.ui.tiendas

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.probadores.ui.ViewModelFactory
import com.duoc.probadores.ui.components.CampoValidado
import com.duoc.probadores.ui.rememberApp
import com.duoc.probadores.ui.theme.ColorError
import com.duoc.probadores.ui.theme.Indigo
import com.duoc.probadores.ui.theme.TextoPrincipal
import com.duoc.probadores.ui.theme.TextoSecundario

/**
 * Pantalla de inicio del ADMINISTRADOR: elige a qué tienda entrar o crea una nueva.
 * El personal normal no pasa por aquí: entra directo al panel de su tienda.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TiendasScreen(onAbrirTienda: (Int) -> Unit, onSalir: () -> Unit) {
    val app = rememberApp()
    val vm: TiendasViewModel = viewModel(factory = ViewModelFactory(app))
    val tiendas by vm.tiendas.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    // Cuando el ViewModel publica un mensaje, se muestra y se limpia.
    LaunchedEffect(vm.mensaje) {
        vm.mensaje?.let {
            snackbar.showSnackbar(it)
            vm.limpiarMensaje()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Tiendas", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                actions = { TextButton(onClick = onSalir) { Text("Salir") } }
            )
        },
        floatingActionButton = {
            // Solo el administrador puede crear tiendas.
            if (app.esAdmin) {
                ExtendedFloatingActionButton(
                    onClick = vm::abrirDialogo,
                    containerColor = Indigo,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Nueva tienda") }
                )
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            // 88.dp abajo: deja espacio para que el botón flotante no tape la última tienda.
            contentPadding = PaddingValues(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                    Text("Hola, ${app.nombreUsuario}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = TextoPrincipal)
                    Text(
                        if (app.esAdmin) "Elige la tienda a la que vas a entrar" else "Elige la tienda donde vas a trabajar",
                        fontSize = 12.sp, color = TextoSecundario
                    )
                }
            }
            items(tiendas, key = { it.id }) { t ->
                Card(
                    onClick = { vm.elegirTienda(t.id, app.usuarioId, app.esAdmin) { onAbrirTienda(t.id) } },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Default.Home, contentDescription = null, tint = Indigo)
                        Column {
                            Text(t.nombre, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextoPrincipal)
                            Text("${t.total} probadores", fontSize = 12.sp, color = TextoSecundario)
                            if (t.fueraServicio > 0) {
                                Text("${t.fueraServicio} fuera de servicio", fontSize = 12.sp, color = ColorError)
                            }
                        }
                    }
                }
            }
        }
    }

    if (vm.mostrarDialogo) {
        AlertDialog(
            onDismissRequest = vm::cerrarDialogo,
            title = { Text("Nueva tienda") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CampoValidado(
                        valor = vm.nombre, onCambio = vm::onNombreChange, etiqueta = "Nombre de la tienda",
                        iconoInicial = Icons.Default.Home, error = vm.errorNombre, sugerencia = "Jumbo Vitacura"
                    )
                    CampoValidado(
                        valor = vm.cantidad, onCambio = vm::onCantidadChange, etiqueta = "Cantidad de probadores",
                        iconoInicial = Icons.Default.Add, error = vm.errorCantidad,
                        teclado = KeyboardType.Number, sugerencia = "8"
                    )
                }
            },
            confirmButton = { TextButton(onClick = vm::crear) { Text("Crear") } },
            dismissButton = { TextButton(onClick = vm::cerrarDialogo) { Text("Cancelar") } }
        )
    }
}
