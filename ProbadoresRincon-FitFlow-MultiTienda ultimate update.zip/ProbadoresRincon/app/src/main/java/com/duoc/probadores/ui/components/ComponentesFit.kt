package com.duoc.probadores.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.duoc.probadores.model.FuerzaClave
import com.duoc.probadores.ui.theme.BordeCampo
import com.duoc.probadores.ui.theme.BotonDeshabilitado
import com.duoc.probadores.ui.theme.ColorError
import com.duoc.probadores.ui.theme.ColorExito
import com.duoc.probadores.ui.theme.Indigo
import com.duoc.probadores.ui.theme.TextoSecundario

/** Logo de FitFlow: cuadrado redondeado con un cronómetro. Por defecto azul con ícono blanco. */
@Composable
fun LogoFit(
    tamano: Dp,
    modifier: Modifier = Modifier,
    fondo: Color = Indigo,
    icono: Color = Color.White
) {
    Box(
        modifier = modifier
            .size(tamano)
            .clip(RoundedCornerShape(tamano * 0.28f))
            .background(fondo),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Default.Timer, contentDescription = null, tint = icono, modifier = Modifier.size(tamano * 0.6f))
    }
}

/** Círculo rojo con "!" que aparece dentro de los campos con error. */
@Composable
fun IconoErrorFit() {
    Box(
        modifier = Modifier.size(20.dp).clip(CircleShape).background(ColorError),
        contentAlignment = Alignment.Center
    ) {
        Text("!", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

/** Botón principal azul. Cuando [enabled] es false se ve lavanda, como en el diseño. */
@Composable
fun BotonFit(texto: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Indigo,
            contentColor = Color.White,
            disabledContainerColor = BotonDeshabilitado,
            disabledContentColor = Color.White
        ),
        modifier = modifier.fillMaxWidth().height(50.dp)
    ) { Text(texto, fontWeight = FontWeight.Bold) }
}

/** Barra de progreso de pasos ("Paso 1 de 2"). [fraccion] va de 0f a 1f y se anima al cambiar. */
@Composable
fun BarraPaso(fraccion: Float, modifier: Modifier = Modifier) {
    val animada by animateFloatAsState(targetValue = fraccion, label = "barraPaso")
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(BordeCampo)
    ) {
        Box(
            Modifier
                .fillMaxWidth(animada)
                .fillMaxHeight()
                .clip(RoundedCornerShape(3.dp))
                .background(Indigo)
        )
    }
}

/** Barra de 4 segmentos + texto "Fortaleza: ..." + lista de requisitos (✓ cumplido / ✗ falta). */
@Composable
fun IndicadorFuerza(fuerza: FuerzaClave, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(4) { indice ->
                val color = when {
                    indice >= fuerza.puntaje -> BordeCampo
                    fuerza.puntaje <= 1 -> ColorError
                    else -> ColorExito
                }
                Box(
                    Modifier
                        .weight(1f)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(color)
                )
            }
        }
        Text("Fortaleza: ${fuerza.etiqueta}", fontSize = 11.sp, color = TextoSecundario)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Requisito("8 caracteres", fuerza.tieneLargo)
            Requisito("Mayúscula", fuerza.tieneMayuscula)
            Requisito("Número", fuerza.tieneNumero)
            Requisito("Símbolo", fuerza.tieneSimbolo)
        }
    }
}

@Composable
private fun Requisito(texto: String, cumple: Boolean) {
    Text(
        text = if (cumple) "✓ $texto" else "✗ $texto",
        fontSize = 11.sp,
        color = if (cumple) ColorExito else ColorError
    )
}
