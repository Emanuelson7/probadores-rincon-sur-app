package com.duoc.probadores.domain

import com.duoc.probadores.model.FuerzaClave

/**
 * VALIDACIONES centralizadas y desacopladas de la interfaz (rúbrica IE 2.2.1).
 * Cada función devuelve:
 *   - null            -> el valor es válido
 *   - un String       -> el mensaje de error que la UI mostrará bajo el campo
 * La UI NO decide si algo es válido; solo muestra lo que diga el ViewModel/Validador.
 */
object Validador {
    private val regexCorreo = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    /** Largo mínimo de la contraseña (el diseño FitFlow pide 8 caracteres). */
    const val LARGO_MIN_CLAVE = 8

    fun nombre(v: String): String? = when {
        v.isBlank() -> "El nombre es obligatorio"
        v.trim().length < 3 -> "Debe tener al menos 3 caracteres"
        else -> null
    }

    fun correo(v: String): String? = when {
        v.isBlank() -> "El correo es obligatorio"
        !regexCorreo.matches(v.trim()) -> "Ingresa un correo válido (ej: nombre@correo.com)"
        else -> null
    }

    fun clave(v: String): String? = when {
        v.isBlank() -> "La contraseña es obligatoria"
        v.length < LARGO_MIN_CLAVE -> "Debe tener al menos $LARGO_MIN_CLAVE caracteres"
        v.none { it.isDigit() } -> "Debe incluir al menos un número"
        v.none { it.isLetter() } -> "Debe incluir al menos una letra"
        else -> null
    }

    /**
     * Validación de la clave en la pantalla de LOGIN: solo revisa que exista y tenga el largo mínimo.
     * (Las reglas de número/letra se exigen al crear la cuenta; aquí basta con el largo.)
     */
    fun claveIngreso(v: String): String? = when {
        v.isBlank() -> "La contraseña es obligatoria"
        v.length < LARGO_MIN_CLAVE -> "Debe tener al menos $LARGO_MIN_CLAVE caracteres"
        else -> null
    }

    /** Evalúa los 4 criterios del indicador de fortaleza (8 caracteres, mayúscula, número, símbolo). */
    fun fuerzaClave(v: String) = FuerzaClave(
        tieneLargo = v.length >= LARGO_MIN_CLAVE,
        tieneMayuscula = v.any { it.isUpperCase() },
        tieneNumero = v.any { it.isDigit() },
        tieneSimbolo = v.any { !it.isLetterOrDigit() }
    )

    fun direccion(v: String): String? = when {
        v.isBlank() -> "La dirección es obligatoria"
        v.trim().length < 5 -> "Ingresa una dirección más completa"
        else -> null
    }

    fun confirmarClave(clave: String, confirmacion: String): String? = when {
        confirmacion.isBlank() -> "Confirma tu contraseña"
        clave != confirmacion -> "Las contraseñas no coinciden"
        else -> null
    }


    // ---------------- RUT chileno ----------------

    /** Deja solo dígitos y la letra K (mayúscula). Ej: "12.345.678-k" -> "12345678K". */
    private fun limpiarRut(v: String): String =
        v.filter { it in '0'..'9' || it == 'k' || it == 'K' }.uppercase()

    /**
     * Calcula el dígito verificador con el algoritmo módulo 11:
     * se multiplica cada dígito (de derecha a izquierda) por 2,3,4,5,6,7,2,3... y se suman.
     * El dígito es 11 - (suma % 11); si da 11 es '0' y si da 10 es 'K'.
     */
    fun calcularDv(cuerpo: String): Char {
        var suma = 0
        var factor = 2
        for (c in cuerpo.reversed()) {
            suma += (c - '0') * factor
            factor = if (factor == 7) 2 else factor + 1
        }
        return when (val r = 11 - suma % 11) {
            11 -> '0'
            10 -> 'K'
            else -> '0' + r
        }
    }

    fun rut(v: String): String? {
        if (v.isBlank()) return "El RUT es obligatorio"
        val limpio = limpiarRut(v)
        val cuerpo = limpio.dropLast(1)
        if (limpio.length !in 8..9 || !cuerpo.all { it in '0'..'9' }) {
            return "Formato de RUT inválido (ej: 12.345.678-5)"
        }
        return if (calcularDv(cuerpo) == limpio.last()) null else "RUT inválido, revisa el dígito verificador"
    }

    /** Da formato mientras se escribe: "123456785" -> "12.345.678-5". */
    fun formatearRut(v: String): String {
        val limpio = limpiarRut(v).take(9)
        if (limpio.length <= 1) return limpio
        val cuerpo = limpio.dropLast(1)
        val conPuntos = cuerpo.reversed().chunked(3).joinToString(".").reversed()
        return "$conPuntos-${limpio.last()}"
    }

    fun cargo(v: String): String? = if (v.isBlank()) "Selecciona un cargo" else null

    fun tienda(v: String): String? = if (v.isBlank()) "Selecciona una tienda" else null

    // ---------------- Administración de tiendas ----------------

    fun nombreTienda(v: String): String? = when {
        v.isBlank() -> "El nombre de la tienda es obligatorio"
        v.trim().length < 3 -> "Debe tener al menos 3 caracteres"
        v.trim().length > 40 -> "Máximo 40 caracteres"
        else -> null
    }

    /** La cantidad llega como texto (viene de un TextField), por eso se convierte aquí. */
    fun cantidadProbadores(v: String): String? {
        if (v.isBlank()) return "Ingresa la cantidad"
        val n = v.toIntOrNull() ?: return "Solo números enteros"
        return if (n !in 1..30) "Debe estar entre 1 y 30" else null
    }

    /** Motivo obligatorio cuando un probador queda en reparación o no disponible. */
    fun motivoServicio(v: String): String? = when {
        v.isBlank() -> "Indica el motivo (ej: puerta dañada)"
        v.trim().length < 3 -> "Mínimo 3 caracteres"
        v.length > 100 -> "Máximo 100 caracteres"
        else -> null
    }

    /** El tiempo límite llega como texto (viene de un TextField), por eso se convierte aquí. */
    fun tiempoLimite(v: String): String? {
        if (v.isBlank()) return "Ingresa los minutos"
        val n = v.toIntOrNull() ?: return "Solo números enteros"
        return if (n !in 1..120) "Debe estar entre 1 y 120 minutos" else null
    }

    fun nota(v: String): String? = when {
        v.isBlank() -> "Describe lo que encontraste"
        v.trim().length < 5 -> "Mínimo 5 caracteres"
        v.length > 200 -> "Máximo 200 caracteres"
        else -> null
    }
}
