package com.duoc.probadores.data.remote

/*
 * DTO (Data Transfer Object) = clases que representan el JSON que viaja por la API REST.
 * Los nombres de los campos son los mismos que usa el backend Spring Boot: Gson los convierte solo.
 * Son distintos de las entidades de Room (model/Entidades.kt), que representan las tablas locales.
 */

// ---------- auth-service ----------
data class LoginDto(val correo: String, val clave: String)

data class RegistroDto(
    val nombre: String,
    val rut: String,
    val correo: String,
    val cargo: String,
    val clave: String,
    val aceptaTerminos: Boolean,
    val tiendaId: Int
)

data class CambiarTiendaDto(val tiendaId: Int)

/** Usuario que devuelve el servidor: nunca incluye la clave ni su hash. */
data class UsuarioDto(
    val id: Int,
    val nombre: String,
    val rut: String,
    val correo: String,
    val cargo: String,
    val rol: String,
    val tiendaId: Int
)

// ---------- tiendas-service ----------
data class TiendaResumenDto(val id: Int, val nombre: String, val total: Int, val fueraServicio: Int)

data class CrearTiendaDto(val nombre: String, val cantidadProbadores: Int)

data class ProbadorDto(
    val id: Int,
    val tiendaId: Int,
    val numero: Int,
    val ocupado: Boolean,
    val horaInicio: Long?,
    val nota: String,
    val estadoServicio: String,
    val motivoServicio: String
)

data class ServicioDto(val estado: String, val motivo: String)
data class NotaDto(val nota: String)
data class ConfigDto(val tiempoLimiteMin: Int)
data class FilaDto(val clientesEsperando: Int)
data class FilaDeltaDto(val delta: Int)

/** Respuesta simple {"mensaje": "..."}: confirmaciones y errores del servidor. */
data class MensajeDto(val mensaje: String)
