package com.duoc.probadores.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.duoc.probadores.ui.theme.BordeCampo
import com.duoc.probadores.ui.theme.ColorError
import com.duoc.probadores.ui.theme.ColorExito
import com.duoc.probadores.ui.theme.Indigo
import com.duoc.probadores.ui.theme.TextoPrincipal
import com.duoc.probadores.ui.theme.TextoSecundario

/** Colores del campo según su estado: error (rojo), válido (verde) o neutro (gris). */
@Composable
private fun coloresCampo(hayError: Boolean, esValido: Boolean): TextFieldColors =
    OutlinedTextFieldDefaults.colors(
        focusedBorderColor = if (hayError) ColorError else if (esValido) ColorExito else Indigo,
        unfocusedBorderColor = if (hayError) ColorError else if (esValido) ColorExito else BordeCampo,
        errorBorderColor = ColorError,
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White,
        errorContainerColor = Color.White,
        focusedLeadingIconColor = TextoSecundario,
        unfocusedLeadingIconColor = TextoSecundario,
        errorLeadingIconColor = TextoSecundario,
        focusedTrailingIconColor = TextoSecundario,
        unfocusedTrailingIconColor = TextoSecundario,
        errorTrailingIconColor = TextoSecundario
    )

/** Etiqueta pequeña que va ARRIBA del campo (en el diseño no es una etiqueta flotante). */
@Composable
private fun EtiquetaCampo(texto: String) {
    Text(texto, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextoPrincipal)
    Spacer(Modifier.height(6.dp))
}

/** Mensaje de error rojo debajo del campo. */
@Composable
private fun MensajeError(error: String?) {
    if (error != null) {
        Text(error, fontSize = 11.sp, color = ColorError, modifier = Modifier.padding(top = 4.dp))
    }
}

/**
 * Campo de texto reutilizable con retroalimentación visual (rúbrica IE 2.1.2):
 *  - ícono inicial según el tipo de dato
 *  - si hay error: borde rojo, mensaje debajo e ícono "!" rojo
 *  - si es válido y tiene texto: borde verde e ícono de check
 *  - si es clave: botón de ojo para mostrar/ocultar
 * Es "tonto": no valida nada, solo muestra el [error] que le pasa el ViewModel.
 * Esto se llama "state hoisting": el estado vive afuera y el Composable solo lo dibuja.
 */
@Composable
fun CampoValidado(
    valor: String,
    onCambio: (String) -> Unit,
    etiqueta: String,
    iconoInicial: ImageVector,
    error: String?,
    modifier: Modifier = Modifier,
    esClave: Boolean = false,
    teclado: KeyboardType = KeyboardType.Text,
    unaLinea: Boolean = true,
    sugerencia: String = ""
) {
    // Estado local solo de interfaz (ver/ocultar clave): no es lógica de negocio, no va al ViewModel.
    var claveVisible by remember { mutableStateOf(false) }
    val hayError = error != null
    val esValido = !hayError && valor.isNotEmpty()

    Column(modifier.fillMaxWidth()) {
        EtiquetaCampo(etiqueta)
        OutlinedTextField(
            value = valor,
            onValueChange = onCambio,
            placeholder = { if (sugerencia.isNotEmpty()) Text(sugerencia, color = TextoSecundario) },
            leadingIcon = { Icon(iconoInicial, contentDescription = null, modifier = Modifier.size(20.dp)) },
            trailingIcon = {
                if (esClave) {
                    IconButton(onClick = { claveVisible = !claveVisible }) {
                        Icon(
                            if (claveVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (claveVisible) "Ocultar contraseña" else "Mostrar contraseña",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                } else if (hayError) {
                    IconoErrorFit()
                } else if (esValido) {
                    Icon(Icons.Default.Check, contentDescription = "Válido", tint = ColorExito, modifier = Modifier.size(20.dp))
                }
            },
            isError = hayError,
            singleLine = unaLinea,
            visualTransformation = if (esClave && !claveVisible) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = teclado),
            shape = RoundedCornerShape(12.dp),
            colors = coloresCampo(hayError, esValido),
            modifier = Modifier.fillMaxWidth()
        )
        MensajeError(error)
    }
}

/**
 * Lista desplegable (para el "Cargo"). Es un campo de solo lectura: el usuario no escribe,
 * elige una opción del menú. Igual que [CampoValidado], el estado (valor y error) vive afuera.
 */
@OptIn(ExperimentalMaterial3Api::class) // ExposedDropdownMenuBox aún está marcado como experimental
@Composable
fun CampoSelector(
    valor: String,
    opciones: List<String>,
    onSeleccion: (String) -> Unit,
    etiqueta: String,
    iconoInicial: ImageVector,
    error: String?,
    modifier: Modifier = Modifier,
    sugerencia: String = ""
) {
    var abierto by remember { mutableStateOf(false) }
    val hayError = error != null

    Column(modifier.fillMaxWidth()) {
        EtiquetaCampo(etiqueta)
        ExposedDropdownMenuBox(expanded = abierto, onExpandedChange = { abierto = it }) {
            OutlinedTextField(
                value = valor,
                onValueChange = {},          // no se escribe: solo se elige del menú
                readOnly = true,
                placeholder = { Text(sugerencia, color = TextoSecundario) },
                leadingIcon = { Icon(iconoInicial, contentDescription = null, modifier = Modifier.size(20.dp)) },
                trailingIcon = { Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Abrir lista") },
                isError = hayError,
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = coloresCampo(hayError, esValido = false),
                modifier = Modifier
                    .menuAnchor()            // ancla el menú a este campo
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(expanded = abierto, onDismissRequest = { abierto = false }) {
                opciones.forEach { opcion ->
                    DropdownMenuItem(
                        text = { Text(opcion) },
                        onClick = {
                            onSeleccion(opcion)
                            abierto = false
                        }
                    )
                }
            }
        }
        MensajeError(error)
    }
}
