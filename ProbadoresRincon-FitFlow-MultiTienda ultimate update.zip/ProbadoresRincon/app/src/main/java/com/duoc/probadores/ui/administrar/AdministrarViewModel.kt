package com.duoc.probadores.ui.administrar

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.duoc.probadores.model.ProbadorEntity
import com.duoc.probadores.model.TiendaEntity
import com.duoc.probadores.data.repository.ProbadorRepository
import com.duoc.probadores.model.EstadoServicio
import com.duoc.probadores.domain.Validador
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Pantalla del ADMINISTRADOR para UNA tienda: agregar o quitar probadores y cambiar su estado
 * de servicio (operativo / en reparación / no disponible) indicando el motivo.
 */
class AdministrarViewModel(
    private val repo: ProbadorRepository,
    private val tiendaId: Int
) : ViewModel() {

    val tienda: StateFlow<TiendaEntity?> = repo.observarTienda(tiendaId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val probadores: StateFlow<List<ProbadorEntity>> = repo.observarProbadores(tiendaId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    // --- Diálogo "cambiar estado" ---
    /** Probador que se está editando; null = diálogo cerrado. */
    var editando by mutableStateOf<ProbadorEntity?>(null)
        private set
    var estadoElegido by mutableStateOf(EstadoServicio.ACTIVO)
        private set
    var motivo by mutableStateOf("")
        private set
    var errorMotivo by mutableStateOf<String?>(null)
        private set

    // --- Diálogo "eliminar" ---
    var porEliminar by mutableStateOf<ProbadorEntity?>(null)
        private set

    /** Mensaje para el Snackbar (aviso temporal inferior). */
    var mensaje by mutableStateOf<String?>(null)
        private set

    fun agregarProbador() {
        viewModelScope.launch {
            repo.agregarProbador(tiendaId)
            mensaje = "Probador agregado"
        }
    }

    fun abrirEstado(p: ProbadorEntity) {
        editando = p
        estadoElegido = EstadoServicio.desde(p.estadoServicio)
        motivo = p.motivoServicio
        errorMotivo = null
    }

    fun cerrarEstado() { editando = null }

    fun elegirEstado(e: EstadoServicio) { estadoElegido = e; errorMotivo = null }

    fun onMotivoChange(v: String) { motivo = v; errorMotivo = Validador.motivoServicio(v) }

    fun guardarEstado() {
        val p = editando ?: return
        // El motivo solo es obligatorio si el probador queda fuera de servicio.
        if (estadoElegido != EstadoServicio.ACTIVO) {
            errorMotivo = Validador.motivoServicio(motivo)
            if (errorMotivo != null) return
        }
        viewModelScope.launch {
            val motivoFinal = if (estadoElegido == EstadoServicio.ACTIVO) "" else motivo.trim()
            val ok = repo.cambiarEstadoServicio(p.id, estadoElegido, motivoFinal)
            mensaje = if (ok) "Probador ${p.numero}: ${estadoElegido.etiqueta}"
            else "Primero libera el probador ${p.numero} (está ocupado)"
            editando = null
        }
    }

    fun pedirEliminar(p: ProbadorEntity) { porEliminar = p }
    fun cancelarEliminar() { porEliminar = null }

    fun confirmarEliminar() {
        val p = porEliminar ?: return
        viewModelScope.launch {
            mensaje = if (repo.eliminarProbador(p.id)) "Probador ${p.numero} eliminado"
            else "No se puede eliminar un probador ocupado"
            porEliminar = null
        }
    }

    fun limpiarMensaje() { mensaje = null }
}
