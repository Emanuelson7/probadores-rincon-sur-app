package com.duoc.probadores.util

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/** Flow que emite la hora actual cada segundo. Sirve para refrescar los cronómetros. */
fun relojCadaSegundo(): Flow<Long> = flow {
    while (true) {
        emit(System.currentTimeMillis())
        delay(1_000)
    }
}

/** 125 segundos -> "02:05" */
fun formatearTiempo(segundos: Long): String = "%02d:%02d".format(segundos / 60, segundos % 60)
