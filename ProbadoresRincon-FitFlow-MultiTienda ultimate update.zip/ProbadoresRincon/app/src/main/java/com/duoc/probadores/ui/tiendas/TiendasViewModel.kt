package com.duoc.probadores.ui.tiendas

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.duoc.probadores.model.ResumenTienda
import com.duoc.probadores.data.repository.ProbadorRepository
import com.duoc.probadores.domain.Validador
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Pantalla del ADMINISTRADOR: lista de tiendas y formulario para crear una nueva. */
class TiendasViewModel(private val repo: ProbadorRepository) : ViewModel() {

    /** Tiendas con su cantidad de probadores y cuántos están fuera de servicio. */
    val tiendas: StateFlow<List<ResumenTienda>> = repo.observarResumenTiendas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        // Al abrir la lista se descargan las tiendas del servidor (si hay conexión).
        viewModelScope.launch { repo.sincronizarTodo() }
    }

    // Estado del cuadro de diálogo "Nueva tienda".
    var mostrarDialogo by mutableStateOf(false)
        private set
    var nombre by mutableStateOf("")
        private set
    var cantidad by mutableStateOf("")
        private set
    var errorNombre by mutableStateOf<String?>(null)
        private set
    var errorCantidad by mutableStateOf<String?>(null)
        private set
    /** Mensaje para el Snackbar (aviso temporal inferior). */
    var mensaje by mutableStateOf<String?>(null)
        private set

    fun abrirDialogo() {
        nombre = ""
        cantidad = ""
        errorNombre = null
        errorCantidad = null
        mostrarDialogo = true
    }

    fun cerrarDialogo() { mostrarDialogo = false }

    fun onNombreChange(v: String) { nombre = v; errorNombre = Validador.nombreTienda(v) }

    fun onCantidadChange(v: String) {
        cantidad = v.filter { it.isDigit() }
        errorCantidad = Validador.cantidadProbadores(cantidad)
    }

    fun crear() {
        errorNombre = Validador.nombreTienda(nombre)
        errorCantidad = Validador.cantidadProbadores(cantidad)
        if (errorNombre != null || errorCantidad != null) return

        viewModelScope.launch {
            if (repo.crearTienda(nombre, cantidad.toInt())) {
                mostrarDialogo = false
                mensaje = "Tienda creada"
            } else {
                errorNombre = "Ya existe una tienda con ese nombre"
            }
        }
    }

    /**
     * El asistente elige dónde va a trabajar: se recuerda para su próximo ingreso y se abre esa tienda.
     * El administrador no guarda nada (entra a todas), solo se abre la tienda.
     */
    fun elegirTienda(tiendaId: Int, usuarioId: Int, esAdmin: Boolean, alTerminar: () -> Unit) {
        viewModelScope.launch {
            if (!esAdmin) repo.guardarTiendaDeTrabajo(usuarioId, tiendaId)
            alTerminar()
        }
    }

    fun limpiarMensaje() { mensaje = null }
}
