package com.duoc.probadores

import android.app.Application
import com.duoc.probadores.data.local.AppDatabase
import com.duoc.probadores.data.repository.ProbadorRepository
import com.duoc.probadores.data.remote.ApiFitFlow
import com.duoc.probadores.data.repository.ProbadorRepositoryImpl
import com.duoc.probadores.util.Notificador
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * La clase Application se crea UNA vez, antes que cualquier pantalla (está declarada en el
 * AndroidManifest). La usamos como "contenedor" simple de dependencias (inyección manual):
 * aquí se construyen la base de datos, el repositorio y el notificador.
 * (Hilt/Koin harían esto automáticamente; para el Parcial 2 basta lo manual.)
 */
class ProbadoresApp : Application() {

    lateinit var repositorio: ProbadorRepository
        private set
    lateinit var notificador: Notificador
        private set

    /** Nombre del usuario que inició sesión (se muestra en la barra superior). */
    var nombreUsuario: String = ""

    /** true si quien inició sesión es administrador (ve todas las tiendas y puede administrarlas). */
    var esAdmin: Boolean = false

    /** id del usuario con sesión iniciada (sirve para recordar su tienda de trabajo). */
    var usuarioId: Int = 0

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.crear(this)
        repositorio = ProbadorRepositoryImpl(
            db.probadorDao(), db.configuracionDao(), db.filaDao(), db.usuarioDao(), db.tiendaDao(), ApiFitFlow.crear()
        )
        notificador = Notificador(this).also { it.crearCanal() }

        // Cargar datos ficticios en segundo plano (Dispatchers.IO = hilo para disco/red).
        CoroutineScope(Dispatchers.IO).launch { repositorio.sembrarDatosSiVacio() }
    }
}
