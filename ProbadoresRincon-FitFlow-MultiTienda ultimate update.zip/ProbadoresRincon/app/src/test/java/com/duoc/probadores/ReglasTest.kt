package com.duoc.probadores

import com.duoc.probadores.domain.EstadoProbador
import com.duoc.probadores.model.EstadoServicio
import com.duoc.probadores.domain.ReglasProbador
import com.duoc.probadores.domain.Validador
import com.duoc.probadores.domain.fueraDeServicio
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pruebas unitarias: se ejecutan en el PC (sin emulador) con ./gradlew test.
 * Son posibles justamente porque la lógica está separada de la interfaz.
 */
class ReglasTest {

    @Test fun probadorNoOcupadoEstaLibre() {
        assertEquals(EstadoProbador.LIBRE, ReglasProbador.calcularEstado(false, null, 0L, 15))
    }

    @Test fun probadorOcupadoPocoTiempoEsOcupado() {
        val ahora = 5 * 60_000L
        assertEquals(EstadoProbador.OCUPADO, ReglasProbador.calcularEstado(true, 0L, ahora, 15))
    }

    @Test fun probadorQueSuperaElLimiteEsProlongado() {
        val ahora = 20 * 60_000L
        assertEquals(EstadoProbador.PROLONGADO, ReglasProbador.calcularEstado(true, 0L, ahora, 15))
    }

    @Test fun correoValidoEInvalido() {
        assertNull(Validador.correo("operador@rincon.cl"))
        assertNotNull(Validador.correo("correo-malo"))
    }

    @Test fun claveDebeTenerNumeroYLargoMinimo() {
        assertNull(Validador.clave("Clave123"))
        assertNotNull(Validador.clave("abc"))
        assertNotNull(Validador.clave("soloLetras"))
    }

    @Test fun claveDeMenosDeOchoCaracteresEsInvalida() {
        assertNotNull(Validador.clave("Abc123"))        // 6 caracteres
        assertNotNull(Validador.clave("Abcde12"))       // 7 caracteres
        assertNull(Validador.clave("Abcdef12"))         // 8 caracteres
    }

    @Test fun claveDeIngresoSoloExigeLargoMinimo() {
        assertNotNull(Validador.claveIngreso(""))
        assertNotNull(Validador.claveIngreso("1234567"))
        assertNull(Validador.claveIngreso("12345678"))
    }

    @Test fun fuerzaDeClaveCuentaLosCuatroCriterios() {
        val media = Validador.fuerzaClave("Fitnessx")   // largo 8 + mayúscula, sin número ni símbolo
        assertEquals(2, media.puntaje)
        assertEquals("Media", media.etiqueta)
        assertEquals(4, Validador.fuerzaClave("Clave123!").puntaje)
        assertEquals("Débil", Validador.fuerzaClave("abc").etiqueta)
    }

    @Test fun rutConDigitoVerificadorCorrectoEsValido() {
        assertNull(Validador.rut("12.345.678-5"))
        assertNull(Validador.rut("123456785"))           // sin puntos ni guion también sirve
        assertNull(Validador.rut("11.111.111-1"))
        assertNull(Validador.rut("10.000.013-k"))        // dígito K (minúscula)
    }

    @Test fun rutConDigitoVerificadorIncorrectoEsInvalido() {
        // El caso del diseño: 12.345.678-K no existe, el dígito correcto es 5.
        assertEquals("RUT inválido, revisa el dígito verificador", Validador.rut("12.345.678-K"))
        assertNotNull(Validador.rut(""))
        assertNotNull(Validador.rut("abc"))
        assertNotNull(Validador.rut("1-9"))
    }

    @Test fun rutSeFormateaMientrasSeEscribe() {
        assertEquals("12.345.678-5", Validador.formatearRut("123456785"))
        assertEquals("12.345.678-5", Validador.formatearRut("12.345.678-5"))
        assertEquals("1", Validador.formatearRut("1"))
        assertEquals("10.000.013-K", Validador.formatearRut("10000013k"))
    }

    @Test fun cargoEsObligatorio() {
        assertNull(Validador.cargo("Vendedor/a de Sala"))
        assertNotNull(Validador.cargo(""))
    }

    @Test fun probadorEnReparacionOManoDisponibleNoSePuedeUsar() {
        // Aunque esté "ocupado" en la BD, el estado de servicio manda.
        assertEquals(
            EstadoProbador.EN_REPARACION,
            ReglasProbador.calcularEstado(false, null, 0L, 15, EstadoServicio.EN_REPARACION)
        )
        assertEquals(
            EstadoProbador.NO_DISPONIBLE,
            ReglasProbador.calcularEstado(true, 0L, 20 * 60_000L, 15, EstadoServicio.NO_DISPONIBLE)
        )
        assertEquals(
            EstadoProbador.LIBRE,
            ReglasProbador.calcularEstado(false, null, 0L, 15, EstadoServicio.ACTIVO)
        )
        assertTrue(EstadoProbador.EN_REPARACION.fueraDeServicio)
        assertFalse(EstadoProbador.PROLONGADO.fueraDeServicio)
    }

    @Test fun estadoDeServicioSeLeeDesdeTextoGuardado() {
        assertEquals(EstadoServicio.EN_REPARACION, EstadoServicio.desde("EN_REPARACION"))
        assertEquals(EstadoServicio.ACTIVO, EstadoServicio.desde("cualquier cosa"))   // valor desconocido = operativo
    }

    @Test fun datosDeTiendaYProbadoresSeValidan() {
        assertNull(Validador.nombreTienda("Jumbo Chicureo"))
        assertNotNull(Validador.nombreTienda(" "))
        assertNotNull(Validador.nombreTienda("ab"))
        assertNull(Validador.cantidadProbadores("12"))
        assertNotNull(Validador.cantidadProbadores("0"))
        assertNotNull(Validador.cantidadProbadores("31"))
        assertNotNull(Validador.cantidadProbadores("abc"))
        assertNull(Validador.motivoServicio("Puerta dañada"))
        assertNotNull(Validador.motivoServicio(""))
        assertNull(Validador.tienda("Jumbo Costanera"))
        assertNotNull(Validador.tienda(""))
    }

    @Test fun direccionDebeSerCompleta() {
        assertNull(Validador.direccion("Av. Central 123"))
        assertNotNull(Validador.direccion(" "))
        assertNotNull(Validador.direccion("abc"))
    }

    @Test fun tiempoLimiteFueraDeRangoEsInvalido() {
        assertNull(Validador.tiempoLimite("15"))
        assertNotNull(Validador.tiempoLimite("0"))
        assertNotNull(Validador.tiempoLimite("500"))
        assertNotNull(Validador.tiempoLimite("abc"))
    }
}
